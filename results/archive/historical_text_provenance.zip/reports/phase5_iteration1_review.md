# Phase 5 - iteration 1: box-prompted SAM segmentation

Date: 2026-11-09. **Recommendation: NEEDS FIXES before using these masks for image modification.**

The independent segmentation stage runs successfully on the available GPU. Both experiments produced three nonempty original-resolution binary masks, and all 157 offline tests pass. The bicycle masks include background between thin structures; the lamp candidates disagree around the flame/wick and exclude the dark lower support. These quality and target-definition issues require independent review.

**Both experiments are RESEARCH_ONLY.** No human approval was invented, no planner candidate was automatically consumed, and no diffusion, inpainting or cultural editing was performed. Stop after this package.

## 1. Objective and implementation summary

Given an original image and one explicitly selected saved Grounding DINO prediction, run `facebook/sam-vit-base` to generate possible object masks. Preserve every returned mask, restore exact original resolution, save binary PNGs, and collect provenance, numeric checks, visual evidence and performance observations.

The detector is not rerun. Its original query, prediction index, box, score, label and entire source JSON remain unchanged. SAM sees only the image and the selected original-coordinate box; it receives no cultural instructions or text query.

Implementation responsibilities:

| Component | What it does in simple English |
|---|---|
| `SamConfig` and `configs/sam.yaml` | Hold the pinned checkpoint and initial runtime settings. |
| `SegmentationInput` | Records the exact source image/detection hashes, selected box/index and research or reviewed provenance. |
| `SegmentationMask` | Describes a saved mask, its dimensions, SAM score, foreground count, bounds and validation state. |
| `SegmentationResult` | Collects all masks, the visualization choice, measurements, warnings and failure status. |
| `load_segmentation_input` | Checks the existing grounding evidence, explicit selection mode and optional accepted review before inference. |
| `SamSegmenter` | Lazily loads SAM, runs one box, restores masks, rejects invalid outputs and saves artifacts. |
| `scripts/segment_sam.py` | Provides an independent research command without changing caption/plan/ground CLI behavior. |

The new stage reuses the existing working-tree review utility's evidence checks and `read_candidate` gate. The command is run as `python -m scripts.segment_sam` from the project root with `src` on `PYTHONPATH`. It is not advertised as a new installed console subcommand that works from arbitrary directories.

## 2. Human-review record inspection

A saved bicycle file exists at `reports/phase4_iteration3_assets/examples/A_bicycle/accepted.json`. Its hashes, selection and inspection flags pass the existing Phase 4 gate. However, the reviewer field is the unresolved placeholder **`YOUR_NAME`**. Structural validity does not establish that a named person genuinely performed the review.

No confirmed named-human review was available when these experiments ran. The original file was preserved unchanged. A clarification request was presented to the user, but no approval was inferred from silence. Both runs used the explicitly permitted **RESEARCH_ONLY** route. The new SAM input loader refuses common unresolved reviewer-name placeholders in reviewed mode rather than representing them as confirmed approval. This does not modify the existing Phase 4 gate or planner policy.

[Inspection record](phase5_iteration1_assets/review_inspection.json).

The separate reviewed mode accepts a valid, non-placeholder review record only after the existing gate succeeds and its exact image/detection hashes and selected box match the supplied input. This path was exercised with synthetic review declarations in offline tests, not by fabricating a new human acceptance for these experiments.

## 3. Directory changes

```text
MiniProject/
|-- configs/
|   |-- models.yaml                   unchanged
|   |-- planner.yaml                  unchanged
|   |-- grounding.yaml                unchanged defaults
|   `-- sam.yaml                      new pinned SAM settings
|-- src/transcreation/
|   |-- config.py                     appended SamConfig/loader
|   |-- contracts.py                  appended segmentation records
|   |-- cli.py                        unchanged existing commands
|   `-- stages/
|       |-- caption.py                unchanged
|       |-- planning.py               unchanged
|       |-- ollama_planner.py         unchanged
|       |-- grounding.py              unchanged
|       `-- segmentation.py           implemented previous placeholder
|-- scripts/
|   |-- review_grounding.py           unchanged, reused for review checks
|   `-- segment_sam.py                new independent SAM CLI
|-- tests/test_segmentation.py        31 new mocked tests
`-- reports/
    |-- phase5_iteration1_review.md
    |-- phase5_iteration1_assets/
    |   |-- A_bicycle/                all masks, overlays, evidence and JSON
    |   |-- B_oil_lamp/               all masks, overlays, evidence and JSON
    |   `-- implementation/           relevant source/test snapshots
    `-- phase5_iteration1_review.zip
```

Existing inpainting placeholders were not implemented. No architecture rewrite, dependency change or unrelated refactoring was performed.

## 4. Model, revision and installed API

| Item | Value |
|---|---|
| Checkpoint | `facebook/sam-vit-base` |
| Pinned and loaded revision | `70c1a07f894ebb5b307fd9eaaee97b9dfc16068f` |
| Python | 3.11.9 |
| Transformers | 4.57.6, retained |
| Torch | `2.15.0+cu132` |
| Actual GPU | NVIDIA GeForce RTX 3050 Laptop GPU, 4096 MiB |
| Driver / CUDA runtime | 592.00 / 13.2 |
| Device / model precision | CUDA / FP32 |
| Batch size / prompts | One image / one box, no point prompts |
| Seed | 42 |
| Inference | `eval()` and `torch.inference_mode()` |
| Returned alternatives | `multimask_output=True`, three masks observed |
| Mask threshold | 0.0 on restored logits, then binary output |
| Actual attention backend | SDPA |
| Mask restoration device | CPU, to reduce CUDA pressure |

The revision was resolved from the Hugging Face model API before downloading. `model.config._commit_hash` is checked against it during loading. Model construction is lazy. On loading failure, final code records no resolved revision rather than falsely claiming one was loaded.

Installed signatures and processor implementation were inspected before coding. The output docstring abbreviates dimensions, so actual batch/box/candidate axes were checked in code and real results:

```text
input_boxes supplied:       [[[x_min, y_min, x_max, y_max]]]
processor input_boxes:      [1 image, 1 box, 4 coordinates]
SAM pred_masks:             [1, 1, 3, 256, 256]
SAM iou_scores:             [1, 1, 3]
restored masks per image:   [1 box, 3 candidates, original_height, original_width]
```

The processor transforms the original-image XYXY box. No manual scaling of the box is performed. The code preserves `original_sizes` and `reshaped_input_sizes` and invokes `SamImageProcessor.post_process_masks(..., mask_threshold=0.0, binarize=True)` on CPU. It removes processor padding and restores original dimensions before saving.

Actual sizes:

| Scene | `original_sizes` (H,W) | `reshaped_input_sizes` (H,W) | Saved PNG size (W,H) |
|---|---|---|---|
| Bicycle | [966, 1280] | [773, 1024] | [1280, 966] |
| Oil lamp | [842, 1280] | [674, 1024] | [1280, 842] |

The processor uses longest-edge resizing to 1024 and padding for inference. The original files are never permanently resized. Effective settings, transformed input boxes and actual tensor shapes are archived in each experiment JSON.

[Effective YAML](phase5_iteration1_assets/sam.yaml), [checkpoint config](phase5_iteration1_assets/checkpoint_config.json), [processor config](phase5_iteration1_assets/checkpoint_preprocessor_config.json), [environment/API metadata](phase5_iteration1_assets/metadata.json).

## 5. Input, output and validation contract

Inputs contain the source path/SHA-256, original dimensions, exact existing detection JSON/hash, selected zero-based index and its original box, original query/model provenance, selection note and RESEARCH_ONLY or REVIEWED_SELECTION status. Reviewed mode additionally binds the accepted-review file/hash.

Before loading model weights, the stage revalidates the input evidence and selected box. It confirms the source image hash and dimensions, verifies the detection/review bytes against the selection snapshot, and refuses missing/invalid indices. It then binds the exact bytes used for decoding and evidence copies. Planner JSONs cannot masquerade as grounding results. Editing-authorization fields must remain false.

Outputs contain every candidate mask and SAM score; original-resolution dimensions; foreground pixel count; mask bounds; source/detection/selection provenance; checkpoint/revision; processor/inference settings; status; timings; allocated CUDA peaks; warnings and both false editing-permission fields.

Binary masks are grayscale PNGs: **0 = background, 255 = foreground**. Masks must be original-sized boolean tensors before conversion. Foreground counts and bounds are derived from those exact masks. Mask bounds use integer XYXY coordinates with **exclusive upper bounds**, like image cropping.

Empty masks are saved as rejected audit evidence but cannot be valid candidates or the primary visualization. Wrong dimensions, nonbinary tensors, nonfinite outputs or model failures are reported explicitly. `SEGMENTED` means all candidates passed these checks; it does not mean their object boundaries are correct. Partly invalid/empty outcomes use `PARTIAL_INVALID` or `INVALID_OUTPUT`; failures use `ERROR`.

All alternatives remain. The highest finite SAM score among nonempty candidates chooses only the main comparison visualization. It is not a human-approved mask, measured accuracy or permission to edit. There is no clipping to the grounding box, manual mask repair, hole filling or cleanup of saved masks. A small dilated/eroded edge band is used only to draw visible boundaries in overlays.

## 6. Exact experiment inputs and commands

### A: bicycle

Source: `data/vlm_collection/scene_06.jpg`; saved detection: `R01_bicycle_replay`; explicit zero-based index **0**. The existing box visibly surrounds the bicycle. Because the only ACCEPT record has an unresolved reviewer placeholder, the experiment is RESEARCH_ONLY.

### B: oil lamp

Source: `data/vlm_collection/scene_02.jpg`; saved detection: `A02_oil_lamp_020`; explicit zero-based index **2**. Prior indexed visual evidence establishes this as the central burning lamp bowl/flame region. It was chosen from that visual evidence, not automatically by confidence. The source JSON retains all eight detector predictions. This is also RESEARCH_ONLY.

Commands were run sequentially from the repository root. Ollama `/api/ps` was empty beforehand. Separate CLI processes loaded only SAM; Grounding DINO, SmolVLM and Qwen were not run simultaneously or rerun for these experiments. The exact effective command arguments are included in the appendix and [command record](phase5_iteration1_assets/commands.json). Use a new output directory for any independently authorized rerun.

## 7. Actual results and mask measurements

Both experiments completed with `SEGMENTED` status on CUDA, without OOM or CPU fallback. Each returned three nonempty masks. All six saved masks were checked for exact original dimensions, byte values {0,255}, foreground count and bounding rectangle. Source copies match their original bytes and hashes.

The per-candidate table, PNGs, overlays and JSONs are included in the appendix. Scores are SAM's **predicted mask-quality/IoU scores**, not IoU measured against independent pixel-level ground truth.

### Bicycle: visual assessment

- Candidate 0, which has the highest predicted score, covers much of the bicycle silhouette but also substantial wall/graffiti background above the rear frame/saddle and between frame parts.
- Candidate 1 removes much of that upper spill and opens larger frame regions more plausibly, but still treats most wheel interiors as solid foreground.
- Candidate 2 introduces irregular holes and fragments in the wheel/frame regions; they do not visibly preserve the individual spokes reliably.
- All candidates include visible background between spokes. Small thin components, cables and exact rim/frame boundaries are not reliably isolated by this box-only result.
- These are not suitable thin-structure-preserving inpainting masks as-is. The highest SAM score does not settle which boundary is useful for our research objective.

### Oil lamp: visual assessment

- All three candidates follow the main bowl outline fairly closely and do not encompass other lamps or the entire scene.
- They differ around the bright flame, wick and surrounding oil/reflection region. Candidate 0 leaves narrow internal holes; candidates 1 and 2 exclude larger areas around that region.
- The dark pedestal/support beneath the bowl appears excluded. The selected source box itself ends near the bowl's lower edge, so whether the intended object includes the full base needs review.
- Outer bowl boundaries look promising for a vessel-only research target, but flame inclusion, transparent/light-emitting regions and the intended extent are unresolved. A lamp-with-flame target would have different requirements from a bowl-only target.

These observations are subjective visual inspection, not expert annotations. We inspected full comparisons, all-candidate overlays and unmodified binary-mask detail crops. No independent pixel ground truth exists; no measured IoU, Dice, precision, recall or mask accuracy is claimed.

The detail figures crop existing outputs for viewing only: bicycle XYXY [400,540,1000,966], lamp [600,220,930,475]. Display crop offsets/header strips are not part of mask coordinates. Cropping did not change saved full-resolution masks.

## 8. Runtime and memory

| Scene | Load/initialize s | Forward s | Restore + mask save s | Stage s | Visualizations s | Peak allocated CUDA MiB |
|---|---:|---:|---:|---:|---:|---:|
| Bicycle | 8.4585 | 3.1459 | 0.1487 | 11.8551 | 1.1976 | 1969.59 |
| Oil lamp | 7.9288 | 0.9840 | 0.0552 | 9.0493 | 0.9856 | 1969.59 |

Both loading peaks were **374956544 bytes**. Both inference/postprocessing allocation peaks were **2065262592 bytes** (about 1.92 GiB). These include resident model tensors but exclude other applications, driver/context allocations and reserved-only memory. CUDA peaks are reset after loading. `nvidia-smi` snapshots showed 1830 MiB globally used before the experiments and 1268 MiB after shutdown; this difference is not a process-specific memory measurement.

Forward timings bracket the model call with CUDA synchronization. Stage times include loading, preprocessing, forward pass, restoration and mask writing; they exclude earlier source verification/decoding, Python startup, cached checkpoint download and later visualizations. Load times include lazy initialization. Each scene was run once in a separate process, so hardware warm-up and state differ; no average-latency or causal speed comparison is claimed.

FP32 was retained throughout. Both runs fit on the 4 GB GPU with SDPA. CUDA OOM handling records the failure and attempts the same checkpoint on CPU once when allowed. Final code records the failed attempt's duration/peak when available. Fallback was exercised with mocks only; actual CPU inference performance remains unmeasured.

## 9. Offline tests and compatibility

| Suite | Tests | Recorded time | Failures/errors | Outcome |
|---|---:|---:|---|---|
| Before Phase 5 | 126 | 1.405 s | 0 / 0 | OK |
| Final after implementation | 157 | 3.658 s | 0 / 0 | OK |

The 31 added tests mock SAM loading and outputs, requiring no weights or download. They cover original-coordinate input and [1,1,4] boxes; original-size restoration; all alternative masks; binary PNGs; empty-mask rejection/audit; incorrect dimensions/nonbinary data; invalid indices/boxes; image/detection/review hash changes; lazy pinned loading and inference mode; loading failure; CUDA OOM/unavailability and CPU fallback; research provenance; unauthorized editing/planner requests; pending/placeholder review rejection; valid synthetic reviewed input; explicit lower-confidence detector selection; no overwrites; nonfinite scores and initial configuration constraints.

All pre-existing tests remain in the suite, including planner decisions/quarantine, grounding validation and the Phase 4 review gate. No original Grounding DINO predictions or existing review policies were changed. Accepted-review test fixtures are synthetic declarations, not evidence of genuine human approval for the two images.

Post-run hardening changes were confined to failed-attempt telemetry, invalid-config checks, exact-byte evidence binding and null revision on loading failure. They do not change successful forward/postprocessing settings or the preserved masks. Final offline tests exercise the final code; model inference was not repeated just for those changes.

[Before tests](phase5_iteration1_assets/tests_before.txt), [after tests](phase5_iteration1_assets/tests_after.txt), [structured test summary](phase5_iteration1_assets/test_summary.json), [new tests](phase5_iteration1_assets/implementation/tests/test_segmentation.py), [CLI help](phase5_iteration1_assets/cli_help.txt), [artifact verification](phase5_iteration1_assets/verification.json).

## 10. Git diff and evidence preservation

Task-specific changes:

- Appended SAM configuration/loader to `config.py` and segmentation contracts to `contracts.py`.
- Implemented the existing `stages/segmentation.py` placeholder.
- Added `configs/sam.yaml`, `scripts/segment_sam.py`, 31 mocked tests and this new evidence package.

A pre-change snapshot covered **545 existing files**. Only the three authorized application files changed; **542 existing files remain byte-identical**, none deleted. This includes Grounding DINO implementation/predictions, review utility/records, images, old experiments, prior reports/ZIPs, VLM/LLM code, planner policies and dependency declarations. Append-only changes preserve the existing contract/configuration code.

[Before hashes](phase5_iteration1_assets/preservation_before.json), [preservation verification](phase5_iteration1_assets/preservation_after.json), [task-scoped diff](phase5_iteration1_assets/task_changes.diff), [diff summary](phase5_iteration1_assets/git_diff_summary.txt), [initial Git status](phase5_iteration1_assets/initial_git_status.txt).

The working tree already contained earlier uncommitted work, which was not overwritten. No automatic commit, push, model-cache deletion or original-image modification occurred. No new dependency or package upgrade was introduced.

## 11. Limitations and recommendation

**NEEDS FIXES before these masks are used for modification.** The implementation and regression checks pass, but segmentation quality and target definition need mentor evaluation.

1. Bicycle spokes and background holes are not reliably separated; the highest-scoring candidate visibly leaks into wall background.
2. Lamp flame/wick/base inclusion is ambiguous. Define the intended foreground before deciding whether a mask is acceptable.
3. No confirmed named-human approval was used. Existing placeholder-review evidence was preserved, not silently relabeled as genuine approval.
4. Scores are learned predictions, not measured ground-truth IoU. Six numerically valid masks do not establish six correct masks.
5. Only two scenes and one fixed box prompt per scene were run. No point prompts, prompt refinement, threshold experiments or mask cleanup were performed.
6. Reproducibility metadata is pinned and archived, but repeated SAM inference was not used to establish bitwise reproducibility. GPU state and kernels can affect observations.
7. CPU fallback and model failures were tested with mocks; real CPU latency and simultaneous model residency were not tested.
8. Review checks bind declared evidence; they cannot authenticate human identity or prove inspection. The reviewed-mode helper follows the existing local gate plus placeholder checks, not a signed review system.

Recommended next action is **independent evaluation of this package**: inspect all candidate masks, decide the intended foreground definition, and determine whether a separate prompt-refinement/review milestone is warranted. Do not automatically choose a new prompt, alter masks, implement diffusion or start another phase.

## 12. Package contents and attribution

The ZIP contains this Markdown, both experiment JSONs, all six original-resolution binary masks and overlays, original/box/mask comparisons, all-candidate/detail figures, exact source image/detection copies, effective model/API/configuration metadata, test evidence, preservation/diff records and relevant code snapshots. Links use relative paths for review after extraction. No model weights, environments, unrelated datasets or secrets are included.

Image attribution from the existing project manifest: bicycle by Basile Morin, [Wikimedia source](https://commons.wikimedia.org/wiki/File:Parked_bicycle_with_graffitied_building_facade_and_doors_in_Amsterdam.jpg), [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/); lamps by Benoy, [Wikimedia source](https://commons.wikimedia.org/wiki/File:Diwali_Oil_lamps_Darjeeling.jpg), [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/). Visualization derivatives retain their corresponding source attribution/license.

## Appendix: exact commands, candidate masks and visual evidence

### Commands used

```powershell
$env:PYTHONPATH = (Resolve-Path .\src).Path
.\.venv\Scripts\python.exe -B -m scripts.segment_sam --image data/vlm_collection/scene_06.jpg --detection reports/phase4_iteration2_assets/runs/R01_bicycle_replay/detection.json --prediction-index 0 --research-only --note "Explicit Phase 4 bicycle prediction index 0; segmentation research only; placeholder reviewer record is not treated as confirmed approval." --out reports/phase5_iteration1_assets/A_bicycle
.\.venv\Scripts\python.exe -B -m scripts.segment_sam --image data/vlm_collection/scene_02.jpg --detection reports/phase4_iteration2_assets/runs/A02_oil_lamp_020/detection.json --prediction-index 2 --research-only --note "Manually chosen zero-based prediction index 2 from saved visual evidence: the central burning lamp bowl and flame, not an automatic highest-confidence selection; no human approval claimed." --out reports/phase5_iteration1_assets/B_oil_lamp
```

Shell quoting in this display preserves the exact note argument values. No additional real model calls were made after these two experiments.

### Bicycle: all mask candidates

Selection status **RESEARCH_ONLY**, detector index **0**. Original image SHA-256: `e0fa05019d587cc62b1d4d5a82d7440216b5d88ef0f2149a69f2eb2ee640fca0`. Detection JSON SHA-256: `424abf5cdd98ad02be3e9ae9e68e40cc9186ba6167874bf5488dbadec94d6992`.

Original source box: `[441.8973388671875, 581.3589477539062, 953.31396484375, 924.9127197265625]`. Detector label `bicycle` and score `0.9432805180549622` are unchanged provenance.

[Exact source image](phase5_iteration1_assets/A_bicycle/original.jpg) | [Saved box view](phase5_iteration1_assets/A_bicycle/box.png) | [Exact detection source](phase5_iteration1_assets/A_bicycle/source_detection.json) | [Full experiment JSON](phase5_iteration1_assets/A_bicycle/segmentation.json)

| Mask index | SAM predicted score (not measured IoU) | Foreground pixels | Mask XYXY bounds (upper exclusive) | Dimensions W,H | Binary mask | Overlay |
|---|---:|---:|---|---|---|---|
| 0 | 0.955327630 | 110800 | `[444, 578, 957, 924]` | `[1280, 966]` | [mask 0](phase5_iteration1_assets/A_bicycle/mask_0.png) | [overlay 0](phase5_iteration1_assets/A_bicycle/overlay_0.png) |
| 1 | 0.943802357 | 88076 | `[444, 584, 956, 924]` | `[1280, 966]` | [mask 1](phase5_iteration1_assets/A_bicycle/mask_1.png) | [overlay 1](phase5_iteration1_assets/A_bicycle/overlay_1.png) |
| 2 | 0.864693284 | 72998 | `[444, 583, 949, 924]` | `[1280, 966]` | [mask 2](phase5_iteration1_assets/A_bicycle/mask_2.png) | [overlay 2](phase5_iteration1_assets/A_bicycle/overlay_2.png) |

All candidates have numeric status VALID and remain unmodified. Full floating-point scores are in JSON. Visualization index **0** was selected only by the highest SAM score; it has not been confirmed as the best semantic mask.

![Bicycle: original, source box and score-ranked mask visualization](phase5_iteration1_assets/A_bicycle/comparison.png)

![Bicycle: every candidate overlay and score](phase5_iteration1_assets/A_bicycle/candidate_gallery.png)

![Bicycle: display crops of original, candidate overlays and raw binary masks](phase5_iteration1_assets/A_bicycle/detail_comparison.png)

### Oil lamp: all mask candidates

Selection status **RESEARCH_ONLY**, detector index **2**. Original image SHA-256: `321c415a72e47d745949c90170c6342f70dafcbbe47380ff4cfaffbaf2b4dfc2`. Detection JSON SHA-256: `ecf6178788fb81e7ebe2ba53b4e87479def087521b35cbdda5d87494526646a6`.

Original source box: `[631.4442138671875, 248.13294982910156, 889.331787109375, 443.25518798828125]`. Detector label `oil lamp` and score `0.31422239542007446` are unchanged provenance.

[Exact source image](phase5_iteration1_assets/B_oil_lamp/original.jpg) | [Saved box view](phase5_iteration1_assets/B_oil_lamp/box.png) | [Exact detection source](phase5_iteration1_assets/B_oil_lamp/source_detection.json) | [Full experiment JSON](phase5_iteration1_assets/B_oil_lamp/segmentation.json)

| Mask index | SAM predicted score (not measured IoU) | Foreground pixels | Mask XYXY bounds (upper exclusive) | Dimensions W,H | Binary mask | Overlay |
|---|---:|---:|---|---|---|---|
| 0 | 0.964610636 | 33862 | `[635, 253, 888, 444]` | `[1280, 842]` | [mask 0](phase5_iteration1_assets/B_oil_lamp/mask_0.png) | [overlay 0](phase5_iteration1_assets/B_oil_lamp/overlay_0.png) |
| 1 | 0.956918180 | 30373 | `[634, 253, 888, 442]` | `[1280, 842]` | [mask 1](phase5_iteration1_assets/B_oil_lamp/mask_1.png) | [overlay 1](phase5_iteration1_assets/B_oil_lamp/overlay_1.png) |
| 2 | 0.947273970 | 27917 | `[634, 253, 888, 442]` | `[1280, 842]` | [mask 2](phase5_iteration1_assets/B_oil_lamp/mask_2.png) | [overlay 2](phase5_iteration1_assets/B_oil_lamp/overlay_2.png) |

All candidates have numeric status VALID and remain unmodified. Full floating-point scores are in JSON. Visualization index **0** was selected only by the highest SAM score; it has not been confirmed as the best semantic mask.

![Oil lamp: original, source box and score-ranked mask visualization](phase5_iteration1_assets/B_oil_lamp/comparison.png)

![Oil lamp: every candidate overlay and score](phase5_iteration1_assets/B_oil_lamp/candidate_gallery.png)

![Oil lamp: display crops of original, candidate overlays and raw binary masks](phase5_iteration1_assets/B_oil_lamp/detail_comparison.png)

### Inspecting bundled focused tests

The package contains minimal source snapshots, not model weights or an environment. From its extracted root, with the existing Python/Pillow/Torch/PyYAML environment, these commands run only the mocked SAM tests:

```powershell
$env:PYTHONPATH = "$(Resolve-Path phase5_iteration1_assets/implementation);$(Resolve-Path phase5_iteration1_assets/implementation/src)"
python -B -m unittest discover -s phase5_iteration1_assets/implementation/tests -p test_segmentation.py -q
```

The snapshots include the unchanged review helper and package markers required by those tests. No review declaration in a synthetic test is a human approval of the research images.

The consolidated evaluation ends here. Independent mentor review is required before any additional prompt experiments or implementation milestone.
