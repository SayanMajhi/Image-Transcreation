# Phase 5 - iteration 3: mask quality review and final segmentation gate

Date: 2026-11-09. **Phase 5 sign-off recommendation: NEEDS FIXES / ACTUAL HUMAN REVIEW PENDING.**

The new review mechanism passes its offline checks. The full regression suite passes **199 tests**. No model inference, model download, new point experiment or mask cleanup occurred. Every pre-existing file is unchanged.

The real cases contain **five PENDING human-review requests and zero accepted masks**. Oil-lamp candidates 0 and 1 are ready for bowl-only inspection. The bicycle case carries a **NEEDS_REVIEW preparation flag**, with its three human requests still PENDING. No successful bicycle mask or human confirmation was fabricated. Phase 6 was not started.

## 1. Implementation summary

Added two files only:

- `scripts/review_mask.py`: prepare review evidence, record an explicit human decision, and revalidate one accepted research mask.
- `tests/test_mask_review.py`: 29 offline tests with synthetic Pillow artifacts and synthetic reviewer declarations.

The utility reuses existing `SegmentationInput`, `SegmentationMask`, `SegmentationResult`, `SamPoint` and grounding contracts. It also reuses the grounding-review JSON, hash, exclusive-write and source-image validation helpers. Existing segmentation contracts and application code were not refactored or changed.

This is a standalone research command run from the project root as `python -m scripts.review_mask`. A fresh-process import check confirms it loads neither Torch nor Transformers. It contains no SAM loading or inference path.

### The three operations

| Operation | What it does | What it cannot do |
|---|---|---|
| `prepare` | Validates saved evidence, copies exact source files into a new directory, creates PENDING requests and a comparison figure. | Accept a mask or fabricate a reviewer. |
| `decide` | Writes a new record for one explicit human declaration. | Select by score, implicitly choose candidate 0, approve a batch or overwrite previous decisions. |
| `read_candidate` | Revalidates an accepted record and returns a copy of its verified binary-mask pixels for the stated controlled test. | Authorize editing, diffusion or cultural transformation. |

## 2. Review states and scope

| Human-review state | Meaning | Mask released? |
|---|---|---|
| PENDING | No human decision submitted. | No |
| ACCEPT_FOR_SEGMENTATION_TEST | A named reviewer explicitly considers one specified mask usable for the named controlled segmentation experiment. | One verified mask, for that test only |
| REJECT | The reviewer considers this candidate unsuitable for the stated target/test. | No |
| NEEDS_REVIEW | The reviewer cannot resolve quality, object extent or suitability. | No |

All submitted decisions require a nonempty reviewer identity/reason and explicit declarations that the **original image, binary mask and overlay** were inspected. Common identity placeholders such as `YOUR_NAME`, `Your Name`, `your-name`, `UNKNOWN` and angle-bracket placeholders are rejected. The utility does not authenticate a person's identity or prove they actually inspected the images.

Acceptance always requires an explicit candidate index matching the chosen pending request. It never defaults to zero or reads the highest SAM score as approval. One call submits one record for one mask. The source segmentation's score-ranked visualization choice is not a selection rule for this gate.

Every request/decision retains these false permissions:

```json
{
  "image_edit_authorized": false,
  "diffusion_authorized": false,
  "cultural_transformation_authorized": false
}
```

Acceptance is labeled **"reviewed mask for controlled segmentation test"**. It does not validate a complete lamp replacement, approve cultural changes, certify source point annotations or upgrade the historical RESEARCH_ONLY provenance.

## 3. Record contents and index meanings

| Evidence | Record field |
|---|---|
| Original image digest | `source_image_sha256` |
| Grounding JSON digest | `detection_json_sha256` |
| Exact segmentation JSON digest | `segmentation_json_sha256` |
| Bound candidate PNG digest | `mask_file_sha256` |
| Selected PNG digest after acceptance | `selected_mask_sha256` |
| Original grounding selection | `grounding_prediction_index`, `grounding_box` |
| SAM checkpoint provenance | `sam_model_id`, `sam_revision` |
| Prompt and historical selection provenance | `prompt_type`, `source_selection_status`, `point_document_sha256` |
| Candidate under inspection | `candidate_index` |
| Actual accepted selection | `selected_mask_index`, null until acceptance |
| Mask properties | `mask_dimensions`, `foreground_pixels`, `mask_bounds`, unchanged `sam_score` |
| Limited purpose | `target_definition`, `controlled_experiment` |
| Human declaration | `reviewer`, `decision`, `reason`, `reviewed_at_utc` |
| Inspection declarations | `inspected_original`, `inspected_mask`, `inspected_overlay` |
| Full source-file binding | `evidence_hashes`, including other candidate masks/overlays |
| Pending-request audit link | `source_request_file`, `source_request_sha256` on submitted decisions |

For the lamp, **grounding prediction index 2** identifies the source box. **SAM candidate index 0 or 1** identifies a mask generated from that box and the saved point set. These indices are different concepts.

A request such as `pending_1.json` binds candidate 1 for inspection; it does not select or approve it. Its `selected_mask_index`, reviewer and actual human review timestamp are null. Request creation time is not a human review timestamp.

## 4. Integrity verification

Before preparing or recording a decision, the utility reconstructs the existing typed segmentation result and checks:

1. The saved result completed with `SEGMENTED` status and consistent SAM model/revision metadata.
2. The portable original-image copy matches both grounding and segmentation image hashes and dimensions.
3. The exact detection JSON hash, selected grounding index, box, query and model provenance agree with the segmentation input.
4. Where applicable, the point document matches its hash, image/detection/index bindings and recorded points. Its preview dimensions are checked.
5. Candidate indices are distinct and the requested candidate exists. No default choice is made when there are several masks.
6. Each source mask is a grayscale PNG at the exact original resolution with only values 0 and 255, a nonzero foreground count, and bounds/counts recomputed from its pixels that agree with the record.
7. Overlays and the box/point previews decode with consistent dimensions. Their exact bytes are included in the bound manifest.
8. The prepared request binds the segmentation JSON, source image/detection/points, all candidate masks and their overlays. Changes after preparation, including PNG trailing bytes or JSON whitespace, invalidate that binding.

When loading an accepted mask later, the utility checks those properties again, verifies the explicit selected index and mask hash, and validates the original PENDING request's digest. The target definition and controlled-experiment scope must still match that request. A modified acceptance cannot silently change the target to a whole-image or cultural-editing task.

Files remain alongside the request for portability. Historical project paths inside the untouched SAM JSON are provenance text; the gate uses its local source-copy fields rather than requiring access to a reviewer's local Windows workspace.

The actual case source files were additionally compared byte-for-byte with the **previous iteration's review ZIP before copying**. [Prior archive check](phase5_iteration3_assets/prior_archive_check.json). [Current request verification](phase5_iteration3_assets/verification.json).

Integrity checks establish consistency of the bound bytes, not semantic mask correctness. They do not create ground truth, authenticate a signer or prove that an overlay was meaningfully inspected.

## 5. Case A: oil-lamp bowl-only review

Target: **visible clay bowl/body only; exclude the flame and unrelated surrounding objects**. Approval is not for complete lamp replacement. Future treatment of flame, wick and supporting objects remains a separate issue.

The existing point-guided SAM masks are preserved. Candidates **0 and 1** are presented side-by-side as explicitly requested. Both remain **PENDING**. No score-based preference or accepted mask is recorded.

| Candidate | Saved SAM score, not measured accuracy | Foreground pixels | Original dimensions W,H | Human decision |
|---|---:|---:|---|---|
| 0 | 0.970740914 | 32088 | 1280, 842 | PENDING |
| 1 | 0.962729812 | 31757 | 1280, 842 | PENDING |

Both appear to preserve most of the bowl silhouette while excluding the bright flame. Candidate 1 has additional small internal exclusions compared with candidate 0. The dark lower support is outside these masks. A real reviewer must decide whether bowl coverage, internal holes, flame/wick boundaries and excluded material are acceptable for the specified narrow test. This report does not settle that judgment.

The third source mask is retained unchanged as provenance because the source result references it, but no formal human-review request for candidate 2 was created in this case.

![Oil-lamp original, candidates 0/1 overlays, source box and binary masks](phase5_iteration3_assets/case_A_oil_lamp/comparison_candidates.png)

[Original](phase5_iteration3_assets/case_A_oil_lamp/original.jpg) | [Box](phase5_iteration3_assets/case_A_oil_lamp/box.png) | [Mask 0](phase5_iteration3_assets/case_A_oil_lamp/mask_0.png) | [Overlay 0](phase5_iteration3_assets/case_A_oil_lamp/overlay_0.png) | [PENDING 0](phase5_iteration3_assets/case_A_oil_lamp/pending_0.json) | [Mask 1](phase5_iteration3_assets/case_A_oil_lamp/mask_1.png) | [Overlay 1](phase5_iteration3_assets/case_A_oil_lamp/overlay_1.png) | [PENDING 1](phase5_iteration3_assets/case_A_oil_lamp/pending_1.json).

## 6. Case B: bicycle limitations and unresolved review

Target: physical bicycle parts, including frame, handlebars, saddle, rims, tires and visible spokes; exclude wall, road and background through wheels.

All three saved point-guided candidates are presented without modification:

| Candidate | Saved SAM score, not measured accuracy | Foreground pixels | Known limitation |
|---|---:|---:|---|
| 0 | 0.887634158 | 97388 | Wheel-interior/background leakage and extraneous wall/graphic regions remain. |
| 1 | 0.816094458 | 74911 | Background remains in parts of wheels; structures and wheel boundaries are incomplete. |
| 2 | 0.731330991 | 26559 | More open wheel interiors, but many spokes and substantial rim/tire portions disappear. |

The **case preparation status is NEEDS_REVIEW**, following the known findings. This is triage metadata with `status_origin: preparation triage, not a human decision`. Its three actual human-review requests remain PENDING with null reviewer/timestamp. No fake human NEEDS_REVIEW or successful bicycle acceptance was created.

This distinction avoids confusing numerical `SEGMENTED` output, preparation-level NEEDS_REVIEW and an actual human decision. The gate refuses the case manifest as an acceptance record. None of these masks is currently supported as reliably preserving the full declared physical-parts target.

![Bicycle original, all candidate overlays, box and binary masks](phase5_iteration3_assets/case_B_bicycle/comparison_candidates.png)

[Case triage manifest](phase5_iteration3_assets/case_B_bicycle/case.json) | [Original](phase5_iteration3_assets/case_B_bicycle/original.jpg) | [Box](phase5_iteration3_assets/case_B_bicycle/box.png) | [PENDING 0](phase5_iteration3_assets/case_B_bicycle/pending_0.json) | [PENDING 1](phase5_iteration3_assets/case_B_bicycle/pending_1.json) | [PENDING 2](phase5_iteration3_assets/case_B_bicycle/pending_2.json).

These are observations of existing evidence, not new model results or independent pixel annotations. No IoU, Dice, precision, recall or measured accuracy is invented.

## 7. How a real reviewer inspects and selects

From the project root in PowerShell:

```powershell
$env:PYTHONPATH = (Resolve-Path .\src).Path
$case = "reports/phase5_iteration3_assets/case_A_oil_lamp"
Invoke-Item "$case/original.jpg"
Invoke-Item "$case/box.png"
Invoke-Item "$case/comparison_candidates.png"
Invoke-Item "$case/mask_0.png"
Invoke-Item "$case/overlay_0.png"
Invoke-Item "$case/mask_1.png"
Invoke-Item "$case/overlay_1.png"
```

Inspect full-resolution raw masks as well as overlays. Decide whether **either** candidate meets the bowl-only target. A small area difference or higher SAM score is not the approval criterion.

The following is an instruction for an actual human, **not a command executed in this milestone**. Only if the reviewer actually chooses candidate 1, replace identity/reason placeholders truthfully and submit:

```powershell
.\.venv\Scripts\python.exe -B -m scripts.review_mask decide --request "$case/pending_1.json" --decision ACCEPT_FOR_SEGMENTATION_TEST --index 1 --reviewer "YOUR_REAL_NAME" --reason "YOUR OWN BOWL-ONLY BOUNDARY OBSERVATIONS" --inspected-original --inspected-mask --inspected-overlay --out "$case/review_candidate_1.json"
```

The identity placeholder is deliberately rejected until replaced with a real supplied identity. Choosing candidate 0 instead requires its request and explicit `--index 0`; there is no automatic default. Choose no acceptance if neither is suitable.

A real reviewer may instead record REJECT or NEEDS_REVIEW, after inspection, with no selected index:

```powershell
.\.venv\Scripts\python.exe -B -m scripts.review_mask decide --request "$case/pending_1.json" --decision REJECT --reviewer "YOUR_REAL_NAME" --reason "YOUR OWN REASON IT IS UNSUITABLE FOR THIS TEST" --inspected-original --inspected-mask --inspected-overlay --out "$case/rejected_candidate_1.json"
```

For the bicycle, first inspect its original/mask/overlay files, then a possible unresolved submission would be:

```powershell
$case = "reports/phase5_iteration3_assets/case_B_bicycle"
.\.venv\Scripts\python.exe -B -m scripts.review_mask decide --request "$case/pending_0.json" --decision NEEDS_REVIEW --reviewer "YOUR_REAL_NAME" --reason "YOUR OWN OBSERVATIONS ABOUT LEAKAGE AND MISSING STRUCTURES" --inspected-original --inspected-mask --inspected-overlay --out "$case/needs_review_candidate_0.json"
```

All three inspection declarations are required even for rejection/unresolved decisions. Existing files are refused. Decisions must remain alongside their evidence. Prior records are not rewritten; later consumers must explicitly select a reviewed file rather than assume the newest filename or highest score is authoritative.

`read_candidate(review_path)` verifies the chosen ACCEPT_FOR_SEGMENTATION_TEST record before returning mask pixels. PENDING, REJECT, NEEDS_REVIEW and preparation manifests return no candidate. No inference or image-editing pipeline was connected to this helper.

## 8. Offline tests

| Suite | Tests | Time | Failures/errors | Outcome |
|---|---:|---:|---|---|
| Before implementation | 170 | 10.399 s | 0 / 0 | OK |
| Final after implementation | 199 | 12.696 s | 0 / 0 | OK |

The 29 new tests cover explicit acceptance of a valid lower-scoring candidate; REJECT/NEEDS_REVIEW/PENDING refusing release; invalid/placeholder identities; missing/invalid/mismatched indices; modified selected and unselected PNGs; source/segmentation/point/overlay hashes; foreground-count mismatch; nonbinary or wrong-sized masks; missing files; all inspection declarations; false editing/diffusion permissions; original-request audit scope; tampered accepted index/target; exact source/contract preservation; no overwrite; bicycle triage not being a human verdict; malformed metadata; duplicate candidate indices; and CLI behavior.

Tests use temporary synthetic Pillow files and clearly synthetic reviewer declarations. Those test records are not human approvals for the research images. No such accepted fixture is included as real case evidence. The full suite ran with `HF_HUB_OFFLINE=1`; prior model calls are mocked. Existing processor-only tests use no model weights or inference.

[Before output](phase5_iteration3_assets/tests_before.txt), [after output](phase5_iteration3_assets/tests_after.txt), [test summary](phase5_iteration3_assets/test_summary.json), [new tests](phase5_iteration3_assets/implementation/tests/test_mask_review.py), [help/import checks](phase5_iteration3_assets/cli_checks.json).

## 9. Preservation and task-scoped Git diff

All **699 pre-existing snapshotted files remain byte-identical**. No existing segmentation contract, model/stage, point set, mask, configuration, dependency, CLI, reviewer record, planner policy or earlier report/ZIP changed.

```text
new scripts/review_mask.py               296 lines
new tests/test_mask_review.py            257 lines
new reports/phase5_iteration3_review.md
new reports/phase5_iteration3_assets/
new reports/phase5_iteration3_review.zip
existing files modified:                0
new model calls / downloads:            0 / 0
actual human acceptance records:        0
```

Comparison figures only compose copies of existing photographs, box views, masks and overlays; original image pixels and mask files are unchanged. The working tree already had earlier uncommitted work, which was preserved. No commit, push, cleanup or deletion of previous evidence occurred.

[Before hashes](phase5_iteration3_assets/preservation_before.json), [preservation check](phase5_iteration3_assets/preservation_after.json), [diff summary](phase5_iteration3_assets/git_diff_summary.txt), [new-file diff](phase5_iteration3_assets/new_files.diff), [initial Git status](phase5_iteration3_assets/initial_git_status.txt).

## 10. Remaining limitations

1. Real mask suitability is still unreviewed. All five requests are PENDING; the bicycle preparation flag is not an invented human verdict.
2. Identity and inspection declarations are local self-reports, not authenticated signatures or proof of attention. Placeholder rejection does not establish identity truth.
3. Hashes protect consistency after preparation. They do not prove model accuracy, initial evidence authenticity or semantic correctness. For these actual cases, source bytes also match the prior review ZIP. A writer with unrestricted access could still forge a new chain.
4. The gate checks PNG data, metadata and overlay dimensions/digests, not whether an overlay interpretation is semantically correct. The human must inspect original, mask and overlay separately.
5. This version expects the existing successful segmentation artifact layout and refuses corrupt, incomplete or inconsistent input rather than repairing it. No mask repair or new quality model was introduced.
6. Bowl-only suitability does not settle full lamp replacement, flame/wick/light behavior or support handling. Bicycle completeness remains unresolved.
7. Records are immutable by utility convention/exclusive creation, not an access-control platform. Separate named human decisions are possible; there is no automatic case-wide winner or supersession policy. Case manifests record preparation-time triage and are not rewritten by submitted decisions.
8. A future consumer must explicitly use the revalidation gate and preserve its limited purpose. The helper does not authorize a future image editor merely by returning research-mask pixels.

## 11. Final recommendation for Phase 5 sign-off

**NEEDS FIXES / HUMAN QUALITY REVIEW PENDING.** The software review gate and all regression tests pass, but Phase 5 is not signed off as providing a verified full-object mask for either cultural editing or complete lamp replacement.

The oil-lamp candidates may be considered by a real reviewer for the narrow bowl-only controlled test. No such choice was made here. The bicycle masks retain the documented failures and have no supported successful selection. The next action is independent mentor/user inspection of the packaged evidence, not another automatic experiment.

No SAM inference, extra point set, cleanup, diffusion, image modification, new AI model, planner change or Phase 6 work occurred.

## 12. Portable package and attribution

The ZIP includes this consolidated report, five PENDING review requests, two preparation manifests, exact saved source JSON/image/point copies, all source candidate masks and overlays for integrity context, focused comparison figures, test/preservation evidence and minimal implementation snapshots. It contains no model weights, environments, unrelated datasets or secrets. Relative links work after extraction.

Image attribution from the existing project manifest: bicycle by Basile Morin, [Wikimedia source](https://commons.wikimedia.org/wiki/File:Parked_bicycle_with_graffitied_building_facade_and_doors_in_Amsterdam.jpg), [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/); lamps by Benoy, [Wikimedia source](https://commons.wikimedia.org/wiki/File:Diwali_Oil_lamps_Darjeeling.jpg), [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/). Comparison derivatives retain corresponding attribution/license.

## Appendix: actual preparation commands and sample PENDING records

### Preparation commands actually executed

```powershell
$env:PYTHONPATH = (Resolve-Path .\src).Path

.\.venv\Scripts\python.exe -B -m scripts.review_mask prepare --segmentation reports/phase5_iteration2_assets/B_oil_lamp/segmentation.json --candidates 0 1 --target "Visible clay bowl/body only. Exclude flame and unrelated surrounding objects. Approval is not for complete lamp replacement." --experiment "Controlled bowl-only mask inspection and segmentation-test evaluation; no image modification." --case-status PENDING --case-note "Candidates 0 and 1 await actual human comparison; neither is accepted." --out reports/phase5_iteration3_assets/case_A_oil_lamp

.\.venv\Scripts\python.exe -B -m scripts.review_mask prepare --segmentation reports/phase5_iteration2_assets/A_bicycle/segmentation.json --candidates 0 1 2 --target "Physical bicycle parts including frame, handlebars, saddle, rims, tires and visible spokes; exclude wall, road and background through wheels." --experiment "Controlled bicycle physical-parts segmentation-quality review; no image modification." --case-status NEEDS_REVIEW --case-note "Preparation triage only: known background leakage, missing thin structures and incomplete wheel rims/spokes; no successful human-approved bicycle mask exists." --out reports/phase5_iteration3_assets/case_B_bicycle

```

These commands only prepared evidence and PENDING requests. No real-image `decide` command was run. [Full argument log](phase5_iteration3_assets/prepare_commands.json).

### Actual oil-lamp candidate 0 PENDING record: selected fields

This is a field excerpt from the actual prepared request; the [full record](phase5_iteration3_assets/case_A_oil_lamp/pending_0.json) additionally includes the controlled-experiment description, overlay/hash manifest, bounds, score and creation time.

```json
{
  "record_type": "sam_mask_human_review",
  "source_image_sha256": "321c415a72e47d745949c90170c6342f70dafcbbe47380ff4cfaffbaf2b4dfc2",
  "detection_json_sha256": "ecf6178788fb81e7ebe2ba53b4e87479def087521b35cbdda5d87494526646a6",
  "segmentation_json_sha256": "62c9213bb551f693d620e7bea939fa43e8023616390ee9439fe364cabccf6309",
  "candidate_index": 0,
  "mask_file": "mask_0.png",
  "mask_file_sha256": "c10336f253c03f2faaf745829b3e79994e5d9acb82773d6cb9583145cf5cbf46",
  "grounding_prediction_index": 2,
  "grounding_box": [
    631.4442138671875,
    248.13294982910156,
    889.331787109375,
    443.25518798828125
  ],
  "sam_model_id": "facebook/sam-vit-base",
  "sam_revision": "70c1a07f894ebb5b307fd9eaaee97b9dfc16068f",
  "prompt_type": "BOX_PLUS_POINTS",
  "source_selection_status": "RESEARCH_ONLY",
  "point_document_sha256": "49c3e6f58bdc84f3ec620fdc52718f1224ff911ccebf761f416a1b5eaef3c8f4",
  "mask_dimensions": [
    1280,
    842
  ],
  "foreground_pixels": 32088,
  "target_definition": "Visible clay bowl/body only. Exclude flame and unrelated surrounding objects. Approval is not for complete lamp replacement.",
  "decision": "PENDING",
  "selected_mask_index": null,
  "selected_mask_sha256": null,
  "reviewer": null,
  "reviewed_at_utc": null,
  "inspected_original": false,
  "inspected_mask": false,
  "inspected_overlay": false,
  "image_edit_authorized": false,
  "diffusion_authorized": false,
  "cultural_transformation_authorized": false
}
```

### Actual oil-lamp candidate 1 PENDING record: selected fields

This is a field excerpt from the actual prepared request; the [full record](phase5_iteration3_assets/case_A_oil_lamp/pending_1.json) additionally includes the controlled-experiment description, overlay/hash manifest, bounds, score and creation time.

```json
{
  "record_type": "sam_mask_human_review",
  "source_image_sha256": "321c415a72e47d745949c90170c6342f70dafcbbe47380ff4cfaffbaf2b4dfc2",
  "detection_json_sha256": "ecf6178788fb81e7ebe2ba53b4e87479def087521b35cbdda5d87494526646a6",
  "segmentation_json_sha256": "62c9213bb551f693d620e7bea939fa43e8023616390ee9439fe364cabccf6309",
  "candidate_index": 1,
  "mask_file": "mask_1.png",
  "mask_file_sha256": "8ad8562a58ab16fe72841a5b1ed403d9bf527a1116cefb664ae072f43fbe6300",
  "grounding_prediction_index": 2,
  "grounding_box": [
    631.4442138671875,
    248.13294982910156,
    889.331787109375,
    443.25518798828125
  ],
  "sam_model_id": "facebook/sam-vit-base",
  "sam_revision": "70c1a07f894ebb5b307fd9eaaee97b9dfc16068f",
  "prompt_type": "BOX_PLUS_POINTS",
  "source_selection_status": "RESEARCH_ONLY",
  "point_document_sha256": "49c3e6f58bdc84f3ec620fdc52718f1224ff911ccebf761f416a1b5eaef3c8f4",
  "mask_dimensions": [
    1280,
    842
  ],
  "foreground_pixels": 31757,
  "target_definition": "Visible clay bowl/body only. Exclude flame and unrelated surrounding objects. Approval is not for complete lamp replacement.",
  "decision": "PENDING",
  "selected_mask_index": null,
  "selected_mask_sha256": null,
  "reviewer": null,
  "reviewed_at_utc": null,
  "inspected_original": false,
  "inspected_mask": false,
  "inspected_overlay": false,
  "image_edit_authorized": false,
  "diffusion_authorized": false,
  "cultural_transformation_authorized": false
}
```

### Actual bicycle preparation flag

This is a preparation manifest, not a human-review verdict or acceptance record:

```json
{
  "record_type": "mask_review_case_manifest",
  "preparation_status": "NEEDS_REVIEW",
  "status_origin": "preparation triage, not a human decision",
  "case_note": "Preparation triage only: known background leakage, missing thin structures and incomplete wheel rims/spokes; no successful human-approved bicycle mask exists.",
  "human_decision": "PENDING",
  "target_definition": "Physical bicycle parts including frame, handlebars, saddle, rims, tires and visible spokes; exclude wall, road and background through wheels.",
  "controlled_experiment": "Controlled bicycle physical-parts segmentation-quality review; no image modification.",
  "candidate_indices": [
    0,
    1,
    2
  ],
  "requests": [
    "pending_0.json",
    "pending_1.json",
    "pending_2.json"
  ]
}
```

### Focused tests from the extracted ZIP

The report and case artifacts can be inspected without access to the original Windows paths. The included review utility/tests require Python 3.11 and Pillow, not SAM, Torch, Transformers, model weights or a GPU. From the extracted ZIP root:

```powershell
$env:PYTHONPATH = "$(Resolve-Path phase5_iteration3_assets/implementation);$(Resolve-Path phase5_iteration3_assets/implementation/src)"
python -B -m unittest discover -s phase5_iteration3_assets/implementation/tests -p test_mask_review.py -q
```

To use the bundled utility, replace `-m scripts.review_mask` in the decision instructions with `phase5_iteration3_assets/implementation/scripts/review_mask.py` after setting that PYTHONPATH, and omit the leading `reports/` from the case path. Only a real reviewer should submit such a decision after actual inspection. The packaged records remain PENDING.

The milestone ends here. No Phase 6 work or model experiment was started.
