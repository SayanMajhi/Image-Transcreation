# Phase 3 — LLM Cultural Planning Experiments

**Project:** Culture-Aware Image Transcreation  
**Prepared:** 9 November 2026  
**Evidence:** recorded experiments and validation work from 8 November 2026

This report summarizes the experiments, findings, changes and actual results after
VLM selection. It collects existing evidence; no models or tests were rerun to
prepare it. Original outputs and unsuccessful experiments remain unchanged.

## 1. Objective

Implement a local LLM that reads an image caption and user-provided cultural context
and returns a structured adaptation draft. Preserve the original scene's purpose,
important people, activity and relationships, and prevent unsupported drafts from
being passed downstream.

SmolVLM-500M supplies the caption. Qwen2.5-3B performs text-based planning through
Ollama. Grounding, segmentation and image editing are not implemented in Phase 3.
The caption is an unverified model claim, not confirmed visual ground truth.

## 2. Experimental setup

| Item | Recorded configuration |
| --- | --- |
| LLM | `qwen2.5:3b` through local Ollama |
| Reported parameter size / quantization | 3.1B / `Q4_K_M` |
| API | Local `/api/chat`, `stream: false` |
| Output format | JSON Schema matching existing planning-result fields |
| Temperature / seed | 0 / 42 |
| Context / output ceiling | 4096 / 1024 tokens |
| Timeout | 180 seconds |
| Memory strategy | Sequential stages, `keep_alive: 0`, explicit unload requests |
| Python integration | Standard HTTP library; no new Python dependency |

Recorded model digest:

```text
357c53fb659c5076de1d65ccb0b397446227b71a42be9d1603d46168015c9e4b
```

The model, quantization and generation controls were held fixed in the recorded
before/after evaluations. Prompt instructions and validation policy changed.
Temperature and seed aid repeatability but do not guarantee identical output across
different digests, software versions or hardware.

### Planning interface

The input includes source caption, completion status, required target culture,
optional source culture, user instructions and user-verified object records.

The result includes `decision`, `decision_reason`, `scene_summary`, `candidate_edits`,
`must_preserve`, `uncertainties` and `verification_requirements`. Each candidate
separates original object description/localization from the future proposed change.

Python dataclasses and runtime checks enforce the contract. The initial mock planner
tested this interface before connecting a real LLM. Fixed system instructions and
user input are sent as separate messages; embedded input text cannot establish
verified facts or authorize editing.

## 3. Scenarios and provenance

| Scenario | Input source | What it tests |
| --- | --- | --- |
| Japanese meal → India | Synthetic shared meal with hypothetical user-verified ramen and Japanese source context | Contextual adaptation and source/target reasoning |
| Durga Puja → Japan | Archived SmolVLM concise caption | Uncertain object identity, protected meaning and truncation |
| Bicycle → India | Archived ordinary bicycle caption | Appropriate no-change behavior |
| Truncated caption | Archived original Durga caption, with its unfinished ending retained | Conservative handling of incomplete evidence |
| Unknown source culture | Synthetic shared meal without verified source culture | Avoiding invented origin/cultural facts |
| Instruction injection | Archived bicycle caption with a deliberately added malicious instruction | Instruction/data separation and validation boundary |

The [fixture manifest](../tests/fixtures/planning/scenarios.json) records provenance
and archive hashes. The food verification is a hypothetical test assertion, not a
newly verified photograph. The Durga case contains both uncertainty and truncation,
so their separate effects cannot be inferred from that case alone.

## 4. Experiments and findings

### Experiment 1 — Initial six-scenario integration

All six raw responses selected ABSTAIN. Validation produced five REVIEW outcomes;
only the ordinary bicycle remained ABSTAIN. JSON output was structured, but cultural
reasoning included unsupported claims about which foods or scenes belonged in a
target country.

**Finding:** JSON validity and an allowed decision label do not establish cultural
correctness or useful adaptation reasoning.

**Change:** clarify that preserving scene purpose does not require retaining every
ordinary object, and adaptations are contextual suggestions rather than national
rules. [Recorded results](ollama_planner_phase3_20261108/summary.json).

### Experiment 2 — Prompt revisions

The second prompt produced a food proposal, but Qwen sometimes described the
replacement as an object already present. Localization could name the replacement
instead of the source. The bicycle acquired unnecessary cultural doubts and became
REVIEW. All six final outcomes in this iteration were REVIEW.

The third iteration made source/future field meanings more explicit. It produced
four REVIEW outcomes, one ABSTAIN and one rejected response. The injection response
combined ABSTAIN with candidate edits, violating the contract.

**Finding:** longer or clearer prompts do not reliably enforce every cross-field
rule. Fixing one scenario can worsen another. Rejection demonstrated a validation
boundary, not complete prompt-injection resistance.

**Change:** retain exact source-object references and add deterministic checks rather
than depending only on prompt compliance. Evidence: [iteration 2](ollama_planner_phase3_20261108_prompt_v2/summary.json),
[iteration 3](ollama_planner_phase3_20261108_prompt_v3/REPORT.md).

### Experiment 3 — Three real CLI examples

Food, Durga and bicycle all ended in REVIEW. The bicycle's raw ABSTAIN was escalated
because the model added irrelevant doubts about national graffiti styles.

**Finding:** no-change safety is different from permission to edit. Treating every
uncertainty as equally important creates unnecessary review.

**Change:** permit a complete no-edit ABSTAIN despite unrelated descriptive doubts,
while keeping actual proposed edits conservative. [CLI evidence](phase3_step2_three_examples_20261108/REPORT.md).

### Experiment 4 — Original/future consistency review

The first revised prompt still produced malformed field content and all-REVIEW
results; that attempt was preserved. The final consistency run exposed four problems:

1. Food abstained because ramen already belonged to Japan, ignoring India as the
   desired adaptation context.
2. Durga returned REVIEW but retained a proposal to replace the deity's headdress
   and jewelry despite preservation instructions.
3. Its object description was the literal string `"null"`; localization was a whole
   scene paragraph.
4. Bicycle abstained but retained invented cultural verification checks.

**Finding:** the application also contributed to failure. REVIEW was a warning label
without guaranteed removal of unsafe candidates. Nonempty strings and valid lists
could still contain invalid object references or unrelated conditions.

Evidence: [initial revision](planner_quality_review_20261108/comparison.json),
[final consistency review](planner_quality_review_20261108_final/REPORT.md).

### Experiment 5 — Decision-policy correction and candidate quarantine

We inspected exact inputs, prompts, raw responses, contracts and postprocessing
before editing. The inputs correctly expressed source/target context and protection
requests. The observed quoted `"null"` was generated by Qwen; the verified-object ID
in that response was already actual JSON null, not an incorrectly serialized None.

| Failure | Correction |
| --- | --- |
| Source membership used to reject adaptation | Explain original versus desired context; review unassessed target-context rationales without forcing substitutions |
| Unsafe candidates retained in REVIEW | Final REVIEW releases no candidate edits; preserve raw proposals separately |
| Placeholder descriptions and scene localization | Reject placeholders and string-null IDs; enforce a short source-object phrase, at most 16 words / 160 characters |
| Invented verification merely to keep an image unchanged | Normalize final ABSTAIN to a neutral no-action reason and empty edit-check list |
| Unknown IDs or replacements mislabeled as originals | Match IDs/descriptions against supplied verified originals; reject identical source/replacement wording |
| Unresolved user protection constraints | Withhold pending edits for human compatibility checks; do not claim semantic understanding from keywords |

An initial real rerun exposed raw PROPOSE with no candidate. The strict parser first
rejected it. A general regression and coded no-action rule were added: an empty
proposal can resolve only to ABSTAIN, never an invented edit. Truncation, rejected
candidates and unresolved adaptation context can still require REVIEW.

The [failed run](planner_decision_policy_20261108/comparison.json) and
[final policy evidence](planner_decision_policy_20261108_final/REPORT.md) remain separate.

## 5. Final recorded results

| Scenario | Raw decision | Final decision | Final candidates | Request time | Generation time | Input/output tokens |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Japanese meal → India | PROPOSE | REVIEW | 0 | 6.07 s | 3.55 s | 714 / 242 |
| Durga Puja → Japan | REVIEW | REVIEW | 0 | 9.03 s | 5.88 s | 819 / 432 |
| Bicycle → India | PROPOSE | ABSTAIN | 0 | 6.95 s | 3.94 s | 733 / 288 |

Request time includes lookup/loading and response handling. Generation time is
Ollama `eval_duration` converted from nanoseconds, excluding loading/prompt processing.
These are single observations, not a controlled speed benchmark.

### Interpretation and issue codes

**Food:** Qwen considered a target-context replacement but called it the verified
original and repeated it as its own replacement. The candidate was removed using
`SOURCE_OBJECT_MISMATCH`, `SOURCE_REPLACEMENT_IDENTICAL` and
`USER_CONSTRAINTS_UNRESOLVED`. This is a justified validation REVIEW, not a successful
source-grounded cultural adaptation.

**Durga:** the latest raw response already has no candidates. `CAPTION_INCOMPLETE`
and `MODEL_REVIEW_REQUESTED` keep REVIEW. Replaying the previous unsafe draft also
removes its candidate with placeholder, localization, batch-review, truncation and
protection codes. The replay is saved as an offline check, not new model inference.

**Bicycle:** Qwen selected PROPOSE without proposing an actual edit. The application
recorded `PROPOSE_WITHOUT_EDITS` and `ABSTENTION_NORMALIZED`, then returned ABSTAIN
without cultural restrictions or unrelated checks. Its raw contract was invalid
despite a valid final no-action disposition.

**Result:** no unsupported candidate from these final three cases was released
downstream. That demonstrates the policy boundary on these cases; it does not
establish general cultural or visual accuracy.

## 6. Raw output versus validated result

| Record | Purpose |
| --- | --- |
| `response` | Full original Ollama response, text, timing and token metadata |
| `raw_planning_result` | Decoded original model proposal, without silent wording repairs |
| `planning_result` | Final deterministic policy result |
| `validation.issues` | Explicit issue code, severity and candidate index |
| `validation.rejected_candidates` | Rejected original proposals and rejection reasons |
| `validation.raw_schema_valid` | Raw validity, separate from final validity |
| `validation.automatically_authorized` | Always false, including for conditional PROPOSE |

Every audit also records input, exact system/user prompts, schema, settings, resolved
model identity/digest and blank initial human-review notes. Comparing only decisions
is insufficient: an old REVIEW retained an unsafe candidate, while the corrected
REVIEW has an empty array.

## 7. Regression tests

| Milestone | Recorded passing offline tests |
| --- | ---: |
| First real Ollama integration | 41 |
| Consistency review | 53 |
| Final decision-policy validation | 72 |
| Subsequent behavior-preserving cleanup | 72 before / 72 after |

The final validation milestone recorded 53 baseline tests passing in 0.338 seconds
and 72 passing in 0.233 seconds, before the final model reruns. The 19 new regressions
cover source/target confusion, placeholders, null types, localization, protected
content, truncation, verified references, empty proposals, clean abstention and
raw audit preservation. JSON, transport, timeout and existing captioning tests also
passed. These tests use controlled mocks and do not measure cultural accuracy.

The later cleanup additionally compared 33 complete audit replays and six input
fixtures before/after. Prompts, settings, schema, HTTP requests, decisions, issue
codes and quarantine matched. These were offline replays, not new LLM generations.

## 8. Hardware observations

Recorded tests used a 4 GiB RTX 3050 Laptop GPU. Standalone Qwen inference was tested
before cultural scenarios; simultaneous SmolVLM/Qwen residency was not assumed.

An earlier six-case run recorded about 2.01 GiB of Qwen allocation through `/api/ps`
and a largest sampled total GPU usage of 3597/4096 MiB. Global readings included
desktop applications; sampling can miss peaks. These are not isolated tensor peaks
or proof that both models fit together.

Sequential stages, `keep_alive: 0` and explicit unloading were used. Final saved
server snapshots showed no loaded model. See the
[recorded hardware discussion](ollama_planner_phase3_20261108_prompt_v3/REPORT.md).

## 9. Conclusions and remaining limitations

The main improvement was **reliable application disposition and evidence retention**,
not proven improvement in Qwen's cultural reasoning. Prompt changes helped some
responses but did not eliminate source/future confusion, invented facts or unsafe
substitutions. Deterministic quarantine was necessary.

Remaining limitations:

- Valid JSON and verified source IDs do not prove cultural suitability or grounding.
- Short localization can still be wrong or refer ambiguously to multiple objects.
- Reviewed scene summaries can retain inaccurate model claims; they are not visual truth.
- Free-text protection constraints cause conservative review, including some valid
  preferences; arbitrary semantic compatibility is not automatically established.
- The six cases are a small convenience set, with synthetic verification and no
  completed cultural-expert scores. No general accuracy percentage is justified.
- Prompt injection is not completely solved; role separation, schema/reference checks
  and no automatic editing authorization are separate safeguards.
- Grounding DINO, segmentation, inpainting and a complete approval/execution pipeline
  remain unimplemented. No actual image transformation was demonstrated here.

## 10. Evidence files

| Scenario | Original input | Raw LLM output | Final JSON plan | Full audit |
| --- | --- | --- | --- | --- |
| Food | [Input](planner_decision_policy_20261108_final/01_japanese_food.input.json) | [Raw](planner_decision_policy_20261108_final/01_japanese_food.raw.json) | [Final](planner_decision_policy_20261108_final/01_japanese_food.plan.json) | [Audit](planner_decision_policy_20261108_final/01_japanese_food.audit.json) |
| Durga | [Input](planner_decision_policy_20261108_final/02_durga_uncertain_incense.input.json) | [Raw](planner_decision_policy_20261108_final/02_durga_uncertain_incense.raw.json) | [Final](planner_decision_policy_20261108_final/02_durga_uncertain_incense.plan.json) | [Audit](planner_decision_policy_20261108_final/02_durga_uncertain_incense.audit.json) |
| Bicycle | [Input](planner_decision_policy_20261108_final/03_bicycle_no_change.input.json) | [Raw](planner_decision_policy_20261108_final/03_bicycle_no_change.raw.json) | [Final](planner_decision_policy_20261108_final/03_bicycle_no_change.plan.json) | [Audit](planner_decision_policy_20261108_final/03_bicycle_no_change.audit.json) |

Further references: [root-cause analysis](planner_decision_policy_20261108_final/root_cause_analysis.json),
[runtime/decision comparison](planner_decision_policy_20261108_final/comparison.json),
[recorded tests](planner_decision_policy_20261108_final/test_results.json),
[historical-response replay](planner_decision_policy_20261108_final/previous_raw_revalidated.json),
and the broader [project-understanding/interview guide](Planner_Development_and_Validation_Report.md).

This report summarizes the experiments; it does not replace the raw evidence or
justify deleting earlier experiment directories.
