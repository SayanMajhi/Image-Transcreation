# Research reports

Use these consolidated reports as the current reading order:

1. [Research and architecture](phase1_research.md)
2. [VLM selection](phase2_vlm.md)
3. [Cultural planning and validation](phase3_llm.md)
4. [Grounding and box review](phase4_grounding.md)
5. [SAM segmentation and mask review](phase5_segmentation.md)

[Cleanup review](repository_cleanup_review.md) records the current repository audit and regression checks. [Results](../results/) indexes exact historical artifacts.

Older iteration documents, review packages and audit folders remain historical evidence at their original paths. They are not additional current phase reports. Their time-specific implementation statements may be superseded. Pending records remain pending; no cleanup changes a research verdict.
