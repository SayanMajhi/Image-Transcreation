# Phase 4 - iteration 3: explicit human box-review gate

Date: 2026-11-09. **Recommendation: PASS for the narrow implementation and offline regression milestone. Actual human selections remain PENDING.**

This utility reviews saved Grounding DINO predictions without running a model. It does not establish object identity automatically, perform segmentation, authorize cultural editing or start the next phase. **There are no real ACCEPT records in this package.** No human reviewer or inspection confirmation was fabricated.

## 1. Implementation in simple English

Iteration 2 showed why geometry and confidence are insufficient: an airplane query returned the bicycle with score about 0.419. A person must decide whether the intended object is actually inside a particular box. Software can then check that the chosen box is exactly the one recorded.

Added only:

- `scripts/review_grounding.py`: standalone preparation, human-decision submission and candidate revalidation.
- `tests/test_grounding_review.py`: 31 offline tests using synthetic images and synthetic reviewer declarations.

Existing `GroundingResult` and `GroundingDetection` contracts are reused. No existing application, inference, CLI, contract, configuration, planner policy or dependency file changed. The utility imports neither Torch nor Transformers in a fresh-process check. **No additional model inference or download occurred.** The installed Karpathy guidelines informed the small, focused change.

### Prepare: bind evidence, never select

`prepare` reads the original image and saved detection JSON, reconstructs the existing contracts, revalidates all coordinates, checks dimensions and verifies the image SHA-256 against the detection record.

It creates a new directory containing exact-byte input copies, a newly drawn indexed `annotated.png`, and `pending.json`. Existing directories are refused. The original detection file and image remain untouched.

The request stores the exact image, detection-file and annotation hashes. It always starts **PENDING**, with null reviewer, selection, candidate kind and human review timestamp. Inspection declarations and editing permissions are false. The creation timestamp records preparation, not a human event.

### Decide: record an explicit human declaration

| Decision | Meaning | Candidate released? |
|---|---|---|
| PENDING | No human decision submitted; created by `prepare`. | No |
| ACCEPT | A named reviewer explicitly selected one indexed prediction after declaring inspection. | One reviewed segmentation-test candidate |
| REJECT | The reviewer rejects the results for the intended research target. | No |
| NEEDS_REVIEW | Identity, extent or instance selection remains unresolved. | No |

`decide` requires a reviewer name and short explanation. ACCEPT additionally requires an explicit **zero-based array index**, `--inspected-original` and `--inspected-boxes`. Even one detection has no default selection. Zero detections, failed results and partly invalid results cannot be accepted. REJECT and NEEDS_REVIEW cannot select an index.

Before saving, the utility rechecks image/detection/annotation hashes, image dimensions and provenance metadata. It verifies index existence and derives coordinates, score and label directly from that indexed prediction, revalidating coordinates again. There is no editable replacement box, highest-score selection, automatic merge, NMS or confidence-based approval.

The decision must be saved as a new JSON alongside its request so evidence links remain portable. The pending request, source files and all unselected predictions remain unchanged. Selecting one prediction does not accept or reject the others.

### Revalidate the candidate later

`read_candidate(review_path)` returns a `GroundingDetection` only for an ACCEPT record satisfying the inspection declarations, reviewer/explanation, timezone-aware timestamp and exact selected snapshot. It rechecks bound hashes, dimensions, metadata, index and coordinates, compares the selected score/label/box with the original prediction, and verifies the original pending-request hash. Other decisions release nothing.

This helper does not run SAM or implement a pipeline adapter. ACCEPT is called a **reviewed segmentation-test candidate**. Every record retains:

```json
{"image_edit_authorized": false, "cultural_transformation_authorized": false}
```

No review state is planner approval or authorization to modify an image.

## 2. Accepted-record schema

| Required evidence | Fields |
|---|---|
| Exact source image and detection JSON | `original_image_sha256`, `detection_json_sha256` |
| Bound indexed preview | `annotation_sha256` |
| Original dimensions and query | `original_dimensions` (width, height), `source_phrase` |
| Model provenance | `model_id`, `model_revision` |
| Explicit selection | `prediction_indexing`, `selected_prediction_index` |
| Exact XYXY, label and confidence | `selected_prediction.box`, `.label`, `.score` |
| Human decision and explanation | `decision`, `reviewer`, `explanation` |
| Actual review timestamp | `reviewed_at_utc`, generated on submission |
| Inspection declarations | `inspected_original`, `inspected_boxes` |
| Original request audit link | `source_request_file`, `source_request_sha256` on a submitted decision |
| Limited purpose | `candidate_kind: reviewed segmentation-test candidate` for ACCEPT only |
| No editing permission | Both authorization fields remain false |

Changing selected coordinates, score or label causes later validation to fail. Changing bound source bytes, even JSON whitespace, changes their digest and causes failure. Hashes detect changed evidence; they do not authenticate a person or prove semantic truth.

## 3. Actual real-image examples

Four preparation commands were run using saved iteration 2 predictions only. The assistant inspected previews for alignment and wrote separate visual suggestions. This was **not** recorded as a named human's approval.

| Example | Saved predictions retained | Actual decision | Selected index | Reviewer / review timestamp |
|---|---|---|---|---|
| Bicycle query on bicycle | 1 | PENDING | null | null / null |
| Airplane query on bicycle | 1 | PENDING | null | null / null |
| Oil lamp, multiple predictions | 8 | PENDING | null | null / null |
| Durga Puja vessels | 7 | PENDING | null | null / null |

**A. Bicycle:** the saved box plausibly encloses the bicycle. A person may inspect zero-based index **0** and explicitly accept it for future segmentation research. No actual acceptance has been recorded.

**B. Airplane:** the original `airplane` label and score **0.4191797375679016** are retained, even though the box visibly encloses the bicycle. A person can record REJECT for query/object mismatch. `read_candidate` then refuses to return it. Actual state is PENDING; rejection behavior was tested synthetically, without inventing a human rejection.

**C. Oil lamp:** zero-based index **2** appears to enclose the central burning lamp. Older iteration 2 overlays called it box 3 because their numbering was one-based. The new review overlay uses zero-based indices matching the CLI. A person may choose index 2 after inspection; this is a visual suggestion, not an automatic selection. All eight predictions remain in the exact source JSON, including uncertain containers and overlapping extents. The other seven are not silently classified.

**D. Durga Puja:** the original query and labels `clay incense burner` are provenance, not independently verified material or ritual identity. Seven predictions remain, including overlapping edge-vessel boxes. Nothing certifies a dhunuchi or ritual burner. A person may submit NEEDS_REVIEW while identity/extent/instance remains unresolved. Actual state is PENDING.

[Separate assistant guidance](phase4_iteration3_assets/assistant_visual_guidance.json) cannot release a candidate. Actual records, images and exact suggested source coordinates are included in the appendix below.

## 4. Human review instructions

The following commands are **instructions for an actual reviewer; they were not executed to fabricate confirmations**. Replace name/reason placeholders with truthful details after inspection. Run from the project root:

```powershell
$env:PYTHONPATH = (Resolve-Path .\src).Path
$review = "reports/phase4_iteration3_assets/examples/A_bicycle"
Invoke-Item "$review/original.jpg"
Invoke-Item "$review/annotated.png"
```

Inspect both files at full resolution and check the exact array index in `detection.json`. Only if the human agrees, submit:

```powershell
.\.venv\Scripts\python.exe -B scripts/review_grounding.py decide --request "$review/pending.json" --decision ACCEPT --index 0 --reviewer "YOUR NAME" --reason "YOUR OWN EXPLANATION AFTER INSPECTION" --inspected-original --inspected-boxes --out "$review/accepted.json"
```

For the incorrect airplane prediction, after the human's inspection:

```powershell
$review = "reports/phase4_iteration3_assets/examples/B_airplane_negative"
.\.venv\Scripts\python.exe -B scripts/review_grounding.py decide --request "$review/pending.json" --decision REJECT --reviewer "YOUR NAME" --reason "YOUR OWN QUERY-MISMATCH EXPLANATION" --out "$review/rejected.json"
```

For the lamp, inspect all saved predictions first. If the human agrees index 2 is the intended individual lamp:

```powershell
$review = "reports/phase4_iteration3_assets/examples/C_oil_lamp_multiple"
.\.venv\Scripts\python.exe -B scripts/review_grounding.py decide --request "$review/pending.json" --decision ACCEPT --index 2 --reviewer "YOUR NAME" --reason "YOUR OWN OBJECT AND EXTENT EXPLANATION" --inspected-original --inspected-boxes --out "$review/accepted.json"
```

For unresolved vessel identity/extent:

```powershell
$review = "reports/phase4_iteration3_assets/examples/D_vessels_unresolved"
.\.venv\Scripts\python.exe -B scripts/review_grounding.py decide --request "$review/pending.json" --decision NEEDS_REVIEW --reviewer "YOUR NAME" --reason "YOUR OWN UNRESOLVED IDENTITY OR EXTENT EXPLANATION" --out "$review/needs_review.json"
```

Missing selection/inspection declarations make ACCEPT fail explicitly. REJECT and NEEDS_REVIEW take no index and release nothing. Existing outputs cannot be replaced. Corrections require new records, not editing accepted evidence. Do not choose an outcome simply because an example command mentions it.

## 5. Offline tests

| Suite | Tests | Time | Failures/errors | Outcome |
|---|---|---|---|---|
| Before implementation | 95 | 0.588 s | 0 / 0 | OK |
| Final after implementation | 126 | 1.325 s | 0 / 0 | OK |

The 31 added tests cover explicit valid selection of a **lower-scoring** box; rejection; no-detection rejection/refusal of acceptance; invalid/missing indices including boolean and noninteger values; selection required even for one box; changed image/detection/annotation/request hashes; required human details and inspection declarations; PENDING with no fabricated confirmation; NEEDS_REVIEW; nonacceptance releasing nothing; false editing permissions; tampered selected coordinates/score/label; metadata mismatches; malformed JSON/schema/nonfinite JSON; invalid geometry/dimensions; source/request preservation and retention of unselected predictions; refusal to overwrite outputs; immutable prior decisions; CLI behavior and portable evidence locations.

Planner REVIEW/ABSTAIN JSONs are not accepted as detection evidence. All existing planner/quarantine and grounding tests remain unchanged and pass. These are synthetic reviewer declarations on temporary synthetic images, **not real review evidence for the research images**. No accepted test record is presented as an actual human confirmation.

[Before tests](phase4_iteration3_assets/tests_before.txt), [after tests](phase4_iteration3_assets/tests_after.txt), [test summary](phase4_iteration3_assets/test_summary.json), [new tests](phase4_iteration3_assets/implementation/tests/test_grounding_review.py), [CLI/import checks](phase4_iteration3_assets/cli_checks.json).

Help commands for prepare/decide and the existing application CLI succeed. A fresh-process review import reports `torch_loaded: false`, `transformers_loaded: false`. There is no model-loading path in this utility.

## 6. Preservation and Git diff

A pre-change SHA-256 snapshot covered **497 existing files**, including original images/detection JSONs, previous reports and ZIPs, historical research, source/tests/configs/scripts and uncommitted work. All 497 remain byte-identical; none was removed. [Before hashes](phase4_iteration3_assets/preservation_before.json), [after verification](phase4_iteration3_assets/preservation_after.json).

Each prepared detection copy matches the input bytes/hash; image copies match the original input hash. New review overlays draw indices only on copies. Checkpoint revision, processor, defaults (0.30/0.25), query normalization and all saved coordinates/scores/labels remain unchanged.

```text
new scripts/review_grounding.py          215 lines
new tests/test_grounding_review.py       252 lines
new reports/phase4_iteration3_review.md
new reports/phase4_iteration3_assets/
new reports/phase4_iteration3_review.zip
existing files modified:                0
dependencies changed:                   0
new model inference calls:              0
```

[Task-scoped diff summary](phase4_iteration3_assets/git_diff_summary.txt), [new-file diff](phase4_iteration3_assets/implementation/new_files.diff), [initial Git status](phase4_iteration3_assets/initial_git_status.txt). Tracked working-tree changes predate this iteration and were not overwritten. No commit, push, deletion or archive movement occurred.

Code snapshots contain the two new files and unchanged reused [contracts](phase4_iteration3_assets/implementation/src/transcreation/contracts.py). The inference implementation and planner policies were not modified to introduce this gate.

## 7. Remaining limitations

1. Inspection flags are a person's declarations, not proof they looked at an image. Local reviewer names are not authenticated or digitally signed. The tool cannot prevent a caller from lying.
2. Hashes bind evidence bytes after preparation; they do not verify cultural identity or authenticity before preparation. A person with full write access can forge a new chain. No signing/access-control platform was added.
3. **All real examples remain PENDING.** Software tests do not substitute for actual human inspection and selection.
4. No SAM/masks or segmentation-quality measurements exist. A reasonable research box can still cut off bases/thin parts or include background. No IoU, accuracy or ground-truth annotation claim is made.
5. Unselected boxes and semantic uncertainty stay in the source JSON. Choosing one box does not certify cultural names or decide the other predictions.
6. There is no planner-to-review bridge or pipeline integration. REVIEW/ABSTAIN policies remain unchanged. Future consumers must explicitly use the gate and retain the distinction between segmentation research and editing permission.
7. Records are local immutable files, not workflow management. Multiple separately named decisions from a pending request are possible; no automatic latest-decision/supersession policy exists. A future consumer must select an explicit reviewed file, not silently search for a convenient ACCEPT.
8. Old overlays used one-based box numbers; this utility uses zero-based JSON indices. Use the new preview and JSON array. Text can overlap on crowded boxes, so inspect the original and source data as well.

## 8. Recommendation and stopping point

**PASS for this narrow implementation milestone.** Explicit decisions, candidate revalidation, source preservation and offline regressions passed. Actual human verification is still **PENDING**, so this package releases no real reviewed segmentation-test candidate.

The next action is independent mentor/user inspection and, if appropriate, truthful submission of a chosen decision. A person evaluates object identity, extent and intended instance; software checks that the chosen box matches the saved evidence. Neither task authorizes cultural editing.

Stop here. No SAM, diffusion, cultural transformation or automatic integration was started.

## 9. Portable evidence and attribution

The ZIP includes this report, four PENDING requests with exact image/detection copies, zero-based annotations/comparisons, test/CLI/preservation evidence, separate assistant guidance and minimal code snapshots. All report links are relative. No model weights, environments, unrelated datasets or secrets are included.

Attribution from the existing manifest: bicycle by Basile Morin, [Wikimedia source](https://commons.wikimedia.org/wiki/File:Parked_bicycle_with_graffitied_building_facade_and_doors_in_Amsterdam.jpg), [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/); lamps by Benoy, [Wikimedia source](https://commons.wikimedia.org/wiki/File:Diwali_Oil_lamps_Darjeeling.jpg), [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/). Annotation/comparison derivatives retain the corresponding source attribution/license. The Durga image is user-provided research material; author/license was unspecified, so external publication permission remains unverified. This package is for project/mentor review.

## Appendix: actual commands, records and visual evidence

### Exact preparation commands actually used

```powershell
$env:PYTHONPATH = (Resolve-Path .\src).Path
.\.venv\Scripts\python.exe -B scripts/review_grounding.py prepare --detection reports/phase4_iteration2_assets/runs/R01_bicycle_replay/detection.json --image data/vlm_collection/scene_06.jpg --out reports/phase4_iteration3_assets/examples/A_bicycle
.\.venv\Scripts\python.exe -B scripts/review_grounding.py prepare --detection reports/phase4_iteration2_assets/runs/N01_airplane_negative/detection.json --image data/vlm_collection/scene_06.jpg --out reports/phase4_iteration3_assets/examples/B_airplane_negative
.\.venv\Scripts\python.exe -B scripts/review_grounding.py prepare --detection reports/phase4_iteration2_assets/runs/A02_oil_lamp_020/detection.json --image data/vlm_collection/scene_02.jpg --out reports/phase4_iteration3_assets/examples/C_oil_lamp_multiple
.\.venv\Scripts\python.exe -B scripts/review_grounding.py prepare --detection reports/phase4_iteration2_assets/runs/B03_clay_incense_burner_030/detection.json --image data/sample_images/durga.jpg --out reports/phase4_iteration3_assets/examples/D_vessels_unresolved
```

[Preparation log](phase4_iteration3_assets/prepare_commands.json). These are the only real-image review utility calls made; every call was `prepare`, never `decide`.

### A_bicycle

[Original image](phase4_iteration3_assets/examples/A_bicycle/original.jpg) | [Zero-based annotations](phase4_iteration3_assets/examples/A_bicycle/annotated.png) | [Exact detection copy](phase4_iteration3_assets/examples/A_bicycle/detection.json) | [Actual PENDING record](phase4_iteration3_assets/examples/A_bicycle/pending.json)

Detection SHA-256: `424abf5cdd98ad02be3e9ae9e68e40cc9186ba6167874bf5488dbadec94d6992`. Actual state: **PENDING**, selected index null, reviewer null, human review timestamp null. All 1 original predictions remain.

![A_bicycle: original vs indexed preview; nothing selected](phase4_iteration3_assets/examples/A_bicycle/comparison.png)

Prediction at index **0** for a human to inspect (not selected in the record):

```json
{
  "box": [
    441.8973388671875,
    581.3589477539062,
    953.31396484375,
    924.9127197265625
  ],
  "score": 0.9432805180549622,
  "label": "bicycle"
}
```

### B_airplane_negative

[Original image](phase4_iteration3_assets/examples/B_airplane_negative/original.jpg) | [Zero-based annotations](phase4_iteration3_assets/examples/B_airplane_negative/annotated.png) | [Exact detection copy](phase4_iteration3_assets/examples/B_airplane_negative/detection.json) | [Actual PENDING record](phase4_iteration3_assets/examples/B_airplane_negative/pending.json)

Detection SHA-256: `96f33eca9e2a92a2aa15a4dd779238d062abaa1578122124f6abc691634623de`. Actual state: **PENDING**, selected index null, reviewer null, human review timestamp null. All 1 original predictions remain.

![B_airplane_negative: original vs indexed preview; nothing selected](phase4_iteration3_assets/examples/B_airplane_negative/comparison.png)

### C_oil_lamp_multiple

[Original image](phase4_iteration3_assets/examples/C_oil_lamp_multiple/original.jpg) | [Zero-based annotations](phase4_iteration3_assets/examples/C_oil_lamp_multiple/annotated.png) | [Exact detection copy](phase4_iteration3_assets/examples/C_oil_lamp_multiple/detection.json) | [Actual PENDING record](phase4_iteration3_assets/examples/C_oil_lamp_multiple/pending.json)

Detection SHA-256: `ecf6178788fb81e7ebe2ba53b4e87479def087521b35cbdda5d87494526646a6`. Actual state: **PENDING**, selected index null, reviewer null, human review timestamp null. All 8 original predictions remain.

![C_oil_lamp_multiple: original vs indexed preview; nothing selected](phase4_iteration3_assets/examples/C_oil_lamp_multiple/comparison.png)

Prediction at index **2** for a human to inspect (not selected in the record):

```json
{
  "box": [
    631.4442138671875,
    248.13294982910156,
    889.331787109375,
    443.25518798828125
  ],
  "score": 0.31422239542007446,
  "label": "oil lamp"
}
```

### D_vessels_unresolved

[Original image](phase4_iteration3_assets/examples/D_vessels_unresolved/original.jpg) | [Zero-based annotations](phase4_iteration3_assets/examples/D_vessels_unresolved/annotated.png) | [Exact detection copy](phase4_iteration3_assets/examples/D_vessels_unresolved/detection.json) | [Actual PENDING record](phase4_iteration3_assets/examples/D_vessels_unresolved/pending.json)

Detection SHA-256: `4f891891cfabbe2a47b7a9b0df7a701e45e6ee864d53c7e8a4709e2b2012e897`. Actual state: **PENDING**, selected index null, reviewer null, human review timestamp null. All 7 original predictions remain.

![D_vessels_unresolved: original vs indexed preview; nothing selected](phase4_iteration3_assets/examples/D_vessels_unresolved/comparison.png)

### Actual example review record

The oil-lamp request below is actual PENDING evidence, not a simulated acceptance. Creation time is not a human review timestamp.

```json
{
  "schema_version": 1,
  "record_type": "grounding_box_human_review",
  "original_image_sha256": "321c415a72e47d745949c90170c6342f70dafcbbe47380ff4cfaffbaf2b4dfc2",
  "original_dimensions": [
    1280,
    842
  ],
  "source_phrase": "oil lamp",
  "model_id": "IDEA-Research/grounding-dino-tiny",
  "model_revision": "a2bb814dd30d776dcf7e30523b00659f4f141c71",
  "prediction_count": 8,
  "detection_json_sha256": "ecf6178788fb81e7ebe2ba53b4e87479def087521b35cbdda5d87494526646a6",
  "annotation_sha256": "d99ca620c4aa83d65258fd76c4b4f879d5661ebed4cdd94bbdf6bdf7dc1b4ffd",
  "image_file": "original.jpg",
  "detection_file": "detection.json",
  "annotation_file": "annotated.png",
  "prediction_indexing": "zero_based_detections_array",
  "decision": "PENDING",
  "selected_prediction_index": null,
  "selected_prediction": null,
  "candidate_kind": null,
  "reviewer": null,
  "explanation": "Awaiting explicit human review; no selection has been made.",
  "created_at_utc": "2026-11-09T07:39:13.689004+00:00",
  "reviewed_at_utc": null,
  "inspected_original": false,
  "inspected_boxes": false,
  "image_edit_authorized": false,
  "cultural_transformation_authorized": false
}
```

Comparison headers add 40 display pixels; right-panel offsets and headers are not part of the original-image box coordinates. No region is highlighted as accepted.

[Final evidence verification](phase4_iteration3_assets/verification.json): all four PENDING requests reject candidate release, all input copies and bound hashes match, and all 497 baseline files are preserved.

### Optional use of the bundled utility after ZIP extraction

The report and images need no local repository paths. To inspect the bundled command or run its focused tests from the extracted ZIP root, use Python 3.11 with Pillow installed. No Torch, Transformers, Ollama or model weights are required by these focused tests. The package includes the unchanged package marker and contracts for this purpose.

```powershell
$env:PYTHONPATH = "$(Resolve-Path phase4_iteration3_assets/implementation);$(Resolve-Path phase4_iteration3_assets/implementation/src)"
python -B phase4_iteration3_assets/implementation/scripts/review_grounding.py --help
python -B -m unittest discover -s phase4_iteration3_assets/implementation/tests -p test_grounding_review.py -q
```

A reviewer using the extracted copy can replace the script path in the decision instructions with `phase4_iteration3_assets/implementation/scripts/review_grounding.py` and omit the leading `reports/` from review-directory paths. Only make those submissions after actual inspection. The four packaged records themselves remain PENDING.
