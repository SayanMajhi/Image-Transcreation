# Phase 4 - iteration 1: Grounding DINO independent localization review

Date: 2026-11-09. **Recommendation: NEEDS FIXES before downstream integration.**

The standalone implementation and offline regression checks passed. These three runs found plausible source objects, but missed visible repeated instances in two scenes. The religious-object identity remains unverified. Stop here for independent mentor review; this report does not approve any cultural edit or the next development phase.

## 1. Objective and scope

Given an original image and an explicit research phrase, find matching regions and return original-image pixel bounding boxes. There is no connection from planner proposals to this command. No SAM, diffusion, cultural transformation, full-pipeline integration, or automatic editing was added.

SmolVLM, Qwen, planning decisions, candidate quarantine and existing inference settings were left unchanged. The new detector has its own pinned configuration.

## 2. Inspection and baseline

Inspected `src/`, configuration loaders, CLI, contracts, testing fixtures, dependency declarations, source image manifest, reports and existing evidence locations. Reused Pillow image decoding/drawing, dataclasses, YAML loading conventions, argparse, unittest and installed Torch/Transformers. No new dependencies or architectural patterns were needed.

The original `stages/grounding.py` was a docstring-only placeholder. Existing contracts had no bounding-box result type. Existing caption and planning branches remain in place; the independent `ground` branch returns before caption-model imports. No automatic planner adapter was added.

Before implementation, the working tree already contained changes to `reports/README.md` and an untracked `reports/experimentLLM.md`. Both were preserved byte-for-byte. A pre-change snapshot covered 384 existing files: only the four intended application files changed, 380 remained identical, and none disappeared. This includes old results, archived evidence, original images and existing tests. [Preservation check](phase4_grounding_assets/preservation_check.json).

Baseline command: `python -B -m unittest discover -s tests -q`: **72 tests, 0.519 seconds, OK**. This is the actual baseline of this checkout, not an assumed historical count.

## 3. Implementation explained simply

- `GroundingConfig` and `grounding.yaml` hold the new detector's checkpoint, fixed revision, device, thresholds, seed and CPU fallback setting. Existing model/planner YAML files were untouched.
- `GroundingDetection` describes one rectangle, score and returned label. It checks finite numbers, increasing corners, image bounds and score range. `GroundingResult` records dimensions, input hash, settings, status, raw postprocessed predictions, timing and memory.
- `GroundingDetector` loads nothing at construction. On first use it loads the pinned processor and model, checks the loaded model's commit hash, calls `eval()` and runs one image inside `torch.inference_mode()`. Text is lowercased and terminated with a period; the exact normalized prompt is saved.
- The processor may resize the model input. Passing `target_sizes=[(original_height, original_width)]` converts its normalized predictions back into original-image pixel coordinates. The public dimensions are saved in width/height order, while the processor expects height/width order.
- Empty, placeholder and non-text queries are rejected. A planner object, including REVIEW or ABSTAIN, is not a valid input. Manually supplied research queries are not user-approved cultural edits. There is no executable planner-to-detector bridge.
- All processor-returned boxes above the configured threshold are retained if valid. There is no custom top-one selection, instance deduplication, extra NMS, threshold sweep or manual box insertion. Repeated objects remain separate detections.
- Invalid coordinates/scores are excluded from validated detections and retained in the audit with `INVALID_BOX_OR_SCORE`. Non-finite raw values use explicit string spellings such as `nan` so the audit remains valid JSON. `INVALID_OUTPUT` prevents treating a partly invalid result as a clean success.
- `NO_DETECTIONS` means a completed run found no above-threshold boxes. `ERROR` means the stage failed, with an explicit `GROUNDING_ERROR`. These are different outcomes. A completed `DETECTED` status only describes numeric detections; it does not establish semantic correctness.
- CUDA is preferred. CUDA unavailability can fall back to CPU; CUDA OOM releases model references/cache and retries once on CPU when enabled. Other CUDA errors remain explicit errors. The CLI closes the model in `finally`, and each real experiment uses a separate process.
- `save_grounding_artifacts` creates a new output directory, checks the source hash, draws on a copy, and saves original/annotated/comparison PNGs plus JSON. Existing output directories are refused. Original JPEGs were not changed.

Implementation snapshots and tests are included under [implementation](phase4_grounding_assets/implementation/src/transcreation/stages/grounding.py). No old inference or planner logic was refactored.

## 4. Updated directory tree

```text
MiniProject/
|-- configs/
|   |-- models.yaml                  unchanged SmolVLM settings
|   |-- planner.yaml                 unchanged Ollama settings
|   `-- grounding.yaml               new pinned detector settings
|-- src/transcreation/
|   |-- cli.py                       existing commands + independent ground
|   |-- config.py                    existing settings + GroundingConfig
|   |-- contracts.py                 existing contracts + detection records
|   |-- pipeline.py                  unchanged caption entry point
|   `-- stages/
|       |-- caption.py               unchanged SmolVLM
|       |-- planning.py              unchanged policies/mock
|       |-- ollama_planner.py        unchanged Qwen adapter
|       `-- grounding.py             implemented standalone detector
|-- tests/
|   |-- fixtures/                    unchanged
|   `-- test_grounding.py            23 new offline tests
|-- data/                            original images unchanged
|-- outputs/                         previous evidence unchanged
|-- reports/
|   |-- phase4_grounding_review.md    this consolidated review
|   |-- phase4_grounding_assets/      results, images, settings, test evidence
|   `-- phase4_review_package.zip     portable review package
|-- .local_archive/                  unchanged
|-- README.md                        current stage and command documented
`-- pyproject.toml                   unchanged dependencies
```

Other existing modules and reports remain; the tree highlights this milestone. Pre-existing segmentation/inpainting docstring placeholders were not implemented or expanded.

## 5. Model, API and effective configuration

Checkpoint: **IDEA-Research/grounding-dino-tiny**. Resolved, pinned revision: **a2bb814dd30d776dcf7e30523b00659f4f141c71**. Resolved through the Hugging Face model API before downloading; checked against `model.config._commit_hash` during loading.

Installed Transformers **4.57.6** was retained. Its installed processor source/signature was inspected before implementation. It accepts `threshold`, not `box_threshold`, in `post_process_grounded_object_detection`. Code passes `threshold=0.30`, `text_threshold=0.25`, `input_ids`, and original `(height, width)`. Returned `text_labels` are used directly; labels are not replaced with the requested phrase.

All three runs used **box threshold 0.30, text threshold 0.25, seed 42, batch size 1, FP32, CUDA, eval mode, inference mode**. `disable_custom_kernels=True` selects the Torch implementation and avoids Windows compiled-extension requirements. No settings were tuned between images. No model was substituted.

Processor configuration: shortest edge 800, longest edge 1333, bilinear resampling, rescale 1/255, ImageNet normalization, padding enabled. Each JSON contains the effective image processor dictionary and exact normalized prompt. [Effective YAML](phase4_grounding_assets/grounding.yaml) and [environment/API metadata](phase4_grounding_assets/metadata.json).

Official references: [Transformers Grounding DINO documentation](https://huggingface.co/docs/transformers/model_doc/grounding-dino), [checkpoint repository](https://huggingface.co/IDEA-Research/grounding-dino-tiny/tree/a2bb814dd30d776dcf7e30523b00659f4f141c71). The installed signature, rather than assumptions about another version's documentation, determined the actual call.

## 6. Exact experiment CLI commands

Run from the project root in PowerShell with the existing Python 3.11 environment:

```powershell
$env:PYTHONPATH = (Resolve-Path .\src).Path
.\.venv\Scripts\python.exe -B -m transcreation.cli ground --image data/vlm_collection/scene_06.jpg --phrase bicycle --out reports/phase4_grounding_assets/A_bicycle
.\.venv\Scripts\python.exe -B -m transcreation.cli ground --image data/vlm_collection/scene_02.jpg --phrase 'oil lamp' --out reports/phase4_grounding_assets/B_oil_lamp
.\.venv\Scripts\python.exe -B -m transcreation.cli ground --image data/sample_images/durga.jpg --phrase 'incense burner' --out reports/phase4_grounding_assets/C_incense_burner
```

The recorded output paths already exist; choose new `--out` directories for any independently authorized rerun. First-use checkpoint download was completed before timed inference. The installed legacy `transcreate.exe` launcher was not relied upon; source-module commands avoid its known stale entry-point issue.

Before the first run, `GET http://localhost:11434/api/ps` returned `{"models": []}`. Qwen was not resident and needed no unloading request. None of these experiment processes imported or instantiated SmolVLM. Model imports were checked separately later without inference. No expensive old-model inference was rerun.

## 7. Experiment comparison: measured results

| Scene | Exact query | Status | Boxes | Load seconds | Inference seconds | Total stage seconds | Peak allocated CUDA MiB |
|---|---|---|---|---|---|---|---|
| Parked bicycle | `bicycle` | DETECTED | 1 | 12.574 | 1.599 | 14.283 | 1740.19 |
| Diwali lamps | `oil lamp` | DETECTED | 1 | 10.900 | 1.513 | 12.532 | 1892.54 |
| Durga Puja | `incense burner` | DETECTED | 5 | 10.675 | 1.304 | 12.095 | 1814.33 |

All detections passed finite-coordinate, order, boundary and score checks. All three runs used CUDA, with no reported OOM, fallback or model error. No boxes were inserted or relabeled manually.

Inference time brackets the model forward call with CUDA synchronization. Total stage time includes loading, preprocessing, inference and postprocessing, but excludes image decoding before the timer, Python startup, prior checkpoint download and artifact rendering. These are one-run observations, not averaged latency benchmarks.

Peak allocated memory is measured with `torch.cuda.max_memory_allocated()`: reset after loading, includes resident detector tensors and inference/postprocessing allocations, and excludes other applications, CUDA driver/context overhead and reserved-but-unused allocator memory. All loading peaks were **692084224 bytes (660.023 MiB)**. Exact byte counts and detailed timings are in each JSON. The global `nvidia-smi` reading is not the same measurement.

## 8. Actual predicted coordinates, labels and scores

The tables display rounded coordinates for readability; JSON files retain full floating-point precision and processor order. Scores are model confidence outputs, not measured accuracy or calibrated probabilities.

### Parked bicycle

Original input: `data/vlm_collection/scene_06.jpg`, dimensions **1280 x 966** (width x height).

SHA-256: `e0fa05019d587cc62b1d4d5a82d7440216b5d88ef0f2149a69f2eb2ee640fca0`

| Index | XYXY original pixels (rounded to 3 decimals) | Returned label | Score |
|---|---|---|---|
| 1 | [441.897, 581.359, 953.314, 924.913] | bicycle | 0.943280518 |

Full-precision predictions, processor settings, timing, memory and validation observations: [detection JSON](phase4_grounding_assets/A_bicycle/detection.json). Observations: `[]`.

### Diwali lamps

Original input: `data/vlm_collection/scene_02.jpg`, dimensions **1280 x 842** (width x height).

SHA-256: `321c415a72e47d745949c90170c6342f70dafcbbe47380ff4cfaffbaf2b4dfc2`

| Index | XYXY original pixels (rounded to 3 decimals) | Returned label | Score |
|---|---|---|---|
| 1 | [631.444, 248.133, 889.332, 443.255] | oil lamp | 0.314222395 |

Full-precision predictions, processor settings, timing, memory and validation observations: [detection JSON](phase4_grounding_assets/B_oil_lamp/detection.json). Observations: `[]`.

### Durga Puja

Original input: `data/sample_images/durga.jpg`, dimensions **980 x 692** (width x height).

SHA-256: `c43e0c3f07b88a310d0e120e7aa32ea5a29cecba37747015bcdec75c284e5ab0`

| Index | XYXY original pixels (rounded to 3 decimals) | Returned label | Score |
|---|---|---|---|
| 1 | [432.901, 318.794, 516.653, 390.961] | incense burner | 0.416083962 |
| 2 | [0.506, 216.004, 95.623, 294.683] | incense burner | 0.423855841 |
| 3 | [141.255, 279.783, 221.294, 346.891] | incense burner | 0.413017392 |
| 4 | [752.651, 250.714, 846.418, 345.236] | incense burner | 0.372171193 |
| 5 | [283.331, 315.683, 365.126, 380.855] | incense burner | 0.386055857 |

Full-precision predictions, processor settings, timing, memory and validation observations: [detection JSON](phase4_grounding_assets/C_incense_burner/detection.json). Observations: `[]`.

## 9. Original and annotated visual evidence

Originals were opened and the three generated side-by-side images were visually inspected. Left is the decoded original; right is its copy with all validated predictions. The 40-pixel comparison title strip is not part of the original image or the recorded box coordinates.

### Parked bicycle

[Exact input JPEG](phase4_grounding_assets/A_bicycle/source.jpg) | [Decoded original copy](phase4_grounding_assets/A_bicycle/original.png) | [Annotated copy](phase4_grounding_assets/A_bicycle/annotated.png)

![Parked bicycle: original on left, model boxes on right](phase4_grounding_assets/A_bicycle/comparison.png)

### Diwali lamps

[Exact input JPEG](phase4_grounding_assets/B_oil_lamp/source.jpg) | [Decoded original copy](phase4_grounding_assets/B_oil_lamp/original.png) | [Annotated copy](phase4_grounding_assets/B_oil_lamp/annotated.png)

![Diwali lamps: original on left, model boxes on right](phase4_grounding_assets/B_oil_lamp/comparison.png)

### Durga Puja

[Exact input JPEG](phase4_grounding_assets/C_incense_burner/source.jpg) | [Decoded original copy](phase4_grounding_assets/C_incense_burner/original.png) | [Annotated copy](phase4_grounding_assets/C_incense_burner/annotated.png)

![Durga Puja: original on left, model boxes on right](phase4_grounding_assets/C_incense_burner/comparison.png)

## 10. Visual assessment and failure analysis

These are subjective visual assessments of the supplied images, not independently annotated ground truth.

| Question | Bicycle | Oil lamp | Incense burner |
|---|---|---|---|
| Intended object found? | One box appears to enclose the visible bicycle. | Central burning lamp appears localized. | Five boxes align with held bowl-shaped vessels matching the research query visually. Their exact function/name is not verified. |
| Position and extent | Covers wheels, frame, handlebar and saddle closely. | Covers the central bowl/flame region reasonably closely; small support/context may extend beyond it. | Covers the bowl bodies; some stems/handles are outside boxes. The leftmost object is partly cropped by the image itself. |
| Excess background | Some wall/pavement inside the rectangular envelope; a box cannot follow spokes/frame contours. | Some nearby tray/rice background; substantially less than the full scene. | Modest smoke/sky/hand context around some vessels; no box encloses the whole scene. |
| Missed instances | No other clearly visible bicycle noticed. | Several other visible lamps were missed, including lamps behind/left/right of the selected one. | A further bowl-shaped vessel at the far-right edge appears unboxed. |
| Unrelated detections | None obvious on visual inspection. | None obvious; the one box matches a lamp. | No obvious boxes on the deity or people as whole objects; query-specific identity remains uncertain. |
| Multiple valid detections? | Only one returned. | Only one returned despite repeated visible objects. | Five distinct plausible instances returned and all retained. No arbitrary single-instance choice. |

Lamp confidence is only about 0.314, slightly above the 0.30 box threshold. A detection is present, but coverage of repeated lamps is poor at these initial settings. The incense-burner scores are about 0.372-0.424: plausible localization does not settle a culturally specific object identity. No threshold sweep or relabeling was performed to improve these findings.

There are no independent ground-truth boxes or cultural identity annotations. IoU, precision, recall and quantitative detection accuracy are therefore not reported. The observations above cannot establish exhaustiveness or prove the absence of false positives.

## 11. Hardware and runtime observations

Actual device reported by both NVIDIA tooling and Torch: **NVIDIA GeForce RTX 3050 Laptop GPU**, approximately 4 GB VRAM. This differs from the requested context's **3050 Ti**; the measured name is retained. Before the first run `nvidia-smi` reported **4096 MiB total, 1735 MiB globally used**. An earlier inspection reported 1779 MiB used; unrelated application usage varies.

Environment: Python 3.11.9; Torch **2.15.0+cu132**; CUDA runtime **13.2**; Transformers 4.57.6; Pillow **13.0.0**; PyYAML **6.0.3**. Python's platform string is archived exactly; Windows 11 can report an NT 10.0-based string.

Each experiment loaded the detector in a new process. We did not test simultaneous SmolVLM/Qwen/detector residency and do not claim it fits. Sequential stages remain the appropriate conservative strategy on this device. CPU fallback and CUDA failures were exercised with mocks only; real CPU inference latency was not measured. After each CLI run, the detector was closed and the process exited.

## 12. Before/after tests and compatibility

| Suite | Tests | Seconds | Outcome |
|---|---|---|---|
| Before implementation | 72 | 0.519 | OK, 0 failures/errors |
| After implementation, final recorded run | 95 | 0.494 | OK, 0 failures/errors |

The 23 added offline tests cover dimensions and original-size postprocessing arguments; valid/invalid/non-finite/out-of-bounds coordinates; score range; no/multiple detections; rejected predictions and JSON audits; empty/placeholder queries; refusal of REVIEW/ABSTAIN planner objects; visualization/source protection; lazy pinned loading; revision mismatch; inference mode; loading errors; CUDA OOM retry, other CUDA errors and CUDA-unavailable fallback behavior; and threshold validation. They do not download weights.

All 72 existing tests remained in the suite, including planning contracts, PROPOSE/REVIEW/ABSTAIN policy, quarantine and previous JSON/transport cases. Existing source audit/serialization behavior was not changed. Four help commands (root, caption, plan, ground) exited successfully; existing caption/planner modules and all three configuration loaders imported/loaded successfully without inference.

[Test summary](phase4_grounding_assets/test_summary.txt), [structured test evidence](phase4_grounding_assets/test_summary.json), [CLI/import/configuration checks](phase4_grounding_assets/compatibility_checks.json), [new offline tests](phase4_grounding_assets/implementation/tests/test_grounding.py).

No real SmolVLM or Qwen inference was rerun; their runtime equivalence is not experimentally claimed. Their source bytes, configuration and old fixtures/results are preserved and regression checks passed.

## 13. Git diff and dependency summary

Task-specific tracked diff plus new files:

```text
 README.md                             |  25 +++--
 src/transcreation/cli.py              |  32 ++++++
 src/transcreation/config.py           |  39 ++++++++
 src/transcreation/contracts.py        |  53 ++++++++++
 src/transcreation/stages/grounding.py | 178 +++++++++++++++++++++++++++++++++-
 5 files changed, 318 insertions(+), 9 deletions(-)

New implementation files (not included in tracked git diff):
configs/grounding.yaml
tests/test_grounding.py

New evidence: reports/phase4_grounding_review.md, reports/phase4_grounding_assets/, reports/phase4_review_package.zip

Pre-existing user changes excluded: reports/README.md, reports/experimentLLM.md

```

The tracked diff excludes the user's pre-existing report changes. New test/config/evidence files are untracked until the user decides to add them; ordinary `git diff --stat` does not count their contents. No automatic commit, push, deletion or archive movement occurred. No dependencies were installed or changed; the checkpoint resides in the existing Hugging Face cache outside the review ZIP.

[Tracked source diff](phase4_grounding_assets/implementation/tracked_changes.diff) and [diff summary](phase4_grounding_assets/git_diff_summary.txt). Source snapshots are included for independent review; the ZIP does not contain model weights or the virtual environment.

During implementation, small audit/error-path hardening changes were made after the real run processes had started: JSON-safe non-finite audit values, CUDA-unavailable error handling, OOM temporary-reference clearing and single-read source verification. They do not change the successful detection path or these recorded predictions. The final offline suite covers the final code. The three successful experiments were not repeated merely for these error-path changes.

## 14. Evidence provenance and portability

The ZIP contains this report, all three full-precision detection JSONs, comparison/annotated/original PNGs, exact input JPEG bytes, effective YAML, environment/API metadata, test and compatibility evidence, preservation summary and relevant code/test snapshots. Report links use relative paths that work after extraction. `source.jpg` in each experiment matches the SHA-256 of the actual input; `original.png` is a decoded RGB copy and has a different file hash by design.

Bicycle: [Wikimedia source](https://commons.wikimedia.org/wiki/File:Parked_bicycle_with_graffitied_building_facade_and_doors_in_Amsterdam.jpg), Basile Morin, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Diwali lamps: [Wikimedia source](https://commons.wikimedia.org/wiki/File:Diwali_Oil_lamps_Darjeeling.jpg), Benoy, [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/). These source/author/license records come from the existing project image manifest. Annotation/comparison derivatives retain the respective source attribution and share-alike license. Durga image: user-provided local research image; author/license not specified in the existing evidence. Confirm permission before external publication; the package is for mentor review.

No model weights, caches, environments, unrelated datasets or secrets were included. Existing research evidence was not overwritten or relocated.

## 15. Limitations and problems requiring correction

1. **Incomplete repeated-object coverage:** several lamps and one apparent edge vessel were missed. Review and annotate intended instances before deciding whether later controlled localization experiments are needed. This milestone did not tune thresholds.
2. **Object identity is not verified:** text-conditioned boxes cannot confirm the cultural/religious role of a held vessel. Keep that uncertainty and require human verification. These research queries carry no edit authorization.
3. **Instance ambiguity:** multiple plausible boxes remain multiple. A future, separately reviewed selection policy would need explicit user intent/verification; no automatic selection was added here.
4. **Boxes are coarse:** they include background and sometimes omit supports. They are not segmentation masks. Do not use them as proof of pixel-accurate object extent.
5. **Limited evaluation:** three single runs, no ground-truth boxes, no negative real image/query pair, no measured CPU fallback run and no repeated-run reproducibility benchmark. Offline no-detection/error tests are not evidence of real-world accuracy.
6. **Numeric checks have a narrow role:** they reject malformed coordinates, not semantic mismatches, missed objects or culturally inappropriate interpretations. `INVALID_OUTPUT` preserves rejected raw predictions without allowing them into the validated box list.
7. **Resource observations are local:** tensor allocation peaks exclude other programs and driver memory. Concurrent model loading was deliberately not attempted. GPU identity differs from the initial hardware description.
8. **CLI installation remains an existing environment concern:** source-module commands work; a stale installed launcher may require an intentional editable reinstall later. No generated installation metadata was modified here.

## 16. Recommendation and learning takeaway

**NEEDS FIXES before downstream integration**, because object coverage and cultural identity/instance verification need mentor review. The independent detector, output validation, evidence collection and offline regression milestone are complete; there is no installation or CUDA execution blocker for the three recorded runs.

The key lesson: captioning describes a scene, planning suggests possible changes, and grounding only asks "where might this named source object be?" A high score and valid rectangle do not verify an object's meaning or approve an edit. Keep the original image, exact query, model revision and raw predictions alongside the visual evidence so another person can challenge the result.

Stop after this package. No SAM, diffusion, integration, threshold tuning or next milestone was started.
