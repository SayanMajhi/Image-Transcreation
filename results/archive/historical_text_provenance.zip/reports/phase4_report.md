# Phase 4: object localization and explicit box review

## Purpose of these notes

This report explains what we implemented, what our experiments showed, why we added human review, and how to present the work. It consolidates the three Phase 4 iterations using their saved evidence. No models or tests were rerun to write these notes.

**Current achievement:** we can independently locate possible objects from an image and a text query, save the evidence, and prepare an explicit human review of a particular prediction.

**Current boundary:** we have not implemented SAM, diffusion, image transformation or automatic planner-to-grounding integration. The real review examples are still PENDING. No actual human acceptance is claimed.

## 1. Where Phase 4 fits in our project

Our long-term project is culture-aware image transcreation: adapting selected visual details while preserving the scene's purpose and important relationships.

| Component | Simple explanation | Current status |
|---|---|---|
| SmolVLM-500M | Describes what an image may contain. | Implemented before Phase 4 |
| Qwen2.5-3B through Ollama | Suggests possible cultural adaptations from the supplied context. | Implemented before Phase 4 |
| Planning validator | Checks proposals and keeps unsafe or unresolved candidates out of the final actionable list. | Implemented before Phase 4 |
| Grounding DINO Tiny | Finds possible locations of a named source object. | Implemented and experimentally evaluated |
| Explicit box review | Lets a person select one saved prediction or decline to select anything. | Implemented; actual example decisions remain PENDING |
| SAM | Would turn a chosen region into an object mask. | Not implemented or run |
| Diffusion inpainting | Would generate replacement pixels inside a permitted region. | Not implemented or run |

For example, a future planning stage might discuss changing an item in a meal. Before any editing, we would need to identify the **original item** in the image. Phase 4 investigates that localization problem. Finding a rectangle does not itself approve the proposed cultural change.

The current grounding command accepts an explicit research phrase. It does not automatically read a planner proposal, take a quarantined candidate, or override a planner REVIEW/ABSTAIN decision.

## 2. The story of Phase 4

We worked through three questions:

1. **Can the detector find a named object on our hardware?** We implemented independent localization and tested three images.
2. **Why were some repeated objects missed?** We compared a fixed set of query phrases and thresholds, then added a negative control.
3. **How should we handle a valid-looking but incorrect box?** We added an explicit review gate rather than interpreting confidence as approval.

The important research progression was:

> Find boxes -> inspect misses -> expose false matches -> require an explicit, evidence-bound human selection.

We did not resolve the false detection by hiding it, relabeling it or changing the model after seeing the result.

## 3. What object localization means

Localization answers: **"Where might the object described by this phrase be in the original image?"**

Inputs are an image, a phrase such as `bicycle`, and configurable thresholds. Outputs include rectangles, model scores, returned text labels and audit metadata.

Each rectangle is stored as:

```text
[x_min, y_min, x_max, y_max]
```

The top-left image corner is the origin. X increases to the right; Y increases downward. The coordinates are measured in **original-image pixels**, not the resized model-input dimensions.

Our saved bicycle prediction illustrates the format:

```json
{
  "box": [441.8973388671875, 581.3589477539062, 953.31396484375, 924.9127197265625],
  "score": 0.9432805180549622,
  "label": "bicycle"
}
```

The original bicycle image is 1280 x 966 pixels. This rectangle appears to cover its wheels, frame, handlebar and saddle reasonably well. It also contains wall and pavement because a rectangle cannot follow an object's exact outline.

**A bounding box is not a segmentation mask.** A mask would identify individual object pixels; we have not produced those masks.

## 4. Model and implementation details

| Setting | Recorded value |
|---|---|
| Model | `IDEA-Research/grounding-dino-tiny` |
| Pinned checkpoint revision | `a2bb814dd30d776dcf7e30523b00659f4f141c71` |
| Python | 3.11.9 |
| Transformers | 4.57.6 |
| Torch in the recorded environment | `2.15.0+cu132` |
| Actual GPU | NVIDIA GeForce RTX 3050 Laptop GPU, approximately 4 GB VRAM |
| Device / precision / batch size | CUDA / FP32 / 1 |
| Default box threshold | 0.30 |
| Default text threshold | 0.25 |
| Seed | 42 |
| Execution | `model.eval()` and `torch.inference_mode()` |
| Custom kernels | Disabled; Torch implementation used |

The measured GPU name was RTX 3050 Laptop GPU, rather than the earlier user-supplied description of a 3050 Ti. Our reports retain the actual measured name.

### Why pin a revision?

A model name can point to changing repository contents. A pinned commit identifies the exact checkpoint revision we intended to use. The loader checks the loaded model's commit hash against that revision. This helps another researcher reproduce the setup.

### How loading works

We use Hugging Face `AutoProcessor` and `AutoModelForZeroShotObjectDetection`. Model construction is lazy: creating the detector object does not download or load its weights immediately. The first detection loads them.

`eval()` puts the model in evaluation mode. `torch.inference_mode()` disables gradient tracking for the forward pass. We are performing inference, not training or fine-tuning.

CUDA is preferred. CUDA unavailability or an out-of-memory event can trigger the configured CPU fallback. Other failures are recorded explicitly. Real experiment runs succeeded on CUDA; CPU fallback was tested with mocks, not benchmarked on the real images.

### Processor and API compatibility

The installed Transformers processor API was inspected before implementation. In version 4.57.6, postprocessing takes the box threshold through the argument **`threshold`**, rather than `box_threshold`:

```python
processor.post_process_grounded_object_detection(
    outputs,
    input_ids=inputs["input_ids"],
    threshold=config.box_threshold,
    text_threshold=config.text_threshold,
    target_sizes=[(original_height, original_width)],
)
```

The processor resizes the input for inference. Supplying original `(height, width)` in `target_sizes` maps output boxes back to original-image coordinates. Public dimensions are saved as `(width, height)`, so getting the order right matters.

The recorded preprocessing uses shortest edge 800, longest edge 1333, rescaling by 1/255, normalization and padding. These settings stayed fixed across the controlled experiment.

### What the two thresholds do

| Threshold | Meaning in this implementation | What it does not prove |
|---|---|---|
| Box threshold | Filters candidates using their model-produced scores. Lowering it admits weaker predictions. | That every admitted rectangle contains the requested object |
| Text threshold | Controls which text tokens contribute to the decoded returned label. | That a cultural name or object identity is correct |

At box threshold 0.20 and text threshold 0.25, a box can pass while no text token passes the text threshold. Its returned label may be empty. We preserve that empty label rather than inventing a replacement.

Scores are model outputs. A score of 0.943 is **not a measured 94.3% detection accuracy** or a verified probability that the label is true.

## 5. What each relevant file contributes

```text
MiniProject/
|-- configs/grounding.yaml
|-- src/transcreation/
|   |-- cli.py
|   |-- config.py
|   |-- contracts.py
|   `-- stages/grounding.py
|-- scripts/
|   |-- evaluate_grounding_iteration2.py
|   `-- review_grounding.py
|-- tests/
|   |-- test_grounding.py
|   `-- test_grounding_review.py
|-- data/                              original images
|-- outputs/                           separate runs and demonstrations
`-- reports/
    |-- phase4_report.md               these learning notes
    |-- phase4_grounding_review.md     iteration 1 evidence
    |-- phase4_iteration2_review.md    controlled experiment evidence
    |-- phase4_iteration3_review.md    review-gate evidence
    `-- phase4_*_assets/               saved JSON, images, settings and tests
```

| File | Responsibility |
|---|---|
| `configs/grounding.yaml` | Stores detector checkpoint, revision, thresholds, seed, device and fallback setting. |
| `config.py` | Loads and checks those settings using `GroundingConfig`. |
| `contracts.py` | Defines `GroundingDetection` and `GroundingResult`; validates box geometry and numeric scores. |
| `stages/grounding.py` | Loads the detector, processes image/query inputs, obtains predictions, validates boxes and saves annotated copies. |
| `cli.py` | Exposes the independent `ground` command alongside the existing caption and plan commands. |
| `evaluate_grounding_iteration2.py` | Runs the fixed research conditions sequentially while reusing one loaded detector. |
| `review_grounding.py` | Prepares PENDING evidence, records explicit human decisions and rechecks accepted research candidates. |
| `test_grounding.py` | Tests localization contracts and failure paths using mocks. |
| `test_grounding_review.py` | Tests explicit selection, decision states, hashes, audit preservation and candidate-release restrictions. |

The review utility is a standalone research script; it does not change the detector's behavior.

## 6. Iteration 1: independent localization

### Question

Could Grounding DINO Tiny return usable original-image boxes on our 4 GB GPU?

We tested three existing images with identical thresholds: box 0.30, text 0.25.

| Scene | Query | Returned boxes | Observed result |
|---|---|---:|---|
| Parked bicycle | `bicycle` | 1 | Plausible box around the visible bicycle; score 0.943281. |
| Diwali lamps | `oil lamp` | 1 | Central lamp localized at 0.314222; several other visible lamps missed. |
| Durga Puja | `incense burner` | 5 | Plausible held-vessel regions, scores about 0.372-0.424; an apparent right-edge vessel missed. |

The vessel query was an experimental phrase. A returned label did not verify the objects' ritual names or functions.

### Engineering checks

We checked finite coordinates, positive dimensions, ordered corners, image boundaries and score range [0,1]. Empty/placeholder queries are rejected. Explicit statuses distinguish `DETECTED`, `NO_DETECTIONS`, `INVALID_OUTPUT` and `ERROR`.

Invalid predictions are kept in the raw audit with rejection issues rather than silently converted into valid boxes. Valid repeated detections are retained; we do not choose just one automatically.

The suite increased from **72 to 95 passing tests**, adding 23 localization tests.

### What we learned

Independent localization was feasible, but finding one object did not demonstrate complete coverage. We needed to investigate missed instances before treating the output as reliable input for another stage.

[Iteration 1 report](phase4_grounding_review.md) and [review ZIP](phase4_review_package.zip).

## 7. Iteration 2: controlled missed-object analysis

### Question and experimental controls

Were missed objects below the score cutoff, and did the supplied query wording affect the predictions?

We predeclared exactly eight conditions: two images, two phrases per image and two box thresholds. Text threshold stayed at 0.25. Checkpoint, processor, device, precision and seed stayed fixed. We did not add new phrases or thresholds after seeing the results.

One loaded model was reused sequentially. The experiment also included the requested airplane negative control and one unchanged positive bicycle replay to check baseline reproducibility: **10 forward calls total**.

### Actual counts

| Image | Query | Boxes at 0.30 | Boxes at 0.20 | Interpretation from visual inspection |
|---|---|---:|---:|---|
| Lamps | `oil lamp` | 1 | 8 | Additional lamp regions, but also ambiguous containers and overlapping predictions. |
| Lamps | `diya` | 5 | 13 | Some plausible lamps, but fruit-like regions, other objects and an almost-whole-image box also appeared. |
| Vessels | `incense burner` | 5 | 8 | Edge vessel recovered, with duplicate extents and an unrelated decorated idol region. |
| Vessels | `clay incense burner` | 7 | 8 | Edge vessel appeared above 0.30, but two boxes covered that same apparent instance; lowering added another doubtful region. |

These are **prediction counts, not counts of correctly identified unique objects**. We had no independently annotated ground-truth boxes, so we did not calculate recall, precision, IoU or accuracy.

All 57 returned predictions across the 10 calls passed numeric validation. Some were still semantically wrong.

### Why the edge vessel was missed

For the query `incense burner`, the two recovered edge-vessel predictions scored approximately **0.270615** and **0.295206**. Both are below 0.30, so the original cutoff filtered them out.

With the specified phrase `clay incense burner`, corresponding edge-region predictions scored about **0.326066** and **0.328748**, crossing 0.30. This demonstrates query sensitivity in this experiment. It does not establish that the vessel is clay or verify its ritual identity.

### Why lowering the threshold was not a universal fix

Lowering the threshold recovered weaker candidates, but also admitted broad regions, unrelated objects and duplicate boxes. Some low-threshold outputs had empty labels: four for `oil lamp`, six for `diya`, and one for `clay incense burner`.

We retained all results and kept the default **0.30/0.25** unchanged. We did not optimize for the maximum number of boxes.

### The most important failure: negative control

Before inference, the bicycle scene was inspected: no recognizable airplane was visible. Querying `airplane` nevertheless returned a box around the bicycle with score **0.4191797375679016** and label **airplane**.

The box was finite, ordered and inside the image. Numeric validation correctly passed, but the query/object match was visibly wrong.

That score was higher than the original central-lamp score of 0.314. Confidence alone therefore could not provide a dependable semantic acceptance rule in these examples. One negative-control failure does not measure general false-positive performance or fully explain the model's internal cause.

### Reproducibility and performance

The bicycle, original lamp and original vessel predictions reproduced **exactly**, including coordinates, labels and scores.

Loading the detector once took about **12.56 seconds** in iteration 2. Subsequent warm forward calls were roughly **0.43-0.51 seconds**, while the initial bicycle/lamp calls were slower because of loading/shape warm-up effects. Fixed order and single measurements prevent a rigorous latency comparison between thresholds.

Peak allocated CUDA memory was about **1740-1892 MiB**, including resident detector tensors. This excludes other applications and driver/context overhead; it is not total GPU memory use. All real calls succeeded on CUDA without fallback. We did not test concurrent SmolVLM, Qwen and detector residency.

All **95 offline tests** still passed. No application behavior changed during this experiment.

### What we learned

More predictions can mean more ambiguity, not better coverage. Valid coordinates do not imply correct object identity. This led directly to the explicit human-review mechanism.

[Iteration 2 report](phase4_iteration2_review.md), [experiment summary](phase4_iteration2_assets/runs/run_summary.json), and [review ZIP](phase4_iteration2_review.zip).

## 8. Iteration 3: explicit human box selection

### Question

How can a person select one particular saved prediction without changing the detector, hiding mistakes or confusing a research box with editing permission?

We added a small standalone utility with two commands: **prepare** and **decide**.

### Step 1: prepare a request

`prepare` reads the original image and existing detection JSON. It validates the saved result, confirms image dimensions and checks the source image hash. It creates exact-byte evidence copies, a preview with zero-based indices, and `pending.json` in a new directory.

PENDING means no human has submitted a decision. It has no selected box, named reviewer or actual review timestamp. Request creation time is recorded separately.

### Step 2: a real person inspects and decides

| State | Meaning | Releases a candidate? |
|---|---|---|
| PENDING | No human decision has been submitted. | No |
| ACCEPT | A person explicitly selected one saved prediction for segmentation research. | One box |
| REJECT | The results are unsuitable for the intended target. | No |
| NEEDS_REVIEW | Object identity, box extent or intended instance is unresolved. | No |

ACCEPT requires an explicit index, reviewer name, explanation and declarations that both the original image and annotated boxes were inspected. It never defaults to the highest-scoring box, even when only one prediction exists. A zero-detection result cannot be accepted.

Indices are **zero-based positions in the JSON `detections` array**. The new previews use the same indices. Older experiment overlays used one-based numbers, so reviewers must not copy an old displayed number without checking the array.

For the saved eight-box lamp result, index **2** is the central lamp. A reviewer could select it while leaving all eight source predictions intact. That does not automatically reject or approve the other seven.

### What is recorded

The decision binds the original image SHA-256, detection JSON SHA-256, annotation hash, original query, model/revision, selected index, exact XYXY coordinates, original label/score, reviewer explanation and review timestamp.

A SHA-256 hash is a fingerprint of the file bytes. If even JSON whitespace changes after preparation, its hash changes. This helps detect changed or stale evidence; it does not prove an object's identity.

`read_candidate()` checks the record and evidence again before returning an accepted research box. Tampered coordinates, score, label or bound files fail validation. PENDING, REJECT and NEEDS_REVIEW release nothing.

The accepted object is called a **reviewed segmentation-test candidate**. Both flags remain false:

```json
{
  "image_edit_authorized": false,
  "cultural_transformation_authorized": false
}
```

### Actual human-review status

We prepared four real examples: bicycle, airplane negative control, multiple lamps and unresolved vessels. **All four remain PENDING.** No actual human selections were available, and we did not manufacture them. Suggestions in the report are separate assistant observations, not human review decisions.

The vessel labels still do not certify a dhunuchi, material or ritual function. A reviewer may retain NEEDS_REVIEW when that identity is unresolved.

We added **31 offline review tests**, bringing the full suite to **126 passing tests**. They include explicit selection of a lower-scoring box, rejection, empty detections, invalid indices, changed hashes, modified selections, missing inspection declarations, source preservation and no editing authorization. Synthetic reviewer declarations in unit tests are not real confirmations for the research images.

No model was reloaded or run during iteration 3. The utility does not import Torch or Transformers. All **497 pre-existing snapshotted files** remained unchanged.

The narrow implementation received **PASS**, while real human verification stayed PENDING. This does not mean all detector failures were fixed or that SAM may start automatically.

[Iteration 3 report](phase4_iteration3_review.md), [test summary](phase4_iteration3_assets/test_summary.json), and [review ZIP](phase4_iteration3_review.zip).

## 9. Current execution flow

```mermaid
flowchart TD
    I[Original image] --> G[Independent Grounding DINO inference]
    Q[Explicit research text query] --> G
    G --> N[Validate numeric boxes and scores]
    N --> D[Save predictions, hashes, settings and annotated copies]
    D --> P[Prepare a PENDING review request]
    P --> H[Human inspects original and indexed boxes]
    H --> A[Explicit ACCEPT of one index]
    H --> R[REJECT or NEEDS_REVIEW]
    P --> W[Remain PENDING if no human decision]
    A --> V[Recheck hashes and exact selected prediction]
    V --> C[Reviewed segmentation-test candidate only]
    R --> X[Release no candidate]
    W --> X
```

This flow ends at a research candidate. It does not connect automatically to a planner, SAM or an image editor.

## 10. How to run and see the output

Run commands in PowerShell from the project root with the existing environment:

```powershell
$env:PYTHONPATH = (Resolve-Path .\src).Path
```

### Run new object detection

This command performs actual model inference; it is an example instruction, not a run performed while writing this report. Use a new output directory:

```powershell
.\.venv\Scripts\python.exe -B -m transcreation.cli ground --image data/vlm_collection/scene_06.jpg --phrase bicycle --out outputs/grounding_bicycle_notes_demo
```

The first use may need the pinned weights if they are not already cached. Output includes `detection.json`, `original.png`, `annotated.png` and `comparison.png`.

### Prepare review from an existing prediction, without running the model

```powershell
.\.venv\Scripts\python.exe -B scripts/review_grounding.py prepare --detection reports/phase4_iteration2_assets/runs/R01_bicycle_replay/detection.json --image data/vlm_collection/scene_06.jpg --out outputs/bicycle_review_notes_demo
```

This produces `original.jpg`, `detection.json`, `annotated.png` and `pending.json`. The decision stays PENDING.

```powershell
Invoke-Item outputs/bicycle_review_notes_demo/original.jpg
Invoke-Item outputs/bicycle_review_notes_demo/annotated.png
Get-Content outputs/bicycle_review_notes_demo/pending.json
```

The later bicycle demonstration requested in our conversation used this same preparation mechanism on saved detections. It did not rerun Grounding DINO or accept a box.

### Record a genuine human selection

Only after the reviewer actually inspects both images and confirms index 0:

```powershell
.\.venv\Scripts\python.exe -B scripts/review_grounding.py decide --request outputs/bicycle_review_notes_demo/pending.json --decision ACCEPT --index 0 --reviewer "YOUR NAME" --reason "YOUR OWN EXPLANATION AFTER INSPECTION" --inspected-original --inspected-boxes --out outputs/bicycle_review_notes_demo/accepted.json
```

This is an instruction, not an acceptance already performed. Replace the placeholders truthfully. REJECT and NEEDS_REVIEW use the same command with their decision name and no `--index`; detailed examples are in the iteration 3 report. Existing output files/directories are refused.

### Run offline tests

```powershell
.\.venv\Scripts\python.exe -B -m unittest discover -s tests -q
```

The most recent recorded full result is **126 tests passed**. That is historical test evidence; these notes do not claim a new run happened during documentation.

## 11. Evidence and test progression

| Milestone | Before | After | What changed |
|---|---:|---:|---|
| Iteration 1 | 72 passing | 95 passing | Added independent detector and 23 localization tests. |
| Iteration 2 | 95 passing | 95 passing | Added controlled experiment utility; application behavior stayed fixed. |
| Iteration 3 | 95 passing | 126 passing | Added explicit review utility and 31 review tests. |

The iteration 3 ZIP was extracted independently, and its 31 focused review tests also passed. Source/image hashes and relative evidence links were verified when the packages were created.

Across iterations 1 and 2 there were **13 real detector forward calls**: three initial runs plus eight controlled conditions, one negative control and one unchanged bicycle replay. Iteration 3 and the later review-preparation demonstration added no detector inference.

We preserved previous results, used new output paths, retained all returned predictions and did not commit or push automatically.

### Main evidence to open

| Purpose | Saved artifact |
|---|---|
| Initial baseline findings | [Iteration 1 review](phase4_grounding_review.md) |
| Baseline bicycle output | [Detection JSON](phase4_grounding_assets/A_bicycle/detection.json) |
| Threshold sensitivity | [Oil-lamp comparison](phase4_iteration2_assets/threshold_comparison_oil_lamp.png) |
| Negative-control failure | [Airplane comparison](phase4_iteration2_assets/runs/N01_airplane_negative/comparison.png) |
| Reproduced baseline checks | [Reproducibility JSON](phase4_iteration2_assets/baseline_reproducibility.json) |
| Actual pending lamp review | [PENDING record](phase4_iteration3_assets/examples/C_oil_lamp_multiple/pending.json) |
| Current gate tests | [Test summary](phase4_iteration3_assets/test_summary.json) |
| Human review examples and commands | [Iteration 3 review](phase4_iteration3_review.md) |

## 12. Problems, responses and unresolved work

| Problem | What we did | What remains unresolved |
|---|---|---|
| Missed repeated objects | Ran a predeclared threshold/query comparison and inspected all outputs. | Complete coverage is not established. |
| Lower thresholds add dubious boxes | Retained every prediction and documented unrelated/broad regions. | No universal best threshold or general false-positive performance claim. |
| Duplicate boxes | Preserved overlaps and required explicit instance selection. | A human still needs to judge intended object and extent. |
| Airplane label on bicycle | Preserved the negative result and added explicit review capability. | The model can still make the same semantic mistake; no automatic semantic fix was added. |
| Cultural object identity uncertain | Kept source labels as claims and real reviews pending. | Independent identity verification is still needed. |
| Changed or stale evidence | Bound requests to file hashes and revalidated selected snapshots. | Hashes cannot prove semantic truth or authenticate reviewers. |
| Limited GPU memory | Used batch one, lazy loading and sequential experiments; reused one detector in iteration 2. | Concurrent VLM/LLM/detector residency was not tested. |

There are no independent ground-truth boxes, quantitative detection-accuracy results or SAM masks. Human inspection flags are declarations; the local tool cannot prove that a person looked at the image. It also has no signed identity system or automatic policy for resolving contradictory separately saved review decisions.

The current deliverable is a controlled localization-and-review research stage. Completing SAM, diffusion or full transcreation remains future work requiring a separate milestone and evaluation.

## 13. How to explain this in a presentation

### A short opening statement

> In Phase 4, I built an independent text-guided object-localization stage using Grounding DINO Tiny. It takes an original image and a research phrase and returns bounding boxes in original-image coordinates. I tested it on a bicycle, Diwali lamps and Durga Puja vessels. I then investigated missed objects with controlled query and threshold variations. The most important finding was that an airplane query incorrectly localized the bicycle, despite valid coordinates and a nontrivial score. I therefore added an explicit human-review gate that binds a selected box to unchanged source evidence. The latest recorded suite passes 126 offline tests. The actual review examples remain pending, and SAM and image editing are not implemented.

### Suggested five-slide structure

1. **Problem and scope:** why a planned source object must be localized before any future segmentation or editing.
2. **Implementation:** image plus phrase, pinned model, original-pixel boxes, validation and saved evidence.
3. **Controlled experiments:** eight-condition table, repeated-object misses, duplicates and threshold/query sensitivity.
4. **Critical failure and response:** show the airplane-on-bicycle result, then explain why explicit human selection is necessary.
5. **Current outcome and limits:** 126 passing tests, preserved evidence, real reviews PENDING, no SAM/diffusion or accuracy claim.

### Questions you may be asked

**Why Grounding DINO rather than the captioner?**

The captioner supplies a textual scene description. This stage has a different job: locating possible image regions for a supplied phrase. A description is not a bounding box or verified visual evidence.

**Why Tiny?**

We needed to establish feasibility on a 4 GB GPU with a manageable checkpoint. Our recorded runs fit. We did not benchmark multiple detectors here, so I would not claim Tiny is universally best.

**Why not simply lower the threshold?**

It recovered weaker candidates, but also produced duplicates, unrelated regions and a nearly whole-scene box. More returned boxes did not mean more correct distinct objects.

**Why not choose the highest score?**

The negative query returned a wrong semantic match at 0.419, above the central lamp's 0.314. Scores do not replace visual confirmation of the requested target. The review tool requires an explicit index instead.

**What is the difference between numeric and semantic validation?**

Numeric validation checks whether a rectangle is finite, ordered and inside the image, with a valid score. Semantic validation asks whether the rectangle contains the intended object. The airplane-on-bicycle result passed the first and failed visual inspection of the second.

**Did you fix the model's false detection?**

No. I preserved and documented it, and added a separate explicit review mechanism. The underlying detector behavior stayed unchanged.

**Why do you not report precision, recall or IoU?**

We lack independently annotated ground-truth boxes. We report observed prediction counts and clearly identified subjective visual assessments rather than inventing quantitative accuracy.

**How do you preserve reproducibility?**

We record input hashes, the model revision, effective settings, exact normalized prompts, all returned predictions and measurements. We keep old results unchanged. The original bicycle/lamp/vessel baselines reproduced exactly in iteration 2.

**What does an ACCEPT record permit?**

One explicitly reviewed segmentation-test candidate. It does not permit cultural editing or certify a generated cultural object name. The real example records have not yet been accepted by a human.

**What is the strongest engineering contribution in this phase?**

Separating candidate generation, numeric validation and explicit human judgment, while preserving raw evidence and limiting what each successful check actually proves.

## 14. Claims to keep accurate

| Accurate statement | Avoid saying |
|---|---|
| We implemented independent text-guided localization and an explicit review utility. | We completed an automatic transcreation pipeline. |
| The model returned eight predictions for one low-threshold condition. | It correctly found eight different lamps. |
| Some boxes are visually plausible candidates for future segmentation research. | We verified SAM can segment these objects. |
| Review gates and hashes passed offline tests. | The computer proved the object identity or that a human inspected it. |
| Our latest recorded suite passes 126 tests. | All model predictions are correct because the tests passed. |
| Cultural vessel identities remain unresolved. | The model confirmed dhunuchi or clay ritual-burner identity. |
| Four real review examples remain PENDING. | A human already approved the boxes. |

The central lesson to remember is: **a model suggests where to look; numeric checks verify the rectangle; a person still has to judge the intended object.**
