# Phase 5 - iteration 2: SAM box-plus-point refinement

Date: 2026-11-09. **Recommendation: NEEDS FIXES.**

Exactly two new SAM experiments were run, one fixed point set per image, and both returned three nonempty masks on CUDA. The bowl-only lamp result shows a modest visual improvement around flame exclusion. The bicycle result exposes a trade-off: some background is removed, but thin structures and parts of the wheel contours are lost in the sparsest candidate. No candidate is certified as correct.

All outputs and point placements remain **RESEARCH_ONLY**. No independent human approval or pixel ground truth was supplied. No mask cleanup, model change, fine-tuning, diffusion, inpainting or planner integration occurred. Stop for mentor evaluation after this package.

## 1. Objectives and frozen target definitions

Determine whether adding a small number of explicit foreground/background point prompts improves masks over the saved box-only baseline, without changing the image, box, checkpoint or runtime settings.

**BICYCLE:** target physical bicycle parts, including frame, handlebars, saddle, rims, tires and visible spokes. Exclude wall, road and background visible through wheels.

**OIL LAMP:** for this diagnostic only, target the visible clay lamp bowl/body. Exclude flame, unrelated tray, rice/grains and surrounding background. This bowl-only target is not sufficient for full lamp replacement. Eventual treatment of flame, wick and supporting objects remains separate and unresolved.

Both the saved baseline and new masks are assessed against these iteration 2 definitions. The baseline is a prior model prediction, not a ground-truth label.

The definitions, final coordinates and labeled previews were saved before inference in the [preregistered plan](phase5_iteration2_assets/experiment_plan.json). No point, target or source box was changed after viewing point-guided SAM output. The only provisional placement adjustment occurred during original-photo inspection before preregistration: a front-wheel background point moved from (904,753) to (908,758) because it was close to a spoke. The source-inspection draft is retained; it did not trigger SAM inference. The final JSON/preview, not that draft, is the experiment input.

## 2. Controls and actual experimental scope

| Control | Fixed value |
|---|---|
| Checkpoint | `facebook/sam-vit-base` |
| Revision | `70c1a07f894ebb5b307fd9eaaee97b9dfc16068f` |
| Python / Transformers | 3.11.9 / 4.57.6 |
| Device / precision / batch | CUDA / FP32 / one image |
| GPU | NVIDIA GeForce RTX 3050 Laptop GPU, 4096 MiB |
| Seed | 42 |
| Attention / execution | SDPA, `eval()`, `torch.inference_mode()` |
| Multimask / threshold | Three candidates observed; `multimask_output=True`, logit threshold 0.0 |
| Restoration | Existing processor postprocessing on CPU, exact original resolution |
| Image/box | Exact originals and selected predictions from iteration 1 |

Bicycle uses detector index **0**; lamp uses index **2** from its existing saved multi-detection JSON. Neither was selected automatically by confidence. No Grounding DINO, SmolVLM or Qwen inference was performed. Ollama reported no loaded models before the experiment. Separate SAM-only CLI processes ran sequentially.

No fresh box-only inference was run: all six baseline masks and their JSONs were copied byte-for-byte from iteration 1. The two new calls are the only real SAM calls in this iteration. No prompt sweep, alternative checkpoint or post-result point adjustment followed.

[Unchanged configuration](phase5_iteration2_assets/sam.yaml), [model configuration](phase5_iteration2_assets/checkpoint_config.json), [processor configuration](phase5_iteration2_assets/checkpoint_preprocessor_config.json), [effective API/environment metadata](phase5_iteration2_assets/metadata.json).

## 3. Minimal interface extension

Four existing files changed:

- `contracts.py`: added `SamPoint(x, y, label, note)` and optional bound point-file fields on `SegmentationInput`.
- `stages/segmentation.py`: validates point documents, saves a preview before loading SAM, passes native point/label inputs alongside the existing box and records transformed tensor shapes.
- `scripts/segment_sam.py`: adds optional `--points path/to/points.json`.
- `tests/test_segmentation.py`: appends 13 focused offline point tests; existing test cases remain.

Each point has finite original-image coordinates and an integer label: **1 = foreground, 0 = background**. Booleans, invalid labels and out-of-image positions are rejected. The point document binds the exact image hash, detection JSON hash and selected index. It also records the diagnostic target definition and `RESEARCH_ONLY_REQUIRES_REVIEW` annotation status.

The request records every point and the point-file SHA-256. Changing the file after selection causes a pre-inference failure. Exact point bytes and the indexed preview are copied into each run. The run preview was verified byte-identical to its preregistered preview.

New points cannot inherit approval from an accepted box review: point-file use requires explicit RESEARCH_ONLY mode. Existing reviewed box-only behavior is retained. There is no automatic point generator or additional AI model; coordinates were manually specified by the assistant after inspecting the original photographs. That is research placement, not an independently approved human annotation.

### Installed native point API

The installed processor implementation was read before coding. For one image and one combined box/point prompt:

```text
supplied input_points:   [[[x0,y0], [x1,y1], ...]]
supplied input_labels:   [[1, 0, ...]]
processed input_points: [1, 1, N, 2]
processed input_labels: [1, 1, N]
processed input_boxes:  [1, 1, 4]
```

Coordinates are not manually resized. `SamProcessor` transforms the original-image box and points, and the transformed tensors are forwarded to `SamModel` together. Original sizes and existing mask restoration are unchanged.

**Backward compatibility:** absent points, or an empty point list, send no point/label keyword arguments to either processor or model. Old box-only model calls therefore retain their behavior. Existing JSON fields retain their names; new request fields are additive. Repository tests pass, but external readers requiring an exact old key set may need to permit these new optional fields.

## 4. Point placement and provenance

The bicycle set contains four positive and four negative points. The lamp set contains three positive and two negative points. Full coordinate tables, notes and labeled previews are included in the appendix. Green means label 1; cyan means label 0. Point indices are zero-based.

Dense bicycle spokes make exact background placement difficult, so points require independent review. The final magnified coordinate-check images document where each marker falls in the original photograph. Neither the coordinates nor their labels are independent ground truth.

[Bicycle final point JSON](phase5_iteration2_assets/prompts/A_bicycle.json), [lamp final point JSON](phase5_iteration2_assets/prompts/B_oil_lamp.json), [original-source bicycle placement draft](phase5_iteration2_assets/A_bicycle_coordinate_check_draft.png). No SAM output was used to revise these frozen files.

## 5. Real results and visual comparison

Both runs completed with `SEGMENTED` status. All six new masks have original-image dimensions and binary values 0/255. All alternatives, raw model scores, foreground counts and mask bounds are preserved. Numeric-valid status does not establish object completeness or semantic correctness.

The main three-panel visualization uses the highest SAM score only for display. The before/after galleries show **all three** old and new candidates. No candidate was discarded or promoted as human-approved after inspection.

### Bicycle

| Aspect | Observed comparison |
|---|---|
| Wall/background leakage | New candidate 0 removes some upper/background area compared with baseline 0, but still has wall/graphic fragments and filled wheel interiors. New small foreground islands also appear. |
| Wheel openings | Candidate 0 still includes background at both negative wheel points; candidate 1 still includes background at the rear-wheel negative point. Candidate 2 opens most wheel interiors. |
| Thin structures | Candidate 2 does not visibly recover individual spokes reliably. It also misses substantial rim/tire sections, particularly on the front/right wheel. Opening the wheels is not sufficient when physical bicycle parts disappear. |
| Frame/body | Most major tubes and saddle remain, but holes, fragments and boundary differences persist. Cables, grips and other thin parts are not reliably preserved. |
| New mistakes | The sparsest mask has a much narrower right extent and loses visible wheel portions; larger candidates introduce or retain background patches. |
| Overall | Partial reduction in leakage, but the declared bicycle target is not reliably met. No candidate is established as a complete physical-parts mask. |

Scores fell from approximately 0.955/0.944/0.865 to 0.888/0.816/0.731. This does not establish worse measured accuracy, just as reduced mask area does not establish improvement. The visual evidence and missing parts matter.

### Oil lamp

| Aspect | Observed comparison |
|---|---|
| Bowl outline/coverage | Most of the original bowl outline remains similar. Candidates 0 and 1 retain broad body/rim coverage. |
| Flame exclusion | New candidates 0 and 1 exclude the bright flame more cleanly/consistently than the narrow, fragmented exclusion in baseline 0. All three exclude the supplied flame point. |
| Wick/interior | Candidate 2 still excludes a larger irregular region around wick/oil/reflections; whether all omitted pixels belong outside the intended clay target needs independent review. Small interior holes differ between candidates. |
| Background/tray | The major surrounding tray/rice region stays outside, including the supplied background point. No unrelated lamp is merged. |
| Base/support | The dark support/base remains excluded. The box was not extended to address this after seeing results. |
| Overall | A modest visual improvement for this bowl-only diagnostic, not validated segmentation accuracy or a complete lamp-replacement mask. |

Scores changed from approximately 0.965/0.957/0.947 to 0.971/0.963/0.946. Higher scores for the first two are not proof of improved ground-truth quality. Future treatment of flame, wick and supporting objects remains unresolved.

All displayed assessments are subjective visual engineering observations. No independently labeled pixel mask exists, so measured ground-truth IoU, Dice, precision, recall and segmentation accuracy are not reported.

## 6. Foreground and overlap diagnostics

Foreground counts changed as follows; output positions are not established semantic correspondences:

| Scene | Candidate | Saved box-only pixels | New point-guided pixels | Area change |
|---|---:|---:|---:|---:|
| Bicycle | 0 | 110800 | 97388 | -13412 |
| Bicycle | 1 | 88076 | 74911 | -13165 |
| Bicycle | 2 | 72998 | 26559 | -46439 |
| Lamp | 0 | 33862 | 32088 | -1774 |
| Lamp | 1 | 30373 | 31757 | +1384 |
| Lamp | 2 | 27917 | 27687 | -230 |

The analyzer calculated **all nine baseline/new mask pairs per image**, rather than assuming matching candidate indices identify the same semantic extent. The appendix gives all 18 pairs.

```text
intersection_pixels = pixels foreground in both predicted masks
union_pixels        = pixels foreground in either predicted mask
prediction_overlap_ratio = intersection_pixels / union_pixels
point_only_pixels   = new foreground outside the baseline prediction
baseline_only_pixels = baseline foreground removed in the new prediction
```

This ratio describes **agreement between two predictions**, not IoU against ground truth. Baseline masks are not correct labels. Lower agreement, smaller area or a larger area change is not inherently better or worse segmentation.

### Sampled point-label membership

As a separate descriptive check, the analyzer read the saved mask pixel at each supplied integer point. The labels themselves are research annotations, not independent ground truth.

| Scene | New candidate | Supplied point labels matched at sampled pixels | Unmatched point indices |
|---|---:|---:|---|
| Bicycle | 0 | 6 of 8 | 6, 7: negative wheel points still foreground |
| Bicycle | 1 | 7 of 8 | 6: rear-wheel negative point still foreground |
| Bicycle | 2 | 8 of 8 | None |
| Lamp | 0 | 5 of 5 | None |
| Lamp | 1 | 5 of 5 | None |
| Lamp | 2 | 5 of 5 | None |

SAM's point labels are guidance, not a hard pixel constraint. We did not erase pixels to make masks obey them. Bicycle candidate 2 demonstrates why satisfying sparse labels does not prove complete object coverage: it matches the points while missing many other physical parts. These counts are not segmentation accuracy.

[Full descriptive statistics](phase5_iteration2_assets/mask_statistics.json).

## 7. Performance and hardware

| Scene | Model load s | Forward s | Restore/save s | Stage s | Visualization s | Peak allocated CUDA bytes |
|---|---:|---:|---:|---:|---:|---:|
| Bicycle | 9.2983 | 1.7318 | 0.1041 | 11.2965 | 2.0191 | 2065263616 |
| Lamp | 9.0325 | 1.2262 | 0.0855 | 10.4543 | 0.9879 | 2065263616 |

Peak allocated CUDA memory was **1969.59 MiB, about 1.92 GiB**, in both runs. Loading peak was 374956544 bytes. The allocated peak includes resident model tensors; it excludes other applications, driver/context overhead and reserved-only allocator memory. It is not total GPU memory consumption.

`nvidia-smi` snapshots showed 1469 MiB globally used before and 1068 MiB after SAM shutdown. Those readings are not process-specific peaks or a measurement obtained by subtracting them.

Both runs stayed on CUDA without OOM/fallback or runtime error. CPU fallback behavior remains covered by pre-existing mocked tests; no real CPU run was added. There was no simultaneous loading of the application's other models.

Forward timings use CUDA synchronization. Stage timings include lazy loading, preprocessing, inference, restoration and mask saves; they exclude earlier evidence verification/preview preparation, Python startup and later visualization generation. Each image was run once in a separate process. GPU state and warm-up prevent interpreting the old/new timings as a controlled speed benchmark.

## 8. Regression and provenance checks

| Check | Before | After |
|---|---|---|
| Full offline suite | 157 tests, 3.521 s, OK | 170 tests, 10.015 s, OK |
| Failures/errors | 0 / 0 | 0 / 0 |
| Model/checkpoint/config | Saved iteration 1 values | Unchanged |
| Existing files | 602 snapshotted | Four authorized code/test files changed; 598 others unchanged |

The 13 new tests cover foreground/background labels; invalid labels and finite in-bounds coordinates; correct combined point/label/box shapes; unchanged no-point calls; an empty list; point provenance/serialization/pre-forward preview; file hash changes; image/detection/index binding; research-only restrictions; bad processor tensor shapes; a native processor-only transformation test; and the CLI `--points` option.

No weights are downloaded in offline tests. SAM models are mocked. The native processor test constructs a small synthetic processor/image to verify shape/coordinate behavior without loading a model. This extra import/processing work also means test-suite durations should not be interpreted as model latency.

The existing 157 tests remain, including all prior mask, CUDA/failure, input-hash, human-review and planner restrictions. Existing reviewed box-only input remains valid; no new point annotation is presented as approved by that box review.

Artifact verification confirms exact original image/detection hashes, unchanged selected boxes, binary 0/255 masks at original resolution, recomputed pixel counts/bounds, byte-identical baseline copies and frozen point documents/previews. The generated run previews are byte-identical to those saved before inference.

[Test summary](phase5_iteration2_assets/test_summary.json), [before output](phase5_iteration2_assets/tests_before.txt), [after output](phase5_iteration2_assets/tests_after.txt), [artifact verification](phase5_iteration2_assets/verification.json), [preservation verification](phase5_iteration2_assets/preservation_after.json).

## 9. Git diff and compatibility

Only `contracts.py`, `stages/segmentation.py`, `scripts/segment_sam.py` and `tests/test_segmentation.py` changed among existing files. New reports/assets hold the frozen plan, point files, comparisons and measurements. No dependency, default configuration, model checkpoint, planner, review record, Grounding DINO prediction, original photograph or iteration 1 mask changed. No deletion, commit or push occurred.

The task-specific diff is against the preserved iteration 1 snapshots, not an older Git HEAD containing earlier uncommitted work. [Diff](phase5_iteration2_assets/task_changes.diff), [summary](phase5_iteration2_assets/git_diff_summary.txt), [initial status](phase5_iteration2_assets/initial_git_status.txt), [before preservation hashes](phase5_iteration2_assets/preservation_before.json).

The optional point fields extend request JSON. Existing key names and no-point inference calls are retained. External strict-schema consumers are outside these regression checks and may need to accept the added keys. The standalone command still runs from the project root with `src` on `PYTHONPATH`.

## 10. Limitations and recommendation

**NEEDS FIXES:** point prompts changed the masks and helped a narrow bowl-only diagnostic, but did not reliably satisfy the full bicycle target. There is no verified final mask or approved cultural-edit candidate.

Limitations:

1. Only two fixed experiments and one point set per scene; no point-by-point ablation identifies which prompt caused a specific change.
2. Sparse labels cannot define every spoke, rim edge or background opening. Their sampled satisfaction is not whole-mask correctness.
3. Manual assistant research placement is uncertain, especially near thin spokes; no independent human annotation/approval was fabricated.
4. Baseline agreement and foreground counts are descriptive, with no pixel ground truth or measured accuracy.
5. Candidate indices are output positions; correspondence across prompt types is not established.
6. Mask scores do not decide semantic completeness. All alternatives, including visibly problematic ones, remain available.
7. Bowl-only boundaries do not settle future flame, wick, oil/reflection or support handling. No source-box extension was performed.
8. Single-run memory/timing observations do not establish general performance or bitwise repeatability.

The recommended next action is independent mentor inspection of the fixed points and every mask, especially missing bicycle structures and the intended lamp foreground. Any further prompt experiments would require a separate approved milestone. No point retuning, mask cleanup or additional development began after these results.

## 11. Package contents and attribution

The self-contained ZIP includes this report, frozen plan/coordinates/previews, new JSONs and six binary masks, all six saved baseline masks/JSONs, overlays and before/after figures, original image copies, overlap statistics, test/config/API evidence, task diff and relevant code snapshots. It excludes model weights, environments, unrelated datasets and secrets.

Image attribution from the existing project manifest: bicycle by Basile Morin, [Wikimedia source](https://commons.wikimedia.org/wiki/File:Parked_bicycle_with_graffitied_building_facade_and_doors_in_Amsterdam.jpg), [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/); lamps by Benoy, [Wikimedia source](https://commons.wikimedia.org/wiki/File:Diwali_Oil_lamps_Darjeeling.jpg), [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/). Visualization derivatives retain their source attribution/license.

## Appendix: commands, exact points, all masks and overlap tables

### Preregistration and exact commands

Final plan timestamp: **2026-11-09T11:09:44.916159+00:00**. Point and preview hashes were frozen at this stage and verified after inference.

```powershell
$env:PYTHONPATH = (Resolve-Path .\src).Path
.\.venv\Scripts\python.exe -B -m scripts.segment_sam --image data\vlm_collection\scene_06.jpg --detection reports\phase4_iteration2_assets\runs\R01_bicycle_replay\detection.json --prediction-index 0 --research-only --points reports/phase5_iteration2_assets/prompts/A_bicycle.json --note "One preregistered bicycle box-plus-point experiment; physical parts only; research annotations requiring review." --out reports/phase5_iteration2_assets/A_bicycle
.\.venv\Scripts\python.exe -B -m scripts.segment_sam --image data\vlm_collection\scene_02.jpg --detection reports\phase4_iteration2_assets\runs\A02_oil_lamp_020\detection.json --prediction-index 2 --research-only --points reports/phase5_iteration2_assets/prompts/B_oil_lamp.json --note "One preregistered bowl-only box-plus-point diagnostic; exclude flame and unrelated background; research annotations requiring review." --out reports/phase5_iteration2_assets/B_oil_lamp
```

These effective argument values ran exactly two new conditions. Output paths already exist; no repeated/modified prompt runs were made. [Command record](phase5_iteration2_assets/commands.json).

### A_bicycle: exact original-coordinate points

Target: Physical bicycle parts, including frame, handlebars, saddle, rims, tires and visible spokes. Exclude wall, road and background visible through wheels.

Unchanged original box: `[441.8973388671875, 581.3589477539062, 953.31396484375, 924.9127197265625]`; detector index **0**. Annotation state: **RESEARCH_ONLY_REQUIRES_REVIEW**.

| Point index | X | Y | Label | Intended source placement (research claim) |
|---|---:|---:|---:|---|
| 0 | 680 | 653 | 1 | Visible horizontal frame tube |
| 1 | 658 | 722 | 1 | Visible diagonal frame tube |
| 2 | 550 | 913 | 1 | Rear-wheel tire/rim structure |
| 3 | 850 | 882 | 1 | Front-wheel tire/rim structure |
| 4 | 830 | 625 | 0 | Wall/graffiti above and to the right of the frame |
| 5 | 680 | 695 | 0 | Wall visible inside the main frame opening |
| 6 | 505 | 750 | 0 | Wall/graffiti visible through rear-wheel opening |
| 7 | 908 | 758 | 0 | Background between visible front-wheel spokes; placement requires independent review |

Point-file SHA-256: `8dcf2a168ce68b8958a00fabc12ba1fb9ddb894e1911bcabecd3e16567d68ea4`.

![A_bicycle: fixed point placement saved before inference](phase5_iteration2_assets/prompts/A_bicycle.png)

[Magnified original-coordinate placement check](phase5_iteration2_assets/prompts/A_bicycle_coordinate_check.png). No marker is independently human-approved.

### A_bicycle: all baseline and point-guided masks

[Original image](phase5_iteration2_assets/A_bicycle/original.jpg) | [Unchanged detector source](phase5_iteration2_assets/A_bicycle/source_detection.json) | [New result JSON](phase5_iteration2_assets/A_bicycle/segmentation.json) | [Saved baseline JSON](phase5_iteration2_assets/baseline/A_bicycle/segmentation.json)

| Prompt type | Candidate | SAM score (not measured accuracy) | Foreground pixels | XYXY mask bounds, upper exclusive | Binary PNG | Overlay |
|---|---:|---:|---:|---|---|---|
| box-only | 0 | 0.955327630 | 110800 | `[444, 578, 957, 924]` | [mask 0](phase5_iteration2_assets/baseline/A_bicycle/mask_0.png) | [overlay 0](phase5_iteration2_assets/baseline/A_bicycle/overlay_0.png) |
| box-only | 1 | 0.943802357 | 88076 | `[444, 584, 956, 924]` | [mask 1](phase5_iteration2_assets/baseline/A_bicycle/mask_1.png) | [overlay 1](phase5_iteration2_assets/baseline/A_bicycle/overlay_1.png) |
| box-only | 2 | 0.864693284 | 72998 | `[444, 583, 949, 924]` | [mask 2](phase5_iteration2_assets/baseline/A_bicycle/mask_2.png) | [overlay 2](phase5_iteration2_assets/baseline/A_bicycle/overlay_2.png) |
| box+points | 0 | 0.887634158 | 97388 | `[432, 582, 949, 924]` | [mask 0](phase5_iteration2_assets/A_bicycle/mask_0.png) | [overlay 0](phase5_iteration2_assets/A_bicycle/overlay_0.png) |
| box+points | 1 | 0.816094458 | 74911 | `[444, 583, 939, 925]` | [mask 1](phase5_iteration2_assets/A_bicycle/mask_1.png) | [overlay 1](phase5_iteration2_assets/A_bicycle/overlay_1.png) |
| box+points | 2 | 0.731330991 | 26559 | `[444, 583, 914, 925]` | [mask 2](phase5_iteration2_assets/A_bicycle/mask_2.png) | [overlay 2](phase5_iteration2_assets/A_bicycle/overlay_2.png) |

Scores are displayed to nine decimals; JSON retains full floating-point values. All masks are original resolution. Output position does not imply established semantic correspondence across rows.

![A_bicycle: full original and all saved/new candidate overlays](phase5_iteration2_assets/A_bicycle/all_candidates_comparison.png)

![A_bicycle: detail overlay comparison, baseline above and point-guided below](phase5_iteration2_assets/A_bicycle/detail_comparison.png)

![A_bicycle: raw binary mask detail comparison](phase5_iteration2_assets/A_bicycle/binary_comparison.png)

The upper row is saved box-only output; lower row is box+points. Display crops use the same ROI as iteration 1: bicycle [400,540,1000,966], lamp [600,220,930,475]. Headers and crop offsets do not change stored mask coordinates.

### A_bicycle: all predicted-mask overlap pairs

| Baseline index | Point-guided index | Intersection pixels | Union pixels | Prediction overlap ratio | Point-only pixels | Baseline-only pixels |
|---|---|---:|---:|---:|---:|---:|
| 0 | 0 | 95285 | 112903 | 0.843955 | 2103 | 15515 |
| 0 | 1 | 73275 | 112436 | 0.651704 | 1636 | 37525 |
| 0 | 2 | 25841 | 111518 | 0.231720 | 718 | 84959 |
| 1 | 0 | 85879 | 99585 | 0.862369 | 11509 | 2197 |
| 1 | 1 | 70611 | 92376 | 0.764387 | 4300 | 17465 |
| 1 | 2 | 24343 | 90292 | 0.269603 | 2216 | 63733 |
| 2 | 0 | 71722 | 98664 | 0.726932 | 25666 | 1276 |
| 2 | 1 | 59488 | 88421 | 0.672781 | 15423 | 13510 |
| 2 | 2 | 23721 | 75836 | 0.312793 | 2838 | 49277 |

These are comparisons between two predictions, not ground-truth IoU/Dice or accuracy. Actual native tensors: points `[1, 1, 8, 2]`, labels `[1, 1, 8]`, box `[1, 1, 4]`. Transformed coordinates are recorded in the new result JSON; no manual scaling was applied.

### B_oil_lamp: exact original-coordinate points

Target: For this diagnostic only: visible clay lamp bowl/body. Exclude flame, unrelated tray, rice/grains and surrounding background. This bowl-only target is not sufficient for full lamp replacement; eventual flame, wick and supporting-object treatment remains separate and unresolved.

Unchanged original box: `[631.4442138671875, 248.13294982910156, 889.331787109375, 443.25518798828125]`; detector index **2**. Annotation state: **RESEARCH_ONLY_REQUIRES_REVIEW**.

| Point index | X | Y | Label | Intended source placement (research claim) |
|---|---:|---:|---:|---|
| 0 | 650 | 330 | 1 | Left clay bowl/rim |
| 1 | 760 | 418 | 1 | Front clay bowl body |
| 2 | 850 | 365 | 1 | Right clay rim/body |
| 3 | 769 | 310 | 0 | Bright flame interior |
| 4 | 880 | 420 | 0 | Unrelated tray/rice/background beside the bowl |

Point-file SHA-256: `49c3e6f58bdc84f3ec620fdc52718f1224ff911ccebf761f416a1b5eaef3c8f4`.

![B_oil_lamp: fixed point placement saved before inference](phase5_iteration2_assets/prompts/B_oil_lamp.png)

[Magnified original-coordinate placement check](phase5_iteration2_assets/prompts/B_oil_lamp_coordinate_check.png). No marker is independently human-approved.

### B_oil_lamp: all baseline and point-guided masks

[Original image](phase5_iteration2_assets/B_oil_lamp/original.jpg) | [Unchanged detector source](phase5_iteration2_assets/B_oil_lamp/source_detection.json) | [New result JSON](phase5_iteration2_assets/B_oil_lamp/segmentation.json) | [Saved baseline JSON](phase5_iteration2_assets/baseline/B_oil_lamp/segmentation.json)

| Prompt type | Candidate | SAM score (not measured accuracy) | Foreground pixels | XYXY mask bounds, upper exclusive | Binary PNG | Overlay |
|---|---:|---:|---:|---|---|---|
| box-only | 0 | 0.964610636 | 33862 | `[635, 253, 888, 444]` | [mask 0](phase5_iteration2_assets/baseline/B_oil_lamp/mask_0.png) | [overlay 0](phase5_iteration2_assets/baseline/B_oil_lamp/overlay_0.png) |
| box-only | 1 | 0.956918180 | 30373 | `[634, 253, 888, 442]` | [mask 1](phase5_iteration2_assets/baseline/B_oil_lamp/mask_1.png) | [overlay 1](phase5_iteration2_assets/baseline/B_oil_lamp/overlay_1.png) |
| box-only | 2 | 0.947273970 | 27917 | `[634, 253, 888, 442]` | [mask 2](phase5_iteration2_assets/baseline/B_oil_lamp/mask_2.png) | [overlay 2](phase5_iteration2_assets/baseline/B_oil_lamp/overlay_2.png) |
| box+points | 0 | 0.970740914 | 32088 | `[634, 253, 888, 444]` | [mask 0](phase5_iteration2_assets/B_oil_lamp/mask_0.png) | [overlay 0](phase5_iteration2_assets/B_oil_lamp/overlay_0.png) |
| box+points | 1 | 0.962729812 | 31757 | `[634, 253, 888, 443]` | [mask 1](phase5_iteration2_assets/B_oil_lamp/mask_1.png) | [overlay 1](phase5_iteration2_assets/B_oil_lamp/overlay_1.png) |
| box+points | 2 | 0.945954442 | 27687 | `[634, 252, 888, 441]` | [mask 2](phase5_iteration2_assets/B_oil_lamp/mask_2.png) | [overlay 2](phase5_iteration2_assets/B_oil_lamp/overlay_2.png) |

Scores are displayed to nine decimals; JSON retains full floating-point values. All masks are original resolution. Output position does not imply established semantic correspondence across rows.

![B_oil_lamp: full original and all saved/new candidate overlays](phase5_iteration2_assets/B_oil_lamp/all_candidates_comparison.png)

![B_oil_lamp: detail overlay comparison, baseline above and point-guided below](phase5_iteration2_assets/B_oil_lamp/detail_comparison.png)

![B_oil_lamp: raw binary mask detail comparison](phase5_iteration2_assets/B_oil_lamp/binary_comparison.png)

The upper row is saved box-only output; lower row is box+points. Display crops use the same ROI as iteration 1: bicycle [400,540,1000,966], lamp [600,220,930,475]. Headers and crop offsets do not change stored mask coordinates.

### B_oil_lamp: all predicted-mask overlap pairs

| Baseline index | Point-guided index | Intersection pixels | Union pixels | Prediction overlap ratio | Point-only pixels | Baseline-only pixels |
|---|---|---:|---:|---:|---:|---:|
| 0 | 0 | 32050 | 33900 | 0.945428 | 38 | 1812 |
| 0 | 1 | 31643 | 33976 | 0.931334 | 114 | 2219 |
| 0 | 2 | 27571 | 33978 | 0.811437 | 116 | 6291 |
| 1 | 0 | 30310 | 32151 | 0.942739 | 1778 | 63 |
| 1 | 1 | 30183 | 31947 | 0.944784 | 1574 | 190 |
| 1 | 2 | 27618 | 30442 | 0.907233 | 69 | 2755 |
| 2 | 0 | 27835 | 32170 | 0.865247 | 4253 | 82 |
| 2 | 1 | 27844 | 31830 | 0.874772 | 3913 | 73 |
| 2 | 2 | 27482 | 28122 | 0.977242 | 205 | 435 |

These are comparisons between two predictions, not ground-truth IoU/Dice or accuracy. Actual native tensors: points `[1, 1, 5, 2]`, labels `[1, 1, 5]`, box `[1, 1, 4]`. Transformed coordinates are recorded in the new result JSON; no manual scaling was applied.

### Re-running focused tests from the extracted review package

The package contains relevant implementation snapshots, not weights or an environment. With the existing Python/Torch/Transformers/Pillow/PyYAML environment, run from the extracted root:

```powershell
$env:PYTHONPATH = "$(Resolve-Path phase5_iteration2_assets/implementation);$(Resolve-Path phase5_iteration2_assets/implementation/src)"
$env:HF_HUB_OFFLINE = "1"
python -B -m unittest discover -s phase5_iteration2_assets/implementation/tests -p test_segmentation.py -q
```

This runs the 44 focused SAM tests (31 previous plus 13 new) without model weights. Synthetic test reviewer declarations and synthetic point labels are not approvals or ground-truth annotations for the research images.

The experiment ends with this package. No extra point set, cleanup or next milestone was started.
