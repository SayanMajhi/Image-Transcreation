"""Read-only verification of existing evidence; run from the project root."""
import json
from pathlib import Path

from transcreation.config import load_config, load_planner_config, load_grounding_config, load_sam_config
from transcreation.stages.caption import SmolVLMCaptioner
from transcreation.stages.ollama_planner import OllamaPlanner
from scripts.review_grounding import _checked_evidence
from scripts.review_mask import _check, read_candidate


def main():
    root = Path.cwd()
    config = {
        "caption": str(load_config(root / "configs/models.yaml")),
        "planner": str(load_planner_config(root / "configs/planner.yaml")),
        "grounding": str(load_grounding_config(root / "configs/grounding.yaml")),
        "sam": str(load_sam_config(root / "configs/sam.yaml")),
    }
    masks = []
    for path in (root / "reports/phase5_iteration3_assets").glob("case_*/pending_*.json"):
        record = json.loads(path.read_text())
        _check(record, path.parent)
        try:
            read_candidate(path)
        except ValueError as exc:
            masks.append({"path": path.relative_to(root).as_posix(), "decision": record["decision"],
                          "evidence_valid": True, "release_blocked": True, "reason": str(exc)})
        else:
            raise AssertionError("PENDING mask was released")
    boxes = []
    for path in (root / "reports/phase4_iteration3_assets/examples").glob("*/pending.json"):
        record = json.loads(path.read_text())
        _checked_evidence(record, path.parent)
        boxes.append({"path": path.relative_to(root).as_posix(), "evidence_valid": True,
                      "decision": record["decision"]})
    result = {"configuration": config, "mask_reviews": masks, "box_reviews": boxes,
              "model_inference_calls": 0, "imports": [SmolVLMCaptioner.__name__, OllamaPlanner.__name__]}
    (root / "reports/repository_cleanup_20261110/saved_evidence_verification.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8")
    print(f"Verified {len(masks)} pending masks and {len(boxes)} grounding review sources; no inference")


if __name__ == "__main__":
    main()
