# Phase 4 - iteration 2: missed-object analysis

Date: 2026-11-09. **Recommendation: NEEDS FIXES before unchecked downstream integration.**

The independent detector remains runnable on the 4 GB GPU and reproduces the previous baseline exactly. Lower thresholds and query wording recover some missed objects, but also expose duplicates, unrelated regions and broad boxes. The negative control incorrectly labels the bicycle as an airplane at **0.419180**. This package preserves that failure; no result was suppressed or repaired. Single-object localization is promising with visual review, but numeric box validity and confidence alone are insufficient to select a semantically correct object.

## 1. Objective and hypotheses

Investigate missed repeated-object detections with exactly the eight declared image/query/threshold combinations. Text threshold stays 0.25. No model, architecture, precision, preprocessing, defaults or planner policy changes were made.

Hypotheses, declared before inference:

1. Lowering the box threshold from 0.30 to 0.20 may recover weaker repeated-object candidates, at the cost of unrelated regions, oversized boxes or duplicates.
2. Changing only the specified wording may change scores and box extents. More returned boxes does not necessarily mean more correct distinct instances. The vessel queries remain research hypotheses, not verified cultural labels.
3. No recognizable airplane is expected in the bicycle image. Any returned negative-control detection must remain in the record and be visually inspected.

The eight-condition matrix is separate from the requested negative control. One unchanged positive bicycle baseline replay was additionally performed to check the explicit reproducibility acceptance criterion; it is not an added exploratory phrase/threshold variation. There were **10 forward calls total: 8 matrix conditions + 1 negative control + 1 original-baseline replay**. No conditions were added after results were observed.

## 2. Baseline preservation and preflight

Read the iteration 1 report, three detection JSONs, effective settings and annotated comparisons. The current suite passed **95 tests in 0.535 seconds** before experimentation. `configs/grounding.yaml` still has box threshold 0.30, text threshold 0.25 and seed 42.

The application already supported CLI threshold overrides, so no CLI, detector, contract, configuration, model or dependency change was needed. Added only a fixed research utility, `scripts/evaluate_grounding_iteration2.py`, and new review evidence.

A snapshot of **407 existing files** was taken before creating iteration 2 evidence. All 407 are still byte-identical. This includes original source images, prior reports/ZIPs, original predictions, archived results, existing tests and uncommitted work. [Preservation before](phase4_iteration2_assets/preservation_before.json) and [preservation verification](phase4_iteration2_assets/preservation_after.json). Copies of the three original baseline JSON/comparison pairs are included for a self-contained review.

### Source inputs

| Scene | Repository source | Dimensions | SHA-256 | Portable exact input |
|---|---|---|---|---|
| Bicycle | `data/vlm_collection/scene_06.jpg` | 1280 x 966 | `e0fa05019d587cc62b1d4d5a82d7440216b5d88ef0f2149a69f2eb2ee640fca0` | [bicycle.jpg](phase4_iteration2_assets/sources/bicycle.jpg) |
| Diwali lamps | `data/vlm_collection/scene_02.jpg` | 1280 x 842 | `321c415a72e47d745949c90170c6342f70dafcbbe47380ff4cfaffbaf2b4dfc2` | [lamps.jpg](phase4_iteration2_assets/sources/lamps.jpg) |
| Durga Puja vessels | `data/sample_images/durga.jpg` | 980 x 692 | `c43e0c3f07b88a310d0e120e7aa32ea5a29cecba37747015bcdec75c284e5ab0` | [vessels.jpg](phase4_iteration2_assets/sources/vessels.jpg) |

No source image was altered. PNGs are decoded copies; exact JPEG copies above retain the input file hash.

## 3. Fixed model and environment

- Checkpoint: `IDEA-Research/grounding-dino-tiny`.
- Pinned/resolved revision: `a2bb814dd30d776dcf7e30523b00659f4f141c71`; detector checks loaded `model.config._commit_hash`.
- Python 3.11.9; Transformers 4.57.6; Torch `2.15.0+cu132`; CUDA runtime 13.2; Pillow `13.0.0`; PyYAML `6.0.3`. Package versions exactly match iteration 1.
- Actual device: NVIDIA GeForce RTX 3050 Laptop GPU, 4096 MiB, driver 592.00. CUDA, FP32, batch size 1, seed 42, `eval()`, `torch.inference_mode()`, `disable_custom_kernels=True` remain unchanged.
- Processor: shortest edge 800, longest edge 1333, bilinear resizing, rescale 1/255, existing ImageNet normalization and padding. Exact effective processor dictionaries are saved in every detection JSON and match the baseline.
- Installed postprocessing API uses `threshold` for the box threshold, `text_threshold=0.25` and original `(height, width)` in `target_sizes`. Results use `[x_min, y_min, x_max, y_max]` in original-image pixels.

One model was lazy-loaded on the first call and reused for all subsequent conditions. The script asserts that its model object is unchanged. Only the immutable configuration value `box_threshold` is replaced between conditions. The detector and processor are not replaced; every query still runs a separate forward pass. The model is closed at the end. No SmolVLM/Qwen inference or concurrent model loading was performed. Ollama `/api/ps` returned an empty model list before the study, so no unloading request was needed.

[Environment/configuration metadata](phase4_iteration2_assets/metadata.json), [unchanged default YAML](phase4_iteration2_assets/grounding.yaml), [predeclared plan](phase4_iteration2_assets/runs/experiment_plan.json).

## 4. Exact experiment matrix and measured counts

The plan was written at UTC **2026-11-09T07:02:25.416298+00:00**, before model loading. Run order was bicycle replay, A01-A04, B01-B04, then the negative control. No extra threshold sweep, new wording or repeated timing trials followed.

Counts below mean processor-returned predictions and boxes passing **numeric** validation, not correct detections or unique objects.

| Condition | Image | Exact normalized prompt | Box threshold | Text threshold | Raw returned | Numerically valid | Invalid |
|---|---|---|---|---|---|---|---|
| A01_oil_lamp_030 | Diwali lamps | `oil lamp.` | 0.30 | 0.25 | 1 | 1 | 0 |
| A02_oil_lamp_020 | Diwali lamps | `oil lamp.` | 0.20 | 0.25 | 8 | 8 | 0 |
| A03_diya_030 | Diwali lamps | `diya.` | 0.30 | 0.25 | 5 | 5 | 0 |
| A04_diya_020 | Diwali lamps | `diya.` | 0.20 | 0.25 | 13 | 13 | 0 |
| B01_incense_burner_030 | Durga Puja vessels | `incense burner.` | 0.30 | 0.25 | 5 | 5 | 0 |
| B02_incense_burner_020 | Durga Puja vessels | `incense burner.` | 0.20 | 0.25 | 8 | 8 | 0 |
| B03_clay_incense_burner_030 | Durga Puja vessels | `clay incense burner.` | 0.30 | 0.25 | 7 | 7 | 0 |
| B04_clay_incense_burner_020 | Durga Puja vessels | `clay incense burner.` | 0.20 | 0.25 | 8 | 8 | 0 |

| Additional check | Query | Thresholds | Returned / numerically valid / invalid |
|---|---|---|---|
| R01: unchanged bicycle baseline replay | `bicycle.` | 0.30 / 0.25 | 1 / 1 / 0 |
| N01: requested negative control | `airplane.` | 0.30 / 0.25 | 1 / 1 / 0 |

All **57 returned boxes** across 10 calls passed coordinate/order/boundary/score checks. Every returned prediction was retained; none was removed for seeming wrong. No invalid-coordinate predictions occurred. Each `validation.json` nevertheless separates `valid_predictions`, `invalid_predictions` and observations; empty invalid arrays are actual outcomes, not missing evidence.

### Before/after count comparison

| Image/query | Iteration 1 same-query count at 0.30 | This study at 0.30 | This study at 0.20 | Count increase on lowering threshold |
|---|---|---|---|---|
| Lamps / oil lamp | 1 | 1 | 8 | +7 |
| Lamps / diya | Not previously run | 5 | 13 | +8 |
| Vessels / incense burner | 5 | 5 | 8 | +3 |
| Vessels / clay incense burner | Not previously run | 7 | 8 | +1 |

The prior scene-level counts were one lamp and five vessels, but alternative queries are new conditions, not like-for-like baseline reruns. The bicycle positive baseline is **1 -> 1**. Its exact coordinates, label and score reproduced, as did the same-query lamp and vessel baselines. [Exact reproducibility checks](phase4_iteration2_assets/baseline_reproducibility.json).

For every one of the four query pairs, all 0.30 predictions appear **exactly unchanged** in that query's 0.20 result (coordinates, scores and labels). [Subset checks](phase4_iteration2_assets/threshold_subset_checks.json). This is a consistency check on this run; it is not a detection-quality metric.

## 5. Execution and performance

Exact command used from the project root in PowerShell:

```powershell
$env:PYTHONPATH = (Resolve-Path .\src).Path
.\.venv\Scripts\python.exe -B scripts/evaluate_grounding_iteration2.py --out reports/phase4_iteration2_assets/runs
```

The output directory must be new. The [included research utility](phase4_iteration2_assets/evaluate_grounding_iteration2.py) contains the frozen matrix; it does not add a new application CLI behavior. The existing `ground --box-threshold ... --text-threshold ...` command also remains available, but was not used for ten separate model loads here.

| Condition | Load/check s | Preprocess s | Forward s | Postprocess s | Total stage s | Artifact saving s | Peak allocated CUDA MiB |
|---|---|---|---|---|---|---|---|
| R01_bicycle_replay | 12.557370 | 0.1296 | 1.7008 | 0.0213 | 14.4320 | 0.3705 | 1740.19 |
| A01_oil_lamp_030 | 0.000003 | 0.0715 | 1.2008 | 0.0019 | 1.3147 | 0.3481 | 1892.32 |
| A02_oil_lamp_020 | 0.000001 | 0.0978 | 0.4924 | 0.0055 | 0.5982 | 0.3373 | 1892.32 |
| A03_diya_030 | 0.000002 | 0.0794 | 0.5063 | 0.0029 | 0.5910 | 0.3180 | 1892.32 |
| A04_diya_020 | 0.000002 | 0.0926 | 0.5025 | 0.0040 | 0.6010 | 0.3258 | 1892.32 |
| B01_incense_burner_030 | 0.000002 | 0.0673 | 0.4683 | 0.0117 | 0.5499 | 0.2518 | 1813.82 |
| B02_incense_burner_020 | 0.000001 | 0.0662 | 0.4595 | 0.0035 | 0.5310 | 0.1895 | 1813.82 |
| B03_clay_incense_burner_030 | 0.000001 | 0.0598 | 0.4663 | 0.0034 | 0.5315 | 0.1842 | 1813.82 |
| B04_clay_incense_burner_020 | 0.000001 | 0.0599 | 0.4568 | 0.0036 | 0.5221 | 0.2721 | 1813.82 |
| N01_airplane_negative | 0.000001 | 0.0656 | 0.4294 | 0.0018 | 0.4989 | 0.3286 | 1740.50 |

First load: **12.557370 seconds**. Subsequent `load_seconds` values are just the guard/check overhead of reusing the model, not repeated checkpoint loading. For reused calls, the existing `load_peak_allocated_bytes` field records the resident pre-forward allocation high-water value, not a new loading event. The initial loading peak was **692084224 bytes (660.023 MiB)**. Exact byte counts and separate preprocessing/forward/postprocessing times are preserved in JSON.

All ten calls ran on CUDA without errors or CPU fallback. Peak allocated inference memory ranged approximately **1740.19-1892.32 MiB**, including resident model tensors. It excludes other applications, driver/context memory and reserved-but-unused allocator blocks. Before the study `nvidia-smi` showed **1506 MiB globally used**; after detector shutdown it showed **1145 MiB**. These are snapshots, not global peak measurements or a claim that this detector alone consumed their difference.

Forward timings use CUDA synchronization. Total stage time excludes Python startup, image decoding before the stage timer, initial checkpoint download and artifact saving. First-image/shape warm-up and fixed run order affect timing: R01 took 1.701 seconds, A01 1.201 seconds, and remaining forwards about 0.429-0.506 seconds. Do **not** attribute the apparent speed difference to lowering a postprocessing threshold. This was not a randomized or repeated latency benchmark.

## 6. Side-by-side threshold sensitivity

Each pair below uses unchanged annotated source-size copies: **0.30 on the left, 0.20 on the right**, text threshold 0.25 in both. The original images are linked above, and every condition's original-vs-annotated view is linked in the per-box appendix. All comparisons were visually inspected. Original-vs-annotated views have a 40-pixel title strip; threshold-pair views have a 48-pixel title strip. Those headers and the right-panel display offset are not part of the recorded source-image coordinates.

### Oil lamp

![Oil lamp threshold comparison](phase4_iteration2_assets/threshold_comparison_oil_lamp.png)

A01 finds the central burning lamp. A02 adds weaker rear and upper-right lamp regions and the middle-left lamp, but the latter has two overlapping predictions. A02 also includes a broad left foreground vessel region, a right-side metal vessel, and a lower-right filled container whose identity as a lamp is uncertain. Lower threshold improves apparent coverage of some visible lamps while admitting ambiguous/non-target regions. The leftmost partially obscured lamp is not cleanly isolated; a tall box includes adjacent vessel/background.

### Diya

![Diya threshold comparison](phase4_iteration2_assets/threshold_comparison_diya.png)

A03 returns the central, upper-right and rear-central burning-lamp regions, but also an upper-left fruit-shaped region and a lower-right filled container of uncertain identity. It misses the middle-left burning lamp at 0.30. A04 recovers that lamp with overlapping extents, yet adds fruit-like regions, a coin-stack region, a possible unlit rear bowl, the right-side metal container and an almost-whole-image box. Thirteen boxes are **not** thirteen confidently localized lamps. The partial leftmost lamp still lacks a clean individual prediction.

### Incense burner

![Incense burner threshold comparison](phase4_iteration2_assets/threshold_comparison_incense_burner.png)

B01 repeats the five prior held-vessel boxes and misses the visible far-right bowl-shaped vessel. B02 adds that edge region, with two overlapping boxes of different vertical extent, and a decorated face/ornament region on the idol rather than a held vessel. The additional edge scores are approximately **0.270615** and **0.295206**, explaining why these predictions are below the original 0.30 cutoff. This does not verify their cultural identity.

### Clay incense burner

![Clay incense burner threshold comparison](phase4_iteration2_assets/threshold_comparison_clay_incense_burner.png)

B03 places seven boxes on apparently six distinct visible held-vessel regions: the far-right object has two overlapping predictions (scores approximately **0.326066** and **0.328748**). Those values cross 0.30 with this specified wording. The five original vessel-region scores also increase in this comparison. B04 adds a decorated face/ornament-region box at **0.214433** with an empty returned text label; it does not establish an additional held vessel. No duplicate was silently collapsed, and none of these query strings establishes a verified object name or material.

### Text-label sensitivity

At box threshold 0.20, a candidate can pass box filtering while no text token passes text threshold 0.25. The actual decoded label can therefore be empty. A02 has **4 empty labels**, A04 **6**, B04 **1**. A02 also returns the partial label `oil` for a broad vessel region. Empty and partial labels remain exactly as returned in JSON; the code did not fill them with the requested phrase. They are numerically valid predictions requiring semantic review, not confirmed object identities.

### Why more boxes is not the objective

Several newly admitted boxes correspond to repeated predictions of the same apparent object, another kind of container, fruit/coins, an idol region or multiple objects at once. The controlled experiment supports query/threshold sensitivity, not a universal best threshold or culturally correct vocabulary. Leave the production default at **0.30/0.25**. No default was updated on the basis of these two images.

## 7. Negative control: bicycle image queried as airplane

**Before inference**, the original bicycle image was inspected and documented in the predeclared plan: it shows a parked bicycle, building facade, doors, graffiti and pavement. No recognizable airplane or reasonable aircraft object was visible. Abstract graffiti is present; the inspection does not claim to decode every mark.

The detector nevertheless returned:

```json
{
  "box": [
    441.4779052734375,
    581.3060913085938,
    952.7521362304688,
    924.2832641601562
  ],
  "score": 0.4191797375679016,
  "label": "airplane"
}
```

![Airplane negative control: original vs actual prediction](phase4_iteration2_assets/runs/N01_airplane_negative/comparison.png)

Visual inspection shows the box encloses the **bicycle**, not an airplane. This is a clear query/object mismatch in this image. It remains in the raw and numerically validated output; `DETECTED` only means returned boxes, not semantic acceptance. The box is finite, ordered, in bounds and scored within [0,1], so the geometric validator properly does not pretend to prove object identity.

The 0.419 score exceeds the original central lamp's 0.314 score, illustrating why confidence alone cannot establish a universal semantic acceptance cutoff. No extra airplane thresholds/phrases or attempts to remove the result were made. A single negative control demonstrates this failure case, not general false-positive rate, precision or specificity. We cannot determine the complete model-level cause from this one diagnostic; a salient-object/query mismatch is observed, while causal explanations remain hypotheses.

## 8. Positive baseline replay

![Bicycle positive replay](phase4_iteration2_assets/runs/R01_bicycle_replay/comparison.png)

Bicycle replay coordinates **[441.8973388671875, 581.3589477539062, 953.31396484375, 924.9127197265625]**, score **0.9432805180549622**, label **bicycle** are exactly equal to iteration 1. The box appears to enclose the bicycle including wheels, frame, handlebar and saddle, with unavoidable rectangular wall/pavement background. This is a reasonable single-instance box for future human-reviewed segmentation research, not evidence of a pixel-accurate mask or authorization to modify it.

Preserved iteration 1 evidence: [bicycle JSON](phase4_iteration2_assets/iteration1_baseline/A_bicycle/detection.json), [lamp JSON](phase4_iteration2_assets/iteration1_baseline/B_oil_lamp/detection.json), [vessel JSON](phase4_iteration2_assets/iteration1_baseline/C_incense_burner/detection.json). These are unchanged copies, not overwritten baseline files.

## 9. What these boxes tell us about future SAM input

No SAM model, masks or segmentation metrics were implemented or run. Every one of the **57** predicted boxes has a subjective extent/identity/SAM-prompt assessment in the appendix and [visual assessment JSON](phase4_iteration2_assets/visual_assessment.json). These notes are visual engineering judgments, not independent annotation or proof SAM would succeed.

- The positive bicycle and central lamp boxes are reasonable single-object starting regions after human confirmation. Thin bicycle parts and lamp bases still need mask-level evaluation later.
- Many held-vessel boxes bound the bowl body plausibly; some put bases/handles/grips near or outside the boundary. Whether the intended target includes those parts must be decided explicitly. Identity and intended instance remain unverified.
- The leftmost and rightmost vessels are cropped by the original image. No bounding box can recover unseen portions beyond the image.
- Tall edge-vessel boxes include more hand/support than shorter duplicates. Retain both; the system has not chosen the intended extent automatically.
- The broad left lamp-scene box and nearly whole-scene A04 box contain multiple objects/context and are poor prompts for isolating a specified single lamp.
- Fruit, coin, idol-region and negative airplane/bicycle mismatches are unsuitable prompts for the corresponding requested object, even though their numeric coordinates are valid. A later segmentation stage must not be assumed to fix an incorrect target selection.

No independent ground-truth boxes were available. The [human prediction-review worksheet](phase4_iteration2_assets/human_review.csv) pre-fills only condition IDs and raw predicted fields; all human judgment fields are blank. The [missed-instance worksheet](phase4_iteration2_assets/human_missing_instances.csv) leaves independent descriptions/optional ground-truth coordinates blank. No manual target boxes or fabricated expert labels were supplied. A reviewer can assess intended match, full extent, background, cutoffs, merges, duplicates and prospective SAM suitability separately.

## 10. Regression, safeguards and Git diff

| Check | Before | After |
|---|---|---|
| Offline suite | 95 tests, 0.535 s, OK | 95 tests, 0.435 s, OK |
| Failures/errors | 0 / 0 | 0 / 0 |
| Original default thresholds | 0.30 / 0.25 | 0.30 / 0.25, unchanged |
| Existing files | 407 snapshotted | 407 unchanged, none missing |

[Test summary](phase4_iteration2_assets/test_summary.json), [before output](phase4_iteration2_assets/tests_before.txt), [after output](phase4_iteration2_assets/tests_after.txt).

No focused application tests were added because no application CLI/configuration behavior changed. Existing tests cover numeric box checks, no/multiple detections, invalid coordinates, JSON, visualization/source protection, lazy loading, CUDA/mock failures and refusal of REVIEW/ABSTAIN planner objects. Existing planning quarantine/policy tests also continue to pass. The runner uses explicit research strings; no planner adapter, rejected-candidate access or editing stage exists. This preserves the distinction between a research query and approved cultural editing.

Iteration 2 changes: **one new 87-line experiment script**, the new consolidated review and new evidence/ZIP. No existing application, test, default configuration or dependency files changed. The pre-existing working-tree diff belongs to earlier work and was not overwritten. [Task-scoped diff summary](phase4_iteration2_assets/git_diff_summary.txt) and [recorded Git status](phase4_iteration2_assets/git_status_after.txt). Nothing was committed, pushed, deleted or moved to an archive.

For review, unchanged relevant source/test snapshots are included under [implementation](phase4_iteration2_assets/implementation/src/transcreation/stages/grounding.py). The previous research ZIP and all earlier images/results remain untouched in the repository.

## 11. Acceptance assessment and limitations

| Acceptance point | Evidence and status |
|---|---|
| Original coordinates and numeric validation | All 57 outputs finite/ordered/in bounds with valid scores; zero invalid predictions. Numeric validity does not prove semantic correctness. |
| Bicycle reproducibility | Exact match with original coordinates, score and label on the unchanged input. |
| At least one reasonable individual box | Bicycle and central lamp are visually plausible repeated-baseline examples; future SAM performance remains untested. |
| Misses and false positives understood/documented | Missed visible lamps, recovered edge vessel, duplicate extents, false/query-mismatch regions and negative-control failure documented. Causal explanation is incomplete. |
| Multiple detections retained | All predictions, including duplicates, broad boxes and empty labels, saved; no top-one selection. |
| Feasible on hardware | All ten calls successful on CUDA; peak allocated memory below 1.9 GiB; no concurrent VLM/LLM loading. |
| REVIEW/ABSTAIN restrictions | Existing policies/guards unchanged, tests pass; only explicit research phrases used. |
| Regression safety | 95 before and 95 after, all passing; all baseline file hashes preserved. |

**Limits:** only two varied source images, one negative control and one unchanged positive replay; fixed order and one forward timing sample per condition; no independent human annotation, no IoU/precision/recall/accuracy metrics, no calibrated class confidence, no robustness claim for unseen scenes. Query wording does not verify clay material or ritual function. Occlusion, small extent, edge cropping and low light are visible factors that may contribute to misses, but their causal contribution was not isolated. CPU fallback and simultaneous model residency were not tested in this study.

**Recommendation: NEEDS FIXES before unchecked downstream integration.** Complete lamp coverage is not required for a single-object workflow and is not the reason for this recommendation. The unresolved semantic negative-control failure, duplicate-instance/extent ambiguity and blank/partial labels mean selection still needs explicit review. A mentor may judge the human-reviewed single-box research milestone adequate; this package does not authorize automatic target selection or the next phase.

Future decisions requiring mentor evaluation include how an intended source object's identity/instance should be confirmed, how to retain or resolve duplicate extents without arbitrary selection, and what evidence is needed for reliable box prompts. None of those policies were silently added in this iteration. No new model, fine-tuning, architecture change, SAM or diffusion was introduced.

## 12. Portable package and provenance

`phase4_iteration2_review.zip` includes this Markdown, every condition's detection/validation JSON, original-vs-annotated and threshold comparisons, annotated images, the three exact source JPEGs, baseline evidence copies, configuration/environment/run metadata, test/preservation summaries, blank human-review worksheets, per-box subjective assessments and the reproducible research script. All report links are relative and intended to work after extraction. No model weights, environments, unrelated datasets or secrets belong in the package. [Final evidence consistency checks](phase4_iteration2_assets/verification.json).

Source provenance is copied from the project's existing manifest: bicycle by Basile Morin, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/), [Wikimedia source](https://commons.wikimedia.org/wiki/File:Parked_bicycle_with_graffitied_building_facade_and_doors_in_Amsterdam.jpg); lamps by Benoy, [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/), [Wikimedia source](https://commons.wikimedia.org/wiki/File:Diwali_Oil_lamps_Darjeeling.jpg). Annotation/comparison derivatives retain the respective source attribution/license. Durga image is user-provided local research material; author/license was not recorded, so external publication permission remains unverified. The package is for project/mentor review.

## Appendix: all actual predictions and individual visual assessments

Coordinates below are in original-image pixels and displayed to three decimals. Scores are displayed to nine decimals. The linked JSONs retain full precision, labels exactly as decoded, original dimensions, source SHA-256, pinned revision, effective processor/settings, observations and measurements. Numeric-valid predictions include semantically wrong ones; that distinction is deliberate. Per-box notes are subjective assistant visual inspection and do not populate the blank human-review fields.

### R01_bicycle_replay

Query `bicycle`; exact normalized prompt `bicycle.`; box/text thresholds **0.30/0.25**; dimensions **1280 x 966** (width x height); status `DETECTED`.

[Detection JSON](phase4_iteration2_assets/runs/R01_bicycle_replay/detection.json) | [Separate numeric validation record](phase4_iteration2_assets/runs/R01_bicycle_replay/validation.json) | [Original vs annotated comparison](phase4_iteration2_assets/runs/R01_bicycle_replay/comparison.png) | [Annotated source-size image](phase4_iteration2_assets/runs/R01_bicycle_replay/annotated.png)

| # | Original XYXY pixels (rounded to 3 decimals) | Returned label | Score | Subjective region/extent assessment | Prospective SAM-box assessment, not tested |
|---|---|---|---|---|---|
| 1 | [441.897, 581.359, 953.314, 924.913] | `bicycle` | 0.943280518 | bicycle: One bicycle largely enclosed including wheels/frame/saddle/handlebar; some rectangular wall/pavement background; no obvious multi-object merge. | reasonable single-instance box to review; thin structures remain a segmentation challenge |


### A01_oil_lamp_030

Query `oil lamp`; exact normalized prompt `oil lamp.`; box/text thresholds **0.30/0.25**; dimensions **1280 x 842** (width x height); status `DETECTED`.

[Detection JSON](phase4_iteration2_assets/runs/A01_oil_lamp_030/detection.json) | [Separate numeric validation record](phase4_iteration2_assets/runs/A01_oil_lamp_030/validation.json) | [Original vs annotated comparison](phase4_iteration2_assets/runs/A01_oil_lamp_030/comparison.png) | [Annotated source-size image](phase4_iteration2_assets/runs/A01_oil_lamp_030/annotated.png)

| # | Original XYXY pixels (rounded to 3 decimals) | Returned label | Score | Subjective region/extent assessment | Prospective SAM-box assessment, not tested |
|---|---|---|---|---|---|
| 1 | [631.444, 248.133, 889.332, 443.255] | `oil lamp` | 0.314222395 | central burning lamp: Bowl/flame mostly enclosed; some tray/background; base near boundary; no obvious multi-object merge. | reasonable single-instance box to review; full base must be checked |


### A02_oil_lamp_020

Query `oil lamp`; exact normalized prompt `oil lamp.`; box/text thresholds **0.20/0.25**; dimensions **1280 x 842** (width x height); status `DETECTED`.

[Detection JSON](phase4_iteration2_assets/runs/A02_oil_lamp_020/detection.json) | [Separate numeric validation record](phase4_iteration2_assets/runs/A02_oil_lamp_020/validation.json) | [Original vs annotated comparison](phase4_iteration2_assets/runs/A02_oil_lamp_020/comparison.png) | [Annotated source-size image](phase4_iteration2_assets/runs/A02_oil_lamp_020/annotated.png)

| # | Original XYXY pixels (rounded to 3 decimals) | Returned label | Score | Subjective region/extent assessment | Prospective SAM-box assessment, not tested |
|---|---|---|---|---|---|
| 1 | [735.283, 62.248, 927.810, 220.550] | `oil lamp` | 0.278545618 | rear central burning lamp: One lamp/flame largely enclosed; modest background; lower support near box edge. | reasonable single-instance box to review |
| 2 | [1123.555, 181.269, 1278.006, 528.774] | `oil lamp` | 0.278792411 | right-edge metal container: Large metallic vessel cropped by image; not a clearly visible individual lamp. | unsuitable for the intended lamp query without separate verification |
| 3 | [631.444, 248.133, 889.332, 443.255] | `oil lamp` | 0.314222395 | central burning lamp: Bowl/flame mostly enclosed; some tray/background; base near boundary; no obvious multi-object merge. | reasonable single-instance box to review; full base must be checked |
| 4 | [897.961, 426.394, 1193.229, 681.946] | `""` (empty) | 0.239957988 | lower-right filled container: Container is enclosed with rice/context; lamp identity is uncertain from this image, not verified by its predicted label. | physical container could be prompted; review identity before any selection |
| 5 | [53.623, 180.763, 367.199, 707.692] | `oil` | 0.256409138 | left foreground vessel plus lamp context: Tall box includes substantial dark foreground vessel, nearby lamp and background; merged/ambiguous extent. | poor single-instance lamp prompt |
| 6 | [426.457, 120.357, 637.908, 284.011] | `""` (empty) | 0.224185213 | middle-left burning lamp, shorter duplicate: Lamp bowl/flame enclosed but lower support may be cut; overlaps taller prediction of same apparent instance. | review extent and duplicate ambiguity; do not silently select |
| 7 | [1031.105, 128.780, 1243.135, 297.040] | `""` (empty) | 0.209357068 | upper-right burning lamp: One visible lamp and flame mostly enclosed; small surrounding background; base near edge. | reasonable single-instance box to review |
| 8 | [425.938, 119.311, 638.420, 327.478] | `""` (empty) | 0.203360826 | middle-left burning lamp, taller duplicate: Includes more support/context; overlaps shorter prediction of same apparent instance. | review extent and duplicate ambiguity; do not silently select |


### A03_diya_030

Query `diya`; exact normalized prompt `diya.`; box/text thresholds **0.30/0.25**; dimensions **1280 x 842** (width x height); status `DETECTED`.

[Detection JSON](phase4_iteration2_assets/runs/A03_diya_030/detection.json) | [Separate numeric validation record](phase4_iteration2_assets/runs/A03_diya_030/validation.json) | [Original vs annotated comparison](phase4_iteration2_assets/runs/A03_diya_030/comparison.png) | [Annotated source-size image](phase4_iteration2_assets/runs/A03_diya_030/annotated.png)

| # | Original XYXY pixels (rounded to 3 decimals) | Returned label | Score | Subjective region/extent assessment | Prospective SAM-box assessment, not tested |
|---|---|---|---|---|---|
| 1 | [898.943, 437.911, 1194.177, 680.551] | `diya` | 0.413595974 | lower-right filled container: Container is enclosed with rice/context; lamp identity is uncertain from this image, not verified by its predicted label. | physical container could be prompted; review identity before any selection |
| 2 | [1031.793, 130.433, 1245.475, 296.572] | `diya` | 0.350991249 | upper-right burning lamp: One visible lamp and flame mostly enclosed; small surrounding background; base near edge. | reasonable single-instance box to review |
| 3 | [239.451, 29.393, 458.871, 242.191] | `diya` | 0.302671790 | upper-left fruit-shaped object: Box primarily encloses fruit, with adjacent context near lower edge; not an isolated lamp. | unsuitable lamp prompt: apparent query mismatch |
| 4 | [735.639, 63.895, 927.335, 219.189] | `diya` | 0.304758042 | rear central burning lamp: One lamp/flame largely enclosed; modest background; lower support near box edge. | reasonable single-instance box to review |
| 5 | [632.192, 249.282, 888.859, 440.627] | `diya` | 0.361850888 | central burning lamp: Bowl/flame mostly enclosed; some tray/background; base near boundary; no obvious multi-object merge. | reasonable single-instance box to review; full base must be checked |


### A04_diya_020

Query `diya`; exact normalized prompt `diya.`; box/text thresholds **0.20/0.25**; dimensions **1280 x 842** (width x height); status `DETECTED`.

[Detection JSON](phase4_iteration2_assets/runs/A04_diya_020/detection.json) | [Separate numeric validation record](phase4_iteration2_assets/runs/A04_diya_020/validation.json) | [Original vs annotated comparison](phase4_iteration2_assets/runs/A04_diya_020/comparison.png) | [Annotated source-size image](phase4_iteration2_assets/runs/A04_diya_020/annotated.png)

| # | Original XYXY pixels (rounded to 3 decimals) | Returned label | Score | Subjective region/extent assessment | Prospective SAM-box assessment, not tested |
|---|---|---|---|---|---|
| 1 | [898.943, 437.911, 1194.177, 680.551] | `diya` | 0.413595974 | lower-right filled container: Container is enclosed with rice/context; lamp identity is uncertain from this image, not verified by its predicted label. | physical container could be prompted; review identity before any selection |
| 2 | [1031.793, 130.433, 1245.475, 296.572] | `diya` | 0.350991249 | upper-right burning lamp: One visible lamp and flame mostly enclosed; small surrounding background; base near edge. | reasonable single-instance box to review |
| 3 | [239.451, 29.393, 458.871, 242.191] | `diya` | 0.302671790 | upper-left fruit-shaped object: Box primarily encloses fruit, with adjacent context near lower edge; not an isolated lamp. | unsuitable lamp prompt: apparent query mismatch |
| 4 | [735.639, 63.895, 927.335, 219.189] | `diya` | 0.304758042 | rear central burning lamp: One lamp/flame largely enclosed; modest background; lower support near box edge. | reasonable single-instance box to review |
| 5 | [860.045, 0.445, 1077.104, 172.027] | `diya` | 0.290224344 | upper-right rear fruit-shaped object: Box encloses background fruit-like object, not a visible lamp; image top crops its extent. | unsuitable lamp prompt: apparent query mismatch |
| 6 | [426.671, 120.971, 637.747, 285.055] | `""` (empty) | 0.211016744 | middle-left burning lamp, shorter duplicate: Lamp bowl/flame enclosed but lower support may be cut; overlaps taller prediction of same apparent instance. | review extent and duplicate ambiguity; do not silently select |
| 7 | [632.192, 249.282, 888.859, 440.627] | `diya` | 0.361850888 | central burning lamp: Bowl/flame mostly enclosed; some tray/background; base near boundary; no obvious multi-object merge. | reasonable single-instance box to review; full base must be checked |
| 8 | [345.578, 606.198, 788.157, 839.415] | `""` (empty) | 0.219497919 | foreground fruit-shaped object: Box encloses large lower fruit-like object with plate/context; object is cropped by image bottom. | unsuitable lamp prompt: apparent query mismatch |
| 9 | [9.490, 4.671, 1274.891, 836.446] | `""` (empty) | 0.208175927 | almost the entire image: Multiple lamps, vessels, fruit and background merged inside one broad rectangle. | unsuitable for isolating a single intended instance |
| 10 | [428.756, 396.951, 549.629, 525.909] | `""` (empty) | 0.201054156 | coin-stack region: Small coin-like items and nearby rice/background; not a visible lamp. | unsuitable lamp prompt: apparent query mismatch |
| 11 | [549.918, 51.161, 720.837, 190.387] | `""` (empty) | 0.211275250 | small rear bowl or possible unlit lamp: Small bowl region enclosed; no obvious flame, with partial occlusion; identity uncertain. | box may isolate a container; human identity/extent review required |
| 12 | [1123.852, 183.208, 1278.424, 525.139] | `diya` | 0.278878480 | right-edge metal container: Large metallic vessel cropped by image; not a clearly visible individual lamp. | unsuitable for the intended lamp query without separate verification |
| 13 | [426.380, 120.915, 638.119, 322.246] | `""` (empty) | 0.200121388 | middle-left burning lamp, taller duplicate: Includes more support/context; overlaps shorter prediction of same apparent instance. | review extent and duplicate ambiguity; do not silently select |


### B01_incense_burner_030

Query `incense burner`; exact normalized prompt `incense burner.`; box/text thresholds **0.30/0.25**; dimensions **980 x 692** (width x height); status `DETECTED`.

[Detection JSON](phase4_iteration2_assets/runs/B01_incense_burner_030/detection.json) | [Separate numeric validation record](phase4_iteration2_assets/runs/B01_incense_burner_030/validation.json) | [Original vs annotated comparison](phase4_iteration2_assets/runs/B01_incense_burner_030/comparison.png) | [Annotated source-size image](phase4_iteration2_assets/runs/B01_incense_burner_030/annotated.png)

| # | Original XYXY pixels (rounded to 3 decimals) | Returned label | Score | Subjective region/extent assessment | Prospective SAM-box assessment, not tested |
|---|---|---|---|---|---|
| 1 | [432.901, 318.794, 516.653, 390.961] | `incense burner` | 0.416083962 | central held bowl-shaped vessel: Bowl body enclosed; lower base/grip near boundary; modest sky/smoke context; no obvious merge. | reasonable visible-body box after identity and full-base review |
| 2 | [0.506, 216.004, 95.623, 294.683] | `incense burner` | 0.423855841 | left-edge held vessel: Visible bowl mostly enclosed; vessel itself is cropped by source image left boundary. | visible portion only; cannot recover parts outside the original image |
| 3 | [141.255, 279.783, 221.294, 346.891] | `incense burner` | 0.413017392 | middle-left held vessel: Bowl body enclosed; lower base/support near boundary; some hand/background context. | reasonable visible-body box; verify whether base needs a larger extent |
| 4 | [752.651, 250.714, 846.418, 345.236] | `incense burner` | 0.372171193 | upper-right held vessel: Body/base largely enclosed; hand touches lower boundary; modest smoke/sky context. | reasonable single-instance box to review |
| 5 | [283.331, 315.683, 365.126, 380.855] | `incense burner` | 0.386055857 | left-of-center held vessel: Bowl body enclosed; narrow base/support near bottom edge; modest smoke/background. | reasonable visible-body box after identity/extent review |


### B02_incense_burner_020

Query `incense burner`; exact normalized prompt `incense burner.`; box/text thresholds **0.20/0.25**; dimensions **980 x 692** (width x height); status `DETECTED`.

[Detection JSON](phase4_iteration2_assets/runs/B02_incense_burner_020/detection.json) | [Separate numeric validation record](phase4_iteration2_assets/runs/B02_incense_burner_020/validation.json) | [Original vs annotated comparison](phase4_iteration2_assets/runs/B02_incense_burner_020/comparison.png) | [Annotated source-size image](phase4_iteration2_assets/runs/B02_incense_burner_020/annotated.png)

| # | Original XYXY pixels (rounded to 3 decimals) | Returned label | Score | Subjective region/extent assessment | Prospective SAM-box assessment, not tested |
|---|---|---|---|---|---|
| 1 | [432.901, 318.794, 516.653, 390.961] | `incense burner` | 0.416083962 | central held bowl-shaped vessel: Bowl body enclosed; lower base/grip near boundary; modest sky/smoke context; no obvious merge. | reasonable visible-body box after identity and full-base review |
| 2 | [0.506, 216.004, 95.623, 294.683] | `incense burner` | 0.423855841 | left-edge held vessel: Visible bowl mostly enclosed; vessel itself is cropped by source image left boundary. | visible portion only; cannot recover parts outside the original image |
| 3 | [141.255, 279.783, 221.294, 346.891] | `incense burner` | 0.413017392 | middle-left held vessel: Bowl body enclosed; lower base/support near boundary; some hand/background context. | reasonable visible-body box; verify whether base needs a larger extent |
| 4 | [752.651, 250.714, 846.418, 345.236] | `incense burner` | 0.372171193 | upper-right held vessel: Body/base largely enclosed; hand touches lower boundary; modest smoke/sky context. | reasonable single-instance box to review |
| 5 | [889.701, 267.348, 979.038, 380.065] | `incense burner` | 0.270615041 | far-right held vessel, taller overlapping box: Vessel body plus gripping hand/support; source image crops its right edge; overlaps shorter box for same apparent vessel. | review hand inclusion and duplicate ambiguity; no automatic instance choice |
| 6 | [283.331, 315.683, 365.126, 380.855] | `incense burner` | 0.386055857 | left-of-center held vessel: Bowl body enclosed; narrow base/support near bottom edge; modest smoke/background. | reasonable visible-body box after identity/extent review |
| 7 | [713.412, 402.316, 791.414, 505.891] | `incense burner` | 0.271900892 | decorated face/ornament region on idol: Box is over a decorated face/ornament region rather than a held bowl-shaped vessel. | unsuitable vessel prompt: apparent query mismatch |
| 8 | [889.842, 267.591, 978.992, 348.770] | `incense burner` | 0.295206219 | far-right held vessel, shorter overlapping box: Bowl body enclosed, lower grip/support excluded; cropped by source right boundary; overlaps taller box. | reasonable visible-body candidate, but duplicate/extent review required |


### B03_clay_incense_burner_030

Query `clay incense burner`; exact normalized prompt `clay incense burner.`; box/text thresholds **0.30/0.25**; dimensions **980 x 692** (width x height); status `DETECTED`.

[Detection JSON](phase4_iteration2_assets/runs/B03_clay_incense_burner_030/detection.json) | [Separate numeric validation record](phase4_iteration2_assets/runs/B03_clay_incense_burner_030/validation.json) | [Original vs annotated comparison](phase4_iteration2_assets/runs/B03_clay_incense_burner_030/comparison.png) | [Annotated source-size image](phase4_iteration2_assets/runs/B03_clay_incense_burner_030/annotated.png)

| # | Original XYXY pixels (rounded to 3 decimals) | Returned label | Score | Subjective region/extent assessment | Prospective SAM-box assessment, not tested |
|---|---|---|---|---|---|
| 1 | [432.868, 318.808, 516.677, 392.716] | `clay incense burner` | 0.486300677 | central held bowl-shaped vessel: Bowl body enclosed; lower base/grip near boundary; modest sky/smoke context; no obvious merge. | reasonable visible-body box after identity and full-base review |
| 2 | [0.523, 216.077, 95.622, 294.697] | `clay incense burner` | 0.450535566 | left-edge held vessel: Visible bowl mostly enclosed; vessel itself is cropped by source image left boundary. | visible portion only; cannot recover parts outside the original image |
| 3 | [141.240, 279.867, 221.353, 345.884] | `clay incense burner` | 0.464999974 | middle-left held vessel: Bowl body enclosed; lower base/support near boundary; some hand/background context. | reasonable visible-body box; verify whether base needs a larger extent |
| 4 | [752.561, 251.491, 846.450, 342.628] | `clay incense burner` | 0.441206127 | upper-right held vessel: Body/base largely enclosed; hand touches lower boundary; modest smoke/sky context. | reasonable single-instance box to review |
| 5 | [889.668, 267.482, 979.033, 380.135] | `clay incense burner` | 0.326066494 | far-right held vessel, taller overlapping box: Vessel body plus gripping hand/support; source image crops its right edge; overlaps shorter box for same apparent vessel. | review hand inclusion and duplicate ambiguity; no automatic instance choice |
| 6 | [283.336, 315.566, 365.145, 383.193] | `clay incense burner` | 0.439916521 | left-of-center held vessel: Bowl body enclosed; narrow base/support near bottom edge; modest smoke/background. | reasonable visible-body box after identity/extent review |
| 7 | [889.770, 267.630, 978.987, 349.087] | `clay incense burner` | 0.328747779 | far-right held vessel, shorter overlapping box: Bowl body enclosed, lower grip/support excluded; cropped by source right boundary; overlaps taller box. | reasonable visible-body candidate, but duplicate/extent review required |


### B04_clay_incense_burner_020

Query `clay incense burner`; exact normalized prompt `clay incense burner.`; box/text thresholds **0.20/0.25**; dimensions **980 x 692** (width x height); status `DETECTED`.

[Detection JSON](phase4_iteration2_assets/runs/B04_clay_incense_burner_020/detection.json) | [Separate numeric validation record](phase4_iteration2_assets/runs/B04_clay_incense_burner_020/validation.json) | [Original vs annotated comparison](phase4_iteration2_assets/runs/B04_clay_incense_burner_020/comparison.png) | [Annotated source-size image](phase4_iteration2_assets/runs/B04_clay_incense_burner_020/annotated.png)

| # | Original XYXY pixels (rounded to 3 decimals) | Returned label | Score | Subjective region/extent assessment | Prospective SAM-box assessment, not tested |
|---|---|---|---|---|---|
| 1 | [432.868, 318.808, 516.677, 392.716] | `clay incense burner` | 0.486300677 | central held bowl-shaped vessel: Bowl body enclosed; lower base/grip near boundary; modest sky/smoke context; no obvious merge. | reasonable visible-body box after identity and full-base review |
| 2 | [0.523, 216.077, 95.622, 294.697] | `clay incense burner` | 0.450535566 | left-edge held vessel: Visible bowl mostly enclosed; vessel itself is cropped by source image left boundary. | visible portion only; cannot recover parts outside the original image |
| 3 | [141.240, 279.867, 221.353, 345.884] | `clay incense burner` | 0.464999974 | middle-left held vessel: Bowl body enclosed; lower base/support near boundary; some hand/background context. | reasonable visible-body box; verify whether base needs a larger extent |
| 4 | [752.561, 251.491, 846.450, 342.628] | `clay incense burner` | 0.441206127 | upper-right held vessel: Body/base largely enclosed; hand touches lower boundary; modest smoke/sky context. | reasonable single-instance box to review |
| 5 | [889.668, 267.482, 979.033, 380.135] | `clay incense burner` | 0.326066494 | far-right held vessel, taller overlapping box: Vessel body plus gripping hand/support; source image crops its right edge; overlaps shorter box for same apparent vessel. | review hand inclusion and duplicate ambiguity; no automatic instance choice |
| 6 | [283.336, 315.566, 365.145, 383.193] | `clay incense burner` | 0.439916521 | left-of-center held vessel: Bowl body enclosed; narrow base/support near bottom edge; modest smoke/background. | reasonable visible-body box after identity/extent review |
| 7 | [889.770, 267.630, 978.987, 349.087] | `clay incense burner` | 0.328747779 | far-right held vessel, shorter overlapping box: Bowl body enclosed, lower grip/support excluded; cropped by source right boundary; overlaps taller box. | reasonable visible-body candidate, but duplicate/extent review required |
| 8 | [713.611, 402.363, 791.280, 506.121] | `""` (empty) | 0.214433372 | decorated face/ornament region on idol: Box is over a decorated face/ornament region rather than a held bowl-shaped vessel. | unsuitable vessel prompt: apparent query mismatch |


### N01_airplane_negative

Query `airplane`; exact normalized prompt `airplane.`; box/text thresholds **0.30/0.25**; dimensions **1280 x 966** (width x height); status `DETECTED`.

[Detection JSON](phase4_iteration2_assets/runs/N01_airplane_negative/detection.json) | [Separate numeric validation record](phase4_iteration2_assets/runs/N01_airplane_negative/validation.json) | [Original vs annotated comparison](phase4_iteration2_assets/runs/N01_airplane_negative/comparison.png) | [Annotated source-size image](phase4_iteration2_assets/runs/N01_airplane_negative/annotated.png)

| # | Original XYXY pixels (rounded to 3 decimals) | Returned label | Score | Subjective region/extent assessment | Prospective SAM-box assessment, not tested |
|---|---|---|---|---|---|
| 1 | [441.478, 581.306, 952.752, 924.283] | `airplane` | 0.419179738 | bicycle, despite predicted airplane label: Box encloses the bicycle; no visible airplane; coordinate validation passes despite semantic mismatch. | unsuitable airplane prompt; do not suppress or reinterpret the raw label |


The implementation/experiment and review package end here. Stop for independent mentor evaluation; no Phase 5 or automatic integration was started.
