# Repository cleanup review

Prepared 10 November 2026. Scope: documentation consolidation and conservative repository hygiene before Phase 6. No model inference, new feature, policy change, commit or push occurred.

## Outcome

**PASS for documentation/navigation and tested compatibility; substantial historical-file reduction remains pending approval.** Five canonical reports now provide the main reading path. Historical evidence paths remain intact. Phase 5 quality sign-off is still NEEDS FIXES / human review pending. This cleanup does not approve a mask or begin Phase 6.

## Before and after structure

Before (condensed; complete file-level tree is in the ZIP):

```text
MiniProject/
  configs/ models.yaml, planner.yaml, grounding.yaml, sam.yaml
  src/transcreation/ cli.py, config.py, contracts.py, pipeline.py, stages/
  scripts/ evaluations, box review, SAM, mask review
  tests/ regression tests and fixtures
  data/ outputs/ .local_archive/
  reports/
    overlapping VLM/planner summaries
    phase4_* and phase5_* iteration reports, asset folders and review ZIPs
    repository_cleanup_20261108/
  README.md (incorrectly said segmentation was unimplemented)
  ignored bytecode, local environments and generated installation files
```

After:

```text
MiniProject/
  configs/                         unchanged; sam.yaml retained
  src/transcreation/               unchanged application and contracts
  scripts/ tests/                   unchanged utilities and regression coverage
  data/ outputs/ .local_archive/    unchanged research inputs/history
  results/
    phase2_vlm/                    raw-evidence preservation ZIP and provenance index
    phase3_llm/README.md            exact planner trial paths
    phase4_grounding/README.md      baseline, sensitivity and box-review paths
    phase5_segmentation/README.md   masks, points and pending review paths
  reports/
    phase1_research.md
    phase2_vlm.md
    phase3_llm.md
    phase4_grounding.md
    phase5_segmentation.md
    repository_cleanup_review.md
    repository_cleanup_review.zip
    repository_cleanup_20261110/    inventories and verification evidence
    historical reports/assets      preserved, secondary reading material
  README.md .gitignore pyproject.toml
```

The diagram is a responsibility guide, not a mandate to rename working files. `config.py`, `pipeline.py`, `__init__.py` and `configs/sam.yaml` serve existing imports and commands and remain. No segmentation.yaml alias or Phase 6 folder/report was created.

## Inventory and counts

Content inventory before: **781 files; 470,782,048 bytes**. Content inventory excludes `.git/`, `.venv/`, `.python311/`, `.idea/` and this cleanup's audit directory. It includes ignored datasets, outputs and local archives. Exact final counts/bytes are in `size_summary.json`; file-level lists and trees use the same scope. Newly produced cleanup ZIP is reported separately so its changing size does not contaminate content comparisons.

**17 ignored bytecode files totaling 190,263 bytes were removed.** All were hash-checked against the inventory and confirmed Git-ignored; source, model caches, environments, datasets, research results and user notes were not deleted. Test runs used `-B`.

The raw inventory found 160 same-SHA groups with 104,383,642 redundant bytes counted across those groups. This is not a deletion recommendation: repeated source copies and masks can be necessary within self-contained evidence bundles. No duplicate research output was removed solely because its bytes match.

`inventory.json` classifies every inventoried path KEEP, CONSOLIDATE, REMOVE or REVIEW with a reason. No MOVE operation was justified; the exact move mapping is therefore **empty**. `move_deletion_manifest.json` lists every actual removed path, source/copy SHA and pending candidate. `git_before.json` includes untracked and ignored files. Local environments and Git internals are excluded from hash/count comparisons because they are not project research content; they remain untouched.

## Files kept and documentation consolidated

All application code, configs, fixtures, regression tests and necessary research scripts were retained. All original inference results, raw proposals, rejected candidates, model revisions, prompt documents, hashes, source copies and negative cases remain byte-identical. The Python AST/import audit found no unused-import candidates in active source/scripts/tests; definition occurrence counts are screening evidence, not proof of public API non-use. No code refactor was justified.

| Canonical report | Essential contents |
| --- | --- |
| [Phase 1](phase1_research.md) | Intended architecture, stage boundaries and missing original Phase 1 evidence |
| [Phase 2](phase2_vlm.md) | 11-image comparison, latency/memory, cultural coverage, hallucinations and failed truncation fixes |
| [Phase 3](phase3_llm.md) | Local Qwen setup, source/target failures, quarantine corrections and final raw/validated decisions |
| [Phase 4](phase4_grounding.md) | Baseline detections, fixed sensitivity matrix, airplane false positive and review provenance |
| [Phase 5](phase5_segmentation.md) | Box/point mask results, measured timings/memory, bicycle limitations and actual pending review status |

`consolidation_manifest.json` maps each report to its source evidence. Unique historical detail is preserved in the original reports, not silently discarded. Old documents remain secondary evidence, rather than additional current phase summaries.

README now states that SAM and reviews are implemented, distinguishes independent commands from an end-to-end pipeline, provides stage/test/review commands and links the five reports/results indexes. The prior README, report index and previous cleanup report are preserved byte-for-byte under `original_documents/` before their explicitly requested updates. The previous cleanup report is thus not lost when this required filename is reused.

`.gitignore` now excludes generated `reports/*review*.zip` from new Git additions. These local files are not deleted. The nonignored VLM preservation ZIP remains eligible for version control. No dependency or runtime configuration changed.

## Moves, copies and removals

No existing research file was moved. Results indexes organize phase 3–5 artifacts without duplicating them or breaking old references. The precise path mapping is `moves: []` in the manifest.

Twenty-eight selected VLM raw/provenance files were copied from `.local_archive/` into `results/phase2_vlm/historical_raw_evidence.zip`, with original relative entry names and SHA-256 verification of every extracted entry. This prevents the ignored local archive from being the only retained local copy of those selected raw findings. It is **not an independent external backup**, not the entire archive, and does not include every source image. No remote backup was verified. Important remaining original archive material stays intact and needs separate backup.

Only ignored regenerable bytecode was removed. Old ZIPs, screenshots, coordinate drafts, copied snapshots and potentially useful logs remain because untracked work, provenance and unique content cannot safely be discarded by file type alone. Source image rights were not broadened by copying evidence.

## Files awaiting approval or further investigation

The following paths were left unchanged. ZIPs alone occupy 210,925,746 bytes; this is potential review scope, not a claimed safe saving.

| Exact path | Reason |
| --- | --- |
| `reports/phase4_iteration2_review.zip` | Historical generated review ZIP: large and potentially overlapping, but untracked work and unique snapshots require preservation verification before removal. |
| `reports/phase4_iteration3_review.zip` | Historical generated review ZIP: large and potentially overlapping, but untracked work and unique snapshots require preservation verification before removal. |
| `reports/phase4_review_package.zip` | Historical generated review ZIP: large and potentially overlapping, but untracked work and unique snapshots require preservation verification before removal. |
| `reports/phase5_iteration1_review.zip` | Historical generated review ZIP: large and potentially overlapping, but untracked work and unique snapshots require preservation verification before removal. |
| `reports/phase5_iteration2_review.zip` | Historical generated review ZIP: large and potentially overlapping, but untracked work and unique snapshots require preservation verification before removal. |
| `reports/phase5_iteration3_review.zip` | Historical generated review ZIP: large and potentially overlapping, but untracked work and unique snapshots require preservation verification before removal. |
| `reports/experimentLLM.md` | Superseded reading material; canonical phase reports now summarize findings. Preserve original until unique details, citations and user work are approved for archival/removal. |
| `reports/phase4_grounding_review.md` | Superseded reading material; canonical phase reports now summarize findings. Preserve original until unique details, citations and user work are approved for archival/removal. |
| `reports/phase4_iteration2_review.md` | Superseded reading material; canonical phase reports now summarize findings. Preserve original until unique details, citations and user work are approved for archival/removal. |
| `reports/phase4_iteration3_review.md` | Superseded reading material; canonical phase reports now summarize findings. Preserve original until unique details, citations and user work are approved for archival/removal. |
| `reports/phase4_report.md` | Superseded reading material; canonical phase reports now summarize findings. Preserve original until unique details, citations and user work are approved for archival/removal. |
| `reports/phase5_iteration1_review.md` | Superseded reading material; canonical phase reports now summarize findings. Preserve original until unique details, citations and user work are approved for archival/removal. |
| `reports/phase5_iteration2_review.md` | Superseded reading material; canonical phase reports now summarize findings. Preserve original until unique details, citations and user work are approved for archival/removal. |
| `reports/phase5_iteration3_review.md` | Superseded reading material; canonical phase reports now summarize findings. Preserve original until unique details, citations and user work are approved for archival/removal. |
| `reports/Planner_Development_and_Validation_Report.md` | Superseded reading material; canonical phase reports now summarize findings. Preserve original until unique details, citations and user work are approved for archival/removal. |
| `reports/VLM_Selection_Experimental_Findings_Refined.md` | Superseded reading material; canonical phase reports now summarize findings. Preserve original until unique details, citations and user work are approved for archival/removal. |
| `src/transcreation/stages/inpainting.py` | Docstring-only future-stage placeholder; no imports/call sites found. Leave for owner review rather than changing package paths. |
| `.python311.nupkg` | Ignored local interpreter bootstrap; retain with environment. |
| `culture_transcreation.egg-info/` | Generated installation metadata may be used by editable installation; retain. |
| `sayan.md` | Ignored personal notes; leave unchanged. |

For all other same-SHA candidates, `duplicates.json` supplies exact paths and hashes. These include self-contained package source copies; removal requires checking archive coverage and consumers. No permanent deletion of potentially valuable evidence was performed.

## Tests and compatibility

| Check | Actual outcome |
| --- | --- |
| Baseline full suite | Ran 199 tests in 14.139s; OK, 0 failures/errors |
| After full suite | Ran 199 tests in 12.447s; OK, 0 failures/errors |
| Nine CLI help invocations before/after | All exit 0 |
| Existing deterministic compatibility utility | 33 saved audit replays and six planner input fixtures completed with mocked HTTP; no model inference |
| Caption/planner imports and all four configuration loaders | Passed read-only verification |
| Four original grounding review evidence sources | Hash/metadata validation passed |
| Five real PENDING mask requests | Evidence validated; every release attempt rejected |
| Installed console launcher | Stale legacy main reference repaired with editable reinstall; help now exit 0 |
| pip check | No broken requirements found |

The full suite includes planner PROPOSE/REVIEW/ABSTAIN, quarantine, transport/schema errors, invalid/tampered boxes and masks, research-only provenance and no-edit authorization restrictions. Historical source bytes and masks are checked rather than regenerated. This verifies the exercised fixture paths; it does not claim new real-model runtime equivalence.

Nine help commands: `transcreation.cli --help`, its caption/plan/ground subcommands, and `scripts.segment_sam`, `scripts.review_grounding`, `scripts.review_mask`, `scripts.evaluate_grounding_iteration2`, `scripts.evaluate_planner` with `--help`. The original installed `transcreate.exe` separately failed because it referenced retired `main`. Existing installation metadata was copied to `original_installation_metadata/`; `python -m pip install -e . --no-deps --no-build-isolation` refreshed the editable installation from unchanged pyproject.toml. The console launcher then passed `--help`. No dependencies changed. `launcher_repair.json` preserves the actual before/repair/after logs. The full suite was rerun after repair.

Read-only additional verification:

```powershell
$env:PYTHONPATH = (Resolve-Path .\src).Path
$env:HF_HUB_OFFLINE = "1"
.\.venv\Scripts\python.exe -B -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -B -m reports.repository_cleanup_20261110.verify_saved_evidence
```

The historical compatibility utility requires an output-path argument; a first diagnostic invocation omitted it and failed before saving. It was rerun correctly and completed. The new verification utility is run as a module so the project-root `scripts` namespace is available. These invocation errors did not modify evidence.

## References and reproducibility

All local Markdown links checked before cleanup resolved. Canonical and historical root-report links were checked after cleanup; final link counts and any broken targets are in `documentation_links.json`. No saved experiment JSON or measurements were rewritten to modernize paths. Directory links are validated for existence; remote URLs and Markdown heading anchors were not network-checked.

Source attribution is retained: bicycle Basile Morin / CC BY-SA 4.0; Diwali lamps Benoy / CC BY-SA 3.0; Durga user-supplied with unspecified rights. The results indexes contain original Commons references. Review ZIP exclusion does not remove the corresponding expanded evidence. Dataset paths remain local and mostly ignored: reproduction on another machine requires obtaining licensed source images or using source copies in the evidence folders.

Actual interpreter is the existing Python 3.11.9 virtual environment. Recorded installed versions: torch 2.15.0+cu132, transformers 4.57.6, Pillow 13.0.0, PyYAML 6.0.3, huggingface-hub 0.36.2. `dependencies.json` preserves the interpreter identity and versions; machine-local paths in audit logs are diagnostic metadata, not portable command requirements.

## Git diff and preservation

The working tree already contained modified application files and untracked phase 4/5 work before cleanup. `git_diff_before.json` and `git_before.json` preserve that baseline. Cleanup modifies only README.md, reports/README.md, reports/repository_cleanup_review.md and .gitignore, adds five canonical reports/results navigation/VLM preservation copy, and writes audit/package artifacts. It does not claim ownership of pre-existing code changes.

All original source, tests, scripts, configurations and result bytes must compare equal in `final_preservation.json`. The only altered original content files are the four explicitly documented documentation/ignore files; removed files must exactly match the 17-bytecode manifest. Original versions of the three rewritten Markdown files are retained. Full current Git diff and a cleanup-only change manifest are included separately; untracked additions are explicitly listed rather than omitted from a Git stat.

## Remaining technical debt and recommendation

- Historical iteration documents and large ZIPs still clutter disk. Removing untracked/modified research work requires owner approval or a separately verified archival plan; this cleanup deliberately stops short of that deletion.
- No independent external research backup is verified. The new VLM ZIP is same-disk preservation only.
- No separate original Phase 1 experiment evidence was identified; its report is architecture documentation.
- Dependency versions other than Transformers use broad ranges; the recorded environment is not a full platform lockfile.
- A historical box ACCEPT contains `YOUR_NAME`; it is not confirmed named-human approval. No SAM mask is genuinely accepted; five requests remain PENDING and bicycle has NEEDS_REVIEW preparation triage.
- Hashes detect changes relative to recorded evidence, not semantic correctness, reviewer authenticity or signed approval. Cultural correctness and pixel quality still require independent inspection.
- `inpainting.py` remains a docstring placeholder. No diffusion/inpainting or automatic planner-to-grounding/SAM integration was added.

**Recommendation:** mentor may review the consolidated project and regression evidence now. Obtain actual mask-quality review and decide on historical artifact archival before any Phase 6 work. Cleanup does not resolve segmentation failures or authorize editing.

## Final measured content footprint

Same-scope file count: **781 before → 774 after**. Ignored bytecode removed: **190,263 bytes**. The compact reports and VLM preservation copy replace some of that saving; exact net content bytes are in the included size summary. Audit records and the review ZIP increase the total on-disk workspace size. This is a navigation and preservation cleanup, not a large storage reclamation.

Final repository link check: **418 local links, zero broken targets** across the README, root reports and results indexes. Remote URLs/heading anchors were not checked.
