# Culture-Aware Image Transcreation

A research project exploring how to suggest culturally appropriate image adaptations while preserving the original activity, people and relationships.

Implemented stages describe an image, propose a conditional cultural plan, localize an object and produce segmentation masks. **The full transcreation pipeline does not yet edit images.** Diffusion inpainting (Phase 6) has not started.

## Architecture and status

```text
image -> SmolVLM caption -> Qwen cultural draft -> deterministic validation
                                                  |
                         independent research stages (no automatic handoff)
                         Grounding DINO box -> explicit selection -> SAM masks
                                                               -> mask review
```

- Captioning: SmolVLM-500M; caption claims remain unverified.
- Planning: Qwen2.5-3B through local Ollama, structured JSON and raw/final audit records.
- Validation: PROPOSE is conditional; REVIEW quarantines candidates; ABSTAIN leaves the image unchanged. None authorizes editing.
- Localization: Grounding DINO Tiny, original-pixel boxes, multiple detections and explicit box review.
- Segmentation: SAM ViT-Base with boxes and optional positive/negative points; all candidate masks retained at original resolution.
- Mask review: hash-bound explicit selection, reviewer identity and inspection declarations. Current prepared masks remain PENDING; bicycle quality needs review.

Python 3.11, PyTorch, Transformers 4.57.6, Pillow and PyYAML. The planner uses Python's standard HTTP library. Recorded GPU: RTX 3050 Laptop GPU, 4 GB. Run model stages sequentially.

## Repository

```text
configs/              models.yaml, planner.yaml, grounding.yaml, sam.yaml
src/transcreation/    CLI, configuration, typed contracts and implemented stages
scripts/              evaluation, SAM and human-review commands
tests/                offline regression tests and planner fixtures
data/                 source images/datasets (mostly local, Git-ignored)
outputs/              new generated runs (Git-ignored)
results/              phase evidence indexes and preserved VLM raw evidence
reports/              five canonical phase reports and cleanup review
.local_archive/       historical local research; original paths retained
```

Historical iteration evidence remains at its recorded paths under reports/ to preserve hashes and reproducibility. Results indexes identify the essential artifacts. The unused inpainting module is a historical docstring placeholder, not an implementation.

## Installation

From the project root, with Python 3.11:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e .
$env:PYTHONPATH = (Resolve-Path .\src).Path
```

Install a CUDA-compatible PyTorch build for your machine when using the GPU. First model use downloads pinned Hugging Face weights if uncached. Planning requires Ollama running with `qwen2.5:3b` installed. Source datasets are not all committed: consult the evidence indexes for provenance and saved source copies.

## Run the implemented stages

Use fresh output paths. Commands below are separate operations; planning input is not the full caption audit JSON.

```powershell
# Caption
.\.venv\Scripts\python.exe -B -m transcreation.cli caption --image data/sample_images/durga.jpg --out outputs/caption_new.json
# Plan using the provided typed fixture
.\.venv\Scripts\python.exe -B -m transcreation.cli plan --input tests/fixtures/planning/01_japanese_food.json --out outputs/plan_new.json
# Independent localization research
.\.venv\Scripts\python.exe -B -m transcreation.cli ground --image data/vlm_collection/scene_06.jpg --phrase bicycle --out outputs/bicycle_new
# SAM research with an explicitly selected saved box
.\.venv\Scripts\python.exe -B -m scripts.segment_sam --image data/vlm_collection/scene_06.jpg --detection reports/phase4_iteration2_assets/runs/R01_bicycle_replay/detection.json --prediction-index 0 --research-only --note "Explicit bicycle box for segmentation research" --out outputs/sam_bicycle_new
```

SAM optionally accepts `--points` with a source-bound point JSON. Settings remain in `configs/sam.yaml`; it was not renamed to match a diagram. Editable installation also provides `transcreate caption|plan|ground`. The module commands avoid dependence on a stale installed launcher.

Prepare review evidence without inference:

```powershell
.\.venv\Scripts\python.exe -B -m scripts.review_grounding prepare --image data/vlm_collection/scene_06.jpg --detection reports/phase4_iteration2_assets/runs/R01_bicycle_replay/detection.json --out outputs/box_review_new
.\.venv\Scripts\python.exe -B -m scripts.review_mask prepare --segmentation reports/phase5_iteration2_assets/B_oil_lamp/segmentation.json --candidates 0 1 --target "Visible clay bowl only; exclude flame and unrelated objects" --experiment "Bowl-only segmentation test; no editing" --out outputs/mask_review_new
```

Inspect originals, masks and overlays before submitting a real review. See `python -m scripts.review_mask decide --help` for identity, decision, index and inspection flags. Preparation creates PENDING requests; it does not fabricate acceptance. A historical box record with placeholder identity is not confirmed human approval. Mask acceptance is only for a named segmentation experiment.

## Tests

```powershell
$env:PYTHONPATH = (Resolve-Path .\src).Path
$env:HF_HUB_OFFLINE = "1"
.\.venv\Scripts\python.exe -B -m unittest discover -s tests -v
```

Tests use mocks and synthetic fixtures without model-weight downloads. The latest cleanup records actual before/after counts in its report. They do not establish runtime equivalence for untested hardware or cultural correctness.

## Research reports and results

| Phase | Report | Evidence |
| --- | --- | --- |
| 1 | [Research and architecture](reports/phase1_research.md) | Architecture; original Phase 1 experimental notes unavailable |
| 2 | [VLM selection](reports/phase2_vlm.md) | [Captions, timings and failure evidence](results/phase2_vlm/README.md) |
| 3 | [Cultural planning](reports/phase3_llm.md) | [Raw/final plans and validation](results/phase3_llm/README.md) |
| 4 | [Localization](reports/phase4_grounding.md) | [Boxes, negative control and review](results/phase4_grounding/README.md) |
| 5 | [Segmentation](reports/phase5_segmentation.md) | [Masks, points and pending review](results/phase5_segmentation/README.md) |

[Cleanup verification](reports/repository_cleanup_review.md) records preservation, remaining deletion candidates and compatibility checks.

## Known limitations and next step

Captions can hallucinate or truncate; text validation cannot prove cultural appropriateness. Grounding produced a bicycle labeled airplane in a negative control. SAM misses thin bicycle structures and leaks background. No independently labeled detection/mask ground truth supports accuracy claims. Lamp candidates await actual human review; no mask is genuinely approved.

Do not redistribute source imagery without checking attribution and licenses. Local archives and ignored outputs need an independent backup; a same-disk copy is insufficient. Generated review ZIPs are excluded from new Git additions, while source evidence remains intact. Broad package ranges beyond the Transformers pin are a reproducibility limitation.

The next planned stage is diffusion inpainting, **after mentor evaluation and appropriate authorization gates**. No Phase 6 code is implemented.
