# Grounding evidence

[Consolidated phase report](../../reports/phase4_grounding.md).

Original artifact paths are retained because later segmentation inputs and reviews bind to their bytes and provenance.

- [Baseline predictions, original copies and annotations](../../reports/phase4_grounding_assets/)
- [Exact eight-condition protocol](../../reports/phase4_iteration2_assets/runs/experiment_plan.json)
- [All conditions, negative control and bicycle replay](../../reports/phase4_iteration2_assets/runs/)
- [Reproducibility comparison](../../reports/phase4_iteration2_assets/baseline_reproducibility.json)
- [Box-review examples and original evidence](../../reports/phase4_iteration3_assets/examples/)
- [Default model settings](../../configs/grounding.yaml)

Detection JSON contains original-pixel coordinates, model revision, exact settings, confidence, labels, timing and allocated CUDA memory. Negative results and false detections are not suppressed. The airplane negative control incorrectly found the bicycle; a score does not verify semantics.

The historical bicycle `accepted.json` uses placeholder reviewer identity `YOUR_NAME`. It is not confirmed named-human acceptance and is rejected as such by the segmentation input gate. Other prepared cases remain pending; no review record was rewritten during cleanup.

Bicycle source: [Basile Morin / Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Parked_bicycle_with_graffitied_building_facade_and_doors_in_Amsterdam.jpg), CC BY-SA 4.0. Lamp source: [Benoy / Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Diwali_Oil_lamps_Darjeeling.jpg), CC BY-SA 3.0. Durga source was user-supplied; license unspecified. Annotated copies retain source attribution obligations.
