# VLM evidence

[Consolidated phase report](../../reports/phase2_vlm.md).

[Historical raw evidence ZIP](historical_raw_evidence.zip) preserves selected raw JSON/Markdown results: initial BLIP/Florence/SmolVLM captions, paired 11-image comparison, token-ceiling and concise-prompt experiments, crop/grid/dense diagnostics, and the original archive manifest. Archive entry names retain original project-relative paths. Some provenance manifests reference other archive files; this ZIP is not the entire original archive or all input images.

[Copy manifest and SHA-256 checks](../../reports/repository_cleanup_20261110/vlm_preservation_copy.json) identifies every included source file. This is a nonignored preservation copy on the same disk, not an independently verified external backup. Originals remain unchanged in `.local_archive/`.

[Historical selection findings](../../reports/VLM_Selection_Experimental_Findings_Refined.md) explain the convenience sample and qualitative failures. Raw captions and cultural names are model claims, not verified labels. Source-image redistribution rights must be checked separately.
