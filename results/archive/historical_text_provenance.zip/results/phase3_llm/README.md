# Planner evidence

[Consolidated phase report](../../reports/phase3_llm.md).

The files below remain at their existing paths so saved audit references and historical commands stay valid. This index does not duplicate predictions.

- [Fixture inputs and provenance](../../tests/fixtures/planning/)
- [Initial six-scenario integration](../../reports/ollama_planner_phase3_20261108/)
- [Prompt revision 2](../../reports/ollama_planner_phase3_20261108_prompt_v2/)
- [Prompt revision 3, including rejected output](../../reports/ollama_planner_phase3_20261108_prompt_v3/)
- [Three CLI experiments](../../reports/phase3_step2_three_examples_20261108/)
- [Failed consistency revision](../../reports/planner_quality_review_20261108/)
- [Final consistency revision](../../reports/planner_quality_review_20261108_final/)
- [First decision-policy experiment](../../reports/planner_decision_policy_20261108/)
- [Final decision-policy experiment](../../reports/planner_decision_policy_20261108_final/)
- [Raw/final decision and runtime comparison](../../reports/planner_decision_policy_20261108_final/comparison.json)
- [Root-cause analysis](../../reports/planner_decision_policy_20261108_final/root_cause_analysis.json)

Per-case audit JSON retains requests/prompts, responses, parsed drafts, validated plans, issue codes, rejected candidates and runtime/token metadata. Final food and Durga outcomes are REVIEW with no actionable edits; bicycle is ABSTAIN. These are policy outcomes, not verified cultural correctness. Failed trials are retained deliberately.
