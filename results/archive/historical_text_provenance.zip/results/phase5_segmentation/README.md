# Segmentation evidence

[Consolidated phase report](../../reports/phase5_segmentation.md).

All masks and hash-bound records remain unchanged at their original paths:

- [Bicycle box-only candidates](../../reports/phase5_iteration1_assets/A_bicycle/)
- [Lamp box-only candidates](../../reports/phase5_iteration1_assets/B_oil_lamp/)
- [Fixed point protocol](../../reports/phase5_iteration2_assets/experiment_plan.json)
- [Bicycle point-guided candidates and point preview](../../reports/phase5_iteration2_assets/A_bicycle/)
- [Lamp point-guided candidates and point preview](../../reports/phase5_iteration2_assets/B_oil_lamp/)
- [All candidate overlap/count diagnostics](../../reports/phase5_iteration2_assets/mask_statistics.json)
- [Lamp candidates 0 and 1: PENDING human review](../../reports/phase5_iteration3_assets/case_A_oil_lamp/)
- [Bicycle candidates 0, 1 and 2: NEEDS_REVIEW triage, PENDING human decisions](../../reports/phase5_iteration3_assets/case_B_bicycle/)
- [Mask-review regression evidence](../../reports/phase5_iteration3_assets/test_summary.json)
- [SAM settings](../../configs/sam.yaml)

Each run contains source copies, selected detection JSON, exact point provenance where applicable, three binary masks, overlays and full segmentation metadata. Every model run is RESEARCH_ONLY. No mask is genuinely human-approved. Lamp target is clay bowl/body only, not complete replacement; bicycle masks have unresolved thin-structure/background failures.

Predicted SAM scores and overlap with other predicted masks are diagnostics, not ground-truth accuracy. Review decisions authorize only a specific segmentation test and never image editing or cultural transformation.
