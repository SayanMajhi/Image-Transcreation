# Phase 7 Iteration 8 uncertainty triage

Start with [the same working report](results/phase7_integration/phase7_working_report.md), Iteration 8.
Open [the real PENDING review request](results/phase7_integration/iteration8/ramen_uncertainty_review/review_request.md).
The original planner result is still REVIEW with zero released candidates.
No real classification or reviewer name was fabricated. Routine classification does not release candidates or grant any model permission.

With existing Python 3.11 dependencies, from this extracted package root:

```powershell
$env:PYTHONPATH = (Resolve-Path src).Path
$env:HF_HUB_OFFLINE = "1"
python -B -m scripts.review_uncertainty verify --review results/phase7_integration/iteration8/ramen_uncertainty_review/pending.json
python -B -m unittest discover -s tests -p test_uncertainty_review.py -v
python -B -m unittest discover -s tests -v
```

Choose ROUTINE_VERIFICATION_REQUIRED, MATERIAL_UNRESOLVED, REJECT or NEEDS_REVIEW only after actual inspection,
with a genuine reviewer name, explanation and five declarations. Exact commands are in the working report.
The synthetic_examples folder contains only clearly marked generic fixtures and synthetic judgments, never real ramen classifications.
Do not execute any old controlled_call_driver.py; prior files are retained only as historical experimental evidence.
No new model, prompt change, policy change, automatic semantic classifier or downstream handoff was implemented.
The source photo's public creator/license is unknown; included for the user-requested mentor review, not claimed open-licensed.
