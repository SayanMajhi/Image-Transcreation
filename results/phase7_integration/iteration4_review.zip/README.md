# Phase 7 Iteration 4 review

Start with [the same working report](results/phase7_integration/phase7_working_report.md), Iteration 4.
This is an offline policy correction. No new real model run or genuine human approval exists.
Earlier sections/artifacts are preserved as history; current code deliberately changes the instruction gate.

Use the existing Python 3.11 environment; no downloads needed for offline checks:

```powershell
$env:PYTHONPATH = (Resolve-Path src).Path
$env:HF_HUB_OFFLINE = "1"
python -B -m unittest discover -s tests -v
python -B results/phase7_integration/iteration4/replay_policy.py --out replay_reproduced
python -m scripts.review_edit_intent verify --review results/phase7_integration/iteration4/review_flow/accepted_grounding_only/intent/decision.json
```

All accepted demonstration records are SYNTHETIC_TEST_ONLY. Verification never approves a real edit.
The ordinary CLI cannot dispatch live models from synthetic records. Grounding-only dispatch was mocked.
Original instructions remain bound to hashes, and checked_user_instructions is mandatory for accepting instruction-bearing drafts.
All SAM, diffusion and cultural-editing permissions remain false.
The seven original historical audits are included byte-for-byte beside new replay files.
Earlier bicycle source attribution: Basile Morin / CC BY-SA 4.0, with source metadata retained.
