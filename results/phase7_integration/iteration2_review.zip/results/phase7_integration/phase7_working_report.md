# Phase 7 working report

Working integration evidence; **not a polished final Phase 7 report or mentor approval**. Future targeted corrections should append another labeled iteration and preserve these outcomes.

## Iteration 1 — Pipeline Orchestration and Safety

### Objective and scope

Connect existing data contracts and enforce explicit stopping. Implemented here: **live image → caption → validated plan**, and **read-only replay of independently generated localization/segmentation/inpainting artifacts**. No new diffusion was permitted or performed.

**Recommendation: NEEDS FIXES before full approved live-stage orchestration.** The implemented planning/replay paths and their safety tests pass. However, no edit-intent approval/resume contract exists; box and mask acceptances authorize segmentation testing only; diffusion input is explicitly RESEARCH_ONLY. Those contracts were not weakened. Live grounding/SAM/generation dispatch after approval is not implemented by this coordinator and must not be claimed as completed end-to-end integration.

### Existing interfaces inspected

| Component | Existing interface / output | Boundary |
| --- | --- | --- |
| SmolVLM | `create_captioner(config).caption(PIL_RGB)` → typed caption with completion flags/settings | Caption claims are unverified; no culture or object verification is inferred. |
| Planning input | `PlanningInput.from_caption(...)` | Completion flags, target and optional user context transfer without fabricating verified objects. |
| Ollama | `record_plan(PlanningInput)` → request/raw/final audit, errors and unload status | Exact system/user prompts, model digest and transport outcomes remain archived. |
| Deterministic policy | `parse_model_draft` + `validate_planning_result` | REVIEW quarantines candidates; ABSTAIN releases no edits; PROPOSE is conditional. |
| Grounding | `GroundingDetector.detect(image_path, phrase)` → boxes/scores; standalone saver | Existing detector unchanged. Replay uses `_evidence` to validate saved source hash, dimensions and box contracts, never detector inference. |
| Box review | Existing bound ACCEPT / REJECT / NEEDS_REVIEW records | Accepted record is a segmentation-test candidate. Existing SAM input loader also rejects placeholder identity. |
| SAM | `load_segmentation_input(...)`, `SamSegmenter.segment(...)` → mask bundle | Replay uses existing `_bundle` integrity checks; selected index/hash and detection provenance must agree. No SAM inference. |
| Mask review | `_check`, `read_candidate` | Accepted mask is for a named controlled segmentation experiment; it does not authorize cultural editing. |
| Inpainting | `InpaintingInput` / `run_inpainting(...)` | Current entry is isolated research generation. Coordinator only checks an existing result and exact final locality; never calls it. |

The independent implemented model stages remain functional and unchanged. Their existence is distinct from having an approved live dispatch path through this coordinator.

### New implementation and contract

Three files added: `src/transcreation/orchestration.py`, `scripts/run_pipeline.py`, `tests/test_orchestration.py`. No dependencies, existing stage code, prompts, policies, checkpoints, thresholds or generation settings changed.

`PipelineInput` requires source image path/SHA-256, target culture, a new output directory and explicit execution mode. Optional user fields are source culture, instructions and existing typed `VerifiedObject` records. Research mode additionally requires a `ReplayChain`: explicit source phrase, pinned detection reference, explicit selection indices, bound SAM/mask references and fixed independent generation prompt. Missing selections return review states; malformed contracts are rejected. No request field can enable generation permission.

`PipelineResult` records mode, final state, completed stages, stopped stage/reason, content-hash artifact IDs, transitions, outstanding reviews, errors and whether replay integrity was validated. `image_generation_permitted` is **false in both modes throughout this milestone**. `CAPTION_COMPLETED` is logged as a transition; final states include PLAN_REQUIRES_REVIEW, NO_EDIT_JUSTIFIED, EDIT_PROPOSAL_READY, SOURCE_OBJECT_REQUIRES_REVIEW, MASK_REQUIRES_REVIEW, RESEARCH_REPLAY_VALIDATED and FAILED.

Every run creates a new directory with source copy, input JSON, produced/checked artifacts and `pipeline_result.json`. Existing directories are never overwritten. Validating an old image is labeled `EXISTING_OUTPUT_VERIFIED_NOT_GENERATED`, not generation completed.

### Data flow

```mermaid
flowchart TD
    A[Original image + pinned hash] --> M{Explicit mode}
    M -->|AUTOMATED_PLANNING| C[SmolVLM caption]
    C --> R[Release caption weights]
    R --> Q[Qwen audit + existing deterministic validation]
    Q -->|REVIEW| S[Stop: planning review]
    Q -->|ABSTAIN| N[Stop: no edit]
    Q -->|PROPOSE| I[Stop: edit-intent approval required]
    M -->|RESEARCH_REPLAY| D[Verify saved detection and explicit source selection]
    D --> K[Verify saved SAM bundle and selected mask]
    K --> G[Verify existing research output and outside-mask pixels]
    G --> V[Return review-required or replay-validated state]
    V --> X[No new generation / no approval promotion]
```

Intended future live continuation remains edit-intent review → detection → box review → SAM → mask/edit authorization → generation. The coordinator does **not** currently implement that approved continuation/resume path. No permissive boolean or invented review record was introduced to simulate it.

### Modes and review boundaries

**AUTOMATED_PLANNING:** verify and decode exact image bytes; confirm Qwen is not resident; load unchanged SmolVLM configuration; caption; release model/processor references and CUDA cache; map the actual typed caption into PlanningInput; call the unchanged planner; preserve its audit; revalidate the untouched raw response through existing policy and compare to the saved final. This extra check does not query Qwen again or change its policy.

Final REVIEW stops before localization and exposes no executable candidates. ABSTAIN terminates without editing. PROPOSE stops at edit-intent review. Source-image changes during captioning/planning fail the run. Planning errors remain errors rather than becoming a fabricated successful draft.

**RESEARCH_REPLAY:** no captioner, Ollama, detector, SAM or diffusion model is instantiated. It reads the specified independent chain; compares source/query/index/detection hashes; validates masks and optional reviews using existing helpers; checks saved generation request/prompt/SAM bindings, every recorded output hash and final outside-mask equality. Exact source-query matching prevents silently substituting a future replacement phrase. It cannot prove semantic object identity.

Missing review may coexist with read-only validation of later *existing files*: this is inspection, not downstream model execution. Missing explicit selection, wrong phrases, invalid review bindings or failed integrity checks stop before later evidence inspection as shown in guard evaluations. No stop result triggers further execution.

Research replay is never labeled an LLM-planned cultural transformation. Even synthetic test fixtures with accepted box/mask records still cannot permit generation: segmentation-test acceptance is not cultural-edit authorization. No real acceptance was fabricated.

### Offline evaluation

Archived raw/final planner cases were checked without model inference. Exact original audit bytes are retained in the package; saved decisions were not rewritten:

| Archived case | Raw → validated | Candidate release |
| --- | --- | --- |
| Japanese food → India | PROPOSE → REVIEW | None |
| Durga Puja → Japan | REVIEW → REVIEW | None |
| Bicycle → India | PROPOSE → ABSTAIN | None |

These are planning-fixture regressions, not new image runs. The meal's user-verified ramen is a hypothetical fixture assertion, not new photographic verification. [Planner regression details](iteration1/offline/planner_regressions.json).

The real saved oil-lamp chain was traced from original source hash through detection index **2**, SAM point-guided mask **0**, and Phase 6 Iteration 2's existing research output. All artifact checks passed. Final replay state: **SOURCE_OBJECT_REQUIRES_REVIEW**; outstanding gates: **BOX_REVIEW_MISSING** and **MASK_REVIEW_PENDING**; `replay_validated=true`, `image_generation_permitted=false`. Target culture is a declared common input field only; this replay does not apply it to the old material prompt or claim cultural adaptation.

[Replay input](iteration1/offline/replay_input.json) · [Replay transitions/artifacts](iteration1/offline/oil_lamp_replay/pipeline_result.json) · [Combined offline summary](iteration1/offline/summary.json).

Three additional saved-evidence guards produced the expected stops: replacement query → SOURCE_OBJECT_REQUIRES_REVIEW at grounding evidence; missing instance → SOURCE_OBJECT_REQUIRES_REVIEW at box selection; wrong mask hash → FAILED at segmentation evidence. None read/released an inpainting artifact or invoked a model. [Guard results](iteration1/offline/guard_evaluations.json).

### One actual image-to-caption-to-plan run

Predeclared existing parked-bicycle photograph, target **India**, source culture null, no user instructions and no verified-object assertions. Configuration and input hashes were frozen before execution. One run was performed; no retry, alternative image, planner override or second scenario.

[Predeclaration](iteration1/real_preregistration.json) · [Actual input](iteration1/real_input.json) · [Original image copy](iteration1/real_run/evidence/source/scene_06.jpg).

| Observation | Actual result |
| --- | --- |
| Source SHA-256 | `e0fa05019d587cc62b1d4d5a82d7440216b5d88ef0f2149a69f2eb2ee640fca0` |
| SmolVLM revision | `a7da5b986cb59b408707209984f360a5f4ad7e47` |
| Caption status | EOS reached; **112 generated tokens**, not truncated |
| Caption model load / inference | 2.141017 s / 6.152280 s |
| Caption peak allocated CUDA | 1,178,738,688 bytes |
| Caption handoff | Exact text and COMPLETE status, target India, no invented verified objects |
| Qwen | qwen2.5:3b, 3.1B Q4_K_M |
| Resolved model digest | `357c53fb659c5076de1d65ccb0b397446227b71a42be9d1603d46168015c9e4b` |
| Qwen prompt/output tokens | **768 / 184** |
| Qwen reported generation time | **2.784218 s**; load 6.664519 s; server total 9.899929 s |
| Raw planner decision | **REVIEW**, empty candidate list |
| Final deterministic decision | **REVIEW**, empty candidate list |
| Validation issue | MODEL_REVIEW_REQUESTED |
| Pipeline state / stopped stage | **PLAN_REQUIRES_REVIEW / planning_review** |
| Generation permitted | **false** |
| New grounding / SAM / diffusion calls | **0 / 0 / 0** |
| Process wall time | 28.605055 s |

These are execution observations for integration, not new model benchmarking. Caption claims about graffiti words/colors are unverified. Qwen's raw reason suggested graffiti and a bicycle might be inappropriate for India. This is an **unsupported cultural assumption**, not a research finding about India. Safe stopping worked, but valid JSON and a REVIEW label do not make that reasoning good. No policy/prompt change or forced ABSTAIN was made to improve this result.

[Actual caption with exact prompt/settings](iteration1/real_run/caption.json) · [Derived planning input](iteration1/real_run/planning_input.json) · [Full raw/final Qwen audit](iteration1/real_run/planner_audit.json) · [Revalidated final plan](iteration1/real_run/validated_plan.json) · [Stage transitions and artifact IDs](iteration1/real_run/pipeline_result.json) · [Invocation](iteration1/real_invocation.json).

### Resource management and failures

The coordinator is single-process and sequential. It checks Ollama residency before captioning; it may unload the configured Qwen but fails rather than silently evicting unrelated models. Caption weight/processor references are explicitly released in `finally`; existing SmolVLM has no close method, so the coordinator owns this cleanup without modifying the adapter.

In the real run, Torch allocated CUDA memory was **0 bytes after caption release and before Qwen**. The planner's existing keep_alive=0/unload behavior was retained, and `/api/ps` confirmed Qwen absent afterward. This proves the measured cleanup for this path, not whole-board memory freedom. Qwen peak memory was not measured. Grounding/SAM/diffusion had no live instances to close in this iteration; their future live lifecycle remains outside the implemented continuation path.

Unexpected caption/planner errors release owned references and attempt Qwen cleanup. Cleanup failures are recorded and fail closed; primary stage errors remain in the error list. Runtime failures persist a FAILED result with stage/type/code/message. Malformed requests and existing output paths are rejected before a run can overwrite user work.

### Regression tests

Baseline: **232 passed**, zero failures/errors, in 16.084 s. After: **260 passed**, zero failures/errors, in 19.402 s. The 28 new mocked integration tests passed independently as well. No model weights were downloaded/loaded by offline tests.

Coverage includes successful caption/planning and saved-chain handoffs; truncation; Qwen REVIEW/ABSTAIN; invalid/quarantined candidates; source/replacement phrase confusion; no detections; multiple boxes without selection; wrong/missing box review; invalid/unreviewed mask; source/detection/mask/output hash mismatches; **saved** inpainting failure; error propagation; stage order; blocked-state behavior; no research-to-approved promotion; cleanup and no-overwrite.

Important test limit: inpainting failure tests validate a **historical failed result**, not a live inpainting dispatch from this coordinator. Existing inpainting unit tests still cover its own mocked runtime failures. No claim is made that an approved live downstream chain was exercised.

[Before tests](iteration1/tests_before.json) · [After full suite](iteration1/tests_after.json) · [Environment/dependency check](iteration1/environment.json) · [Preserved old files](iteration1/preservation_after.json).

### Git summary and reproducibility

Only three implementation/test files were added, plus Phase 7 evidence and this working report. All **47 inventoried existing source/script/test/config/report files** remain byte-identical. Pre-existing uncommitted Phase 6 changes are preserved and are not attributed to this iteration. No dependency, model/prompt/config, review policy, old report or saved decision changed. No automatic staging, commit or push.

[Git before](iteration1/git_before.json) · [Git after](iteration1/git_after.json). Current relevant code/config snapshots and a content manifest are in the review ZIP. It excludes weights, caches, environments and unrelated datasets. Bicycle attribution: Basile Morin / CC BY-SA 4.0; lamp: Benoy / CC BY-SA 3.0. Their original Commons references and modification details are retained in the package attribution record.

Run from the repository root:

```powershell
$env:PYTHONPATH = (Resolve-Path .\src).Path
python -B -m scripts.run_pipeline --input results/phase7_integration/iteration1/real_input.json
```

The exact saved input points to an already-existing output directory and deliberately cannot be rerun in place. To intentionally reproduce later, use a new output directory. Review does not require another model call. The portable package instead provides a path-remapped **read-only replay** input and checker; original audits retain their original bytes/paths as historical provenance.

### Remaining limits and recommendation

**NEEDS FIXES for the full approved live orchestration milestone.** Current safety/data-flow behavior passes its tests and real early-stop evaluation, but the following are explicit blocked integration points:

- No bound edit-intent approval schema or review/resume mechanism exists. Automated PROPOSE always stops before localization.
- Existing box/mask acceptance scopes cannot authorize cultural editing; the independent inpainting interface remains research-only.
- Live detector/SAM/inpainting dispatch after approval is intentionally absent, not hidden behind a successful test label.
- Semantic identity, mask adequacy, physical continuity and cultural appropriateness are not proved by hashes or types. The ordinary bicycle's unsupported cultural REVIEW remains a model-quality limitation.
- Review identities/inspection declarations are not authenticated signatures. Existing reviewed test fixtures are synthetic and do not fabricate real approvals.
- Reused review helpers live under scripts and assume repository-root execution; wheel-only packaging is not addressed.

This is safe planning plus artifact-chain validation, **not successful culturally verified end-to-end image generation**. No new image was generated. Mentor evaluation should decide the next narrow authorization/resumption correction. No Phase 8 or polished final Phase 7 report was created. **STOP.**


## Iteration 2 — Edit-Intent Review and Grounding Handoff

### Objective and recommendation

Add a review gate between a final validated PROPOSE and a controlled localization test. This iteration implements the gate and grounding-only continuation, without changing any model stage or planning policy.

**Recommendation: NEEDS FIXES before live handoff sign-off.** The requested offline contract and safety checks pass. A genuine eligible image-bound PROPOSE and an actual reviewer acceptance are still absent, so a live accepted-plan handoff has not been established. This is an evidence limitation, not a reason to override REVIEW or manufacture an approval. Stop here for mentor evaluation. No polished final Phase 7 report is created.

### Implementation changes

- `scripts/review_edit_intent.py`: prepare a PENDING request, display the original and proposed objects, record one explicit human decision in a new file, and reverify the saved evidence. It follows the existing immutable-file review conventions.
- `src/transcreation/orchestration.py`: additive `GROUNDING_TEST` mode and `IntentReference(review_file, review_sha256)`. The existing automated-planning and read-only replay modes remain available. A continuation consumes the saved plan rather than rerunning captioning or Qwen.
- `scripts/run_pipeline.py`: parse the optional typed intent reference through the existing JSON-input CLI.
- `tests/test_edit_intent.py`: 39 offline tests using synthetic reviewer declarations and mocked models. These declarations are test data, not real approvals.

No checkpoint, prompt, threshold, seed, precision, preprocessing, planner decision rule, existing box/mask contract or dependency changed. SAM and diffusion are never dispatched in this continuation. See [exact source changes](iteration2/iteration2_changes.patch) and [change summary](iteration2/change_summary.json).

### Review contract and evidence checks

The record supports PENDING preparation and decisions `ACCEPT_FOR_GROUNDING_TEST`, `REJECT`, `NEEDS_REVIEW`. A specific candidate index is always supplied, even when only one candidate exists. There is no highest-ranked or highest-score selection.

Each request stores the source image SHA-256; source/target cultures; user instructions and supplied verified objects; exact `validated_plan.json` file SHA-256; canonical planning-result SHA-256; original planner-audit and pipeline-result SHA-256; selected candidate index and all its original fields; preservation constraints; verification requirements; reviewer identity, reason, time and explicit original-image/edit-proposal inspection flags. The audit SHA-256 is its content identity, binding the untouched raw response and original model metadata.

The preparer copies exact evidence bytes and rechecks caption-to-planning context, artifact hashes, raw/final agreement and the existing deterministic validator. Only an original automated run in EDIT_PROPOSAL_READY with a final PROPOSE and actionable candidates is eligible. REVIEW, ABSTAIN, parse failures, quarantined/rejected entries and mismatched input are refused. A later review cannot change the candidate, cultures, constraints, evidence scope or original pending request. Placeholders such as YOUR_NAME and an identity without both inspection declarations are rejected.

Acceptance means **grounding test only**. `sam_authorized`, `image_edit_authorized`, `diffusion_authorized` and `cultural_transformation_authorized` remain false for every decision. A hash detects changed bytes relative to the recorded evidence; it is not a digital signature or independent proof that a person inspected the image.

### Original versus replacement

`object_description` and `localization_phrase` identify the original source object. `proposed_change` describes the intended future replacement/modification. `cultural_reason` is the proposal's rationale, not a verified cultural fact. All are bound exactly; review never rewrites Qwen's output.

The synthetic demonstration uses original phrase **synthetic object**, replacement **a different surface material**. The mock detector receives only `synthetic object`. Its two boxes remain separate; neither is selected for SAM. This checks data flow, not cultural suitability or detection quality.

### Commands and continuation input

Run from the repository root with the existing Python 3.11 environment and `src` on PYTHONPATH. These first commands are instructions for a **future eligible real run**; they were not used to invent a real positive record:

```powershell
$env:PYTHONPATH = (Resolve-Path src).Path
python -m scripts.review_edit_intent prepare --run <eligible-run>/pipeline_result.json --image <original-image> --index <explicit-index> --out <new-review-folder>
python -m scripts.review_edit_intent verify --review <new-review-folder>/pending.json
# After actual inspection, supply the real person's name and explanation:
python -m scripts.review_edit_intent decide --pending <new-review-folder>/pending.json --out <new-review-folder>/decision.json --decision ACCEPT_FOR_GROUNDING_TEST --reviewer "<actual reviewer>" --reason "<actual assessment>" --inspected-original --inspected-edit
python -m scripts.review_edit_intent verify --review <new-review-folder>/decision.json
python -m scripts.run_pipeline --input <grounding-continuation-input.json>
```

Replace angle-bracket examples; placeholder reviewer names are refused. Use `REJECT` or `NEEDS_REVIEW` when appropriate. Each decision is a new file beside its bound pending evidence. Nothing modifies the original audit.

Continuation JSON uses existing image/context fields with `execution_mode: "GROUNDING_TEST"` and `edit_intent: {"review_file": ".../decision.json", "review_sha256": "<exact-file-hash>"}`. Copy cultures, instructions and verified objects exactly from the original planning input; do not add a replay chain. The selected candidate is already pinned by the review; the continuation cannot substitute another index or phrase.

A safe, saved synthetic input is [synthetic_block_input.json](iteration2/synthetic_block_input.json). Running it through the ordinary CLI must stop with EDIT_INTENT_REQUIRES_REVIEW: synthetic approvals cannot dispatch a live detector. The Python test-only `grounding_factory` seam permits a mock solely for evidence marked SYNTHETIC_TEST_ONLY; no CLI switch exposes that seam. This is a developer test mechanism, not a security boundary against a caller who can alter application code.

### Stage transitions and resource boundary

```text
Original automated run -> final PROPOSE -> PENDING edit-intent request
  PENDING / NEEDS_REVIEW -> EDIT_INTENT_REQUIRES_REVIEW; stop
  REJECT                -> EDIT_INTENT_REJECTED; stop
  changed evidence      -> FAILED; stop
  explicit accepted intent + exact revalidated evidence
    -> confirm Qwen not resident (live route only)
    -> Grounding DINO(original localization phrase)
    -> release detector in finally
    -> retain every box / record no detections
    -> PENDING box review; SOURCE_OBJECT_REQUIRES_REVIEW; stop
```

SmolVLM and Qwen are not rerun or loaded by this continuation. The live route reuses the existing Ollama residency check and fails if an unrelated resident model prevents safe sequential use. The detector uses unchanged grounding configuration and closes after success or failure. No SAM or diffusion branch exists here. Production-route ordering was exercised with all verification/service/model boundaries mocked; actual GPU residency, latency and memory were **not** measured in this iteration.

### Offline evaluation: actual saved demonstrations

| Synthetic case | Outcome | Mock detect / close calls | Live calls |
| --- | --- | --- | --- |
| Accepted, two boxes | SOURCE_OBJECT_REQUIRES_REVIEW; both boxes retained, no selection | 1 / 1 | 0 |
| Accepted, no detections | SOURCE_OBJECT_REQUIRES_REVIEW; no box can be accepted | 1 / 1 | 0 |
| PENDING | EDIT_INTENT_REQUIRES_REVIEW | 0 / 0 | 0 |
| REJECT | EDIT_INTENT_REJECTED | 0 / 0 | 0 |
| NEEDS_REVIEW | EDIT_INTENT_REQUIRES_REVIEW | 0 / 0 | 0 |
| Plan bytes changed after review | FAILED at edit-intent validation | 0 / 0 | 0 |
| Synthetic acceptance through normal live CLI route | EDIT_INTENT_REQUIRES_REVIEW | 0 / 0 | 0 |

[Evaluation summary](iteration2/synthetic_evaluation.json). Representative [PENDING record](iteration2/synthetic/accepted_multiple/intent/pending.json), [synthetic acceptance](iteration2/synthetic/accepted_multiple/intent/decision.json), [original validated plan](iteration2/synthetic/accepted_multiple/run/validated_plan.json), [raw/final audit](iteration2/synthetic/accepted_multiple/run/planner_audit.json), [continuation transitions](iteration2/synthetic/accepted_multiple/continuation/pipeline_result.json), [two mock boxes](iteration2/synthetic/accepted_multiple/continuation/grounding/comparison.png), [pending box review](iteration2/synthetic/accepted_multiple/continuation/box_review/pending.json).

The synthetic image is a small blank fixture and boxes are mock outputs; it contains no demonstrated cultural adaptation or real detection. Test reviewer strings explicitly identify synthetic declarations. The changed-plan case deliberately contains inconsistent disposable synthetic evidence to demonstrate rejection; it is not a successful approved run. Native planning input/output JSONs preserve their recorded paths, including temporary fixture paths. Verification uses bundled relative evidence and hashes; tests regenerate fresh paths when reproduced.

### Real-world evidence and positive-candidate search

Inspected 32 saved planner audits with input/response/final-result fields and 20 standalone plan JSONs. **Zero saved audit final decisions are PROPOSE; zero eligible current final PROPOSE candidates were found.** Seven audits carry the current raw-result field; legacy formats were not silently upgraded into eligible approval evidence. Two early current-format records cannot reproduce their saved final under the present validator; their errors and unchanged hashes are preserved in the survey. They remain historical evidence, not continuation inputs.

The three final policy cases still revalidate as Japanese food REVIEW, uncertain/truncated Durga REVIEW, bicycle ABSTAIN, all with zero released candidates. Copies of their [food audit](iteration2/real_evidence/01_japanese_food.audit.json), [Durga audit](iteration2/real_evidence/02_durga_uncertain_incense.audit.json), [bicycle audit](iteration2/real_evidence/03_bicycle_no_change.audit.json) retain raw responses, exact prompts, validated decisions, issue codes and rejected proposals unchanged. The food's verified identity is a hypothetical fixture assertion, not an approved source photograph.

The actual Iteration 1 bicycle run remains REVIEW with no candidates. The new preparer rejected it before producing any pending intent: [real boundary check](iteration2/real_review_boundary.json). No real pending edit-intent request or genuine acceptance was created. Earlier pending box/mask reviews remain pending and confer no new authority.

Source-image inventory/provenance was inspected. The cooking photograph `scene_07.jpg` visibly shows a person near vessels and a fire, but vessel contents cannot be confidently identified. A title or assistant observation is not user-provided verified food identity. The tea-ceremony source is context-sensitive; a target country alone does not justify replacing its objects. No arbitrary replacement was prescribed. [Image suitability and existing attribution metadata](iteration2/image_suitability.json); [complete audit survey with hashes/errors](iteration2/real_candidate_survey.json).

**New Qwen runs: 0. New live grounding runs: 0. SAM runs: 0. Diffusion runs: 0.** No real image was generated. Avoiding another unsupported condition preserves the validator and the one-condition research budget.

### Regression tests and compatibility

Command actually run before and after: `python -B -m unittest discover -s tests -v`, with HF_HUB_OFFLINE=1 and no checkpoint downloads.

| Run | Passed | Failed/errors | unittest time | Full subprocess wall time |
| --- | --- | --- | --- | --- |
| Before | 260 | 0 | 19.744 s | 23.568 s |
| After | 299 | 0 | 24.612 s | 28.468 s |

All 260 existing tests remain, plus 39 focused tests for pending/accepted/rejected/needs-review decisions, explicit first/second candidate binding, original/replacement phrases, REVIEW/ABSTAIN/quarantine, modified image/plan/audit/raw response, missing evidence, invalid index, placeholders, inspection flags, output immutability, model-construction/inference failure, cleanup order, zero/multiple detections, portable copied review bundles, typed CLI input and editing prohibition. Eight CLI help checks passed, including existing stage and review commands. [Before test log](iteration2/tests_before.json), [after full test log](iteration2/tests_after.json), [CLI checks](iteration2/cli_checks.json), [environment](iteration2/environment.json).

These tests establish the exercised contracts and stop behavior; they do not prove cultural correctness, live-model performance or actual human identity. No additional timing or GPU benchmark is implied by test runtimes.

### Git and preservation

Two application/tool files added and two existing integration files changed: 692 added / 8 removed lines in the snapshot diff, excluding report/evidence generation. At entry, Iteration 1 orchestration, runner, tests and evidence were already untracked user work. Ordinary `git diff` therefore omits them; the provided patch compares against byte-hash-matched original Iteration 1 ZIP source snapshots, not an invented clean Git baseline. No commit, push, reset or clean was run.

Existing stage implementations, configs, prior tests and Iteration 1 artifacts retain their baseline hashes. The working report's entire previous byte sequence is preserved as a prefix; this section is appended. [Baseline preservation manifest](iteration2/preservation_before.json), [final preservation verification](iteration2/preservation_after.json), [Git entry status](iteration2/git_before.json), [Git exit summary](iteration2/git_after.json).

### Remaining limitations and mentor decision

1. Live grounding from a genuinely accepted cultural-edit proposal remains untested because no eligible real positive exists. A real source-object verification and a defensible Qwen final PROPOSE are prerequisites; neither may be fabricated.
2. Reviewer identity and inspection are explicit declarations without authentication or signatures. A malicious editor able to rewrite all evidence/manifests is outside this local research tool's trust model. Hashes cannot prove semantic truth or reviewer expertise.
3. Acceptance is narrowly scoped to testing source localization. Confidence cannot certify semantic correctness; returned boxes still need explicit box review. SAM, mask selection and generation approval are out of scope.
4. Legacy audits preserve old schemas/policies. The tool deliberately accepts the native automated-run bundle rather than arbitrary historical standalone plan files; older or manually assembled chains are not promoted into approvals.
5. A failed or incomplete review preparation/continuation may leave a partial new directory for diagnosis; exclusive creation prevents silently overwriting it. Use a new output directory after correcting evidence.
6. Native detector behavior and sequential resource cleanup are covered by existing tests and new mocked handoff tests; this iteration adds no new measured GPU or cultural-quality evidence.

The narrow implementation is ready for independent code and synthetic-evidence review. **Do not claim a culturally verified end-to-end transformation or proceed to another milestone automatically.**

Portable-package verification: extraction into a separate temporary directory passed all 39 new tests (9.500 s) and verification of the copied synthetic accepted review. All 303 initially manifested payloads matched their hashes. No original repository paths or live models were needed. [Extraction test evidence](iteration2/extraction_verification.json).
