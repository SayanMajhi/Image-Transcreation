# Phase 7 Iteration 2 review package

Start with [the updated working report](results/phase7_integration/phase7_working_report.md).
This package contains synthetic approvals and mock detections, never real human approval.
No live model ran during Iteration 2. Iteration 1's recorded bicycle planning evidence is preserved for context.

Use the existing Python 3.11 environment with the package root as the working directory:

```powershell
$env:PYTHONPATH = (Resolve-Path src).Path
$env:HF_HUB_OFFLINE = "1"
python -B -m unittest discover -s tests -p test_edit_intent.py -v
python -B -m unittest discover -s tests -v
python -m scripts.review_edit_intent verify --review results/phase7_integration/iteration2/synthetic/accepted_multiple/intent/decision.json
```

The verify command validates only synthetic saved evidence. It grants no live execution or editing authority.
The normal CLI blocks synthetic approvals; no real grounding call is needed to inspect this package.
Old JSONs retain original paths and measurements. Review bundles verify relative copies rather than relying on those old paths.
`changed_plan` intentionally contains invalid synthetic evidence for rejection testing.
Existing source-image attribution metadata accompanies the original recorded evidence. The bicycle photograph is Basile Morin / CC BY-SA 4.0.
