"""Portable offline verification; no model execution or service access."""
from pathlib import Path
import hashlib,json,os,sys,tempfile
root=Path(__file__).resolve().parent
os.chdir(root);sys.path[:0]=[str(root),str(root/'src')]
for name,digest in json.loads((root/'MANIFEST.sha256.json').read_text()).items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
base=root/'results/phase7_integration/iteration1'
for result_path in base.rglob('pipeline_result.json'):
 record=json.loads(result_path.read_text());assert record['image_generation_permitted'] is False
 for artifact in record['artifact_ids'].values():
  p=(result_path.parent/artifact['path']).resolve();assert p.is_relative_to(result_path.parent.resolve())
  assert hashlib.sha256(p.read_bytes()).hexdigest()==artifact['sha256']
real=json.loads((base/'real_run/pipeline_result.json').read_text());assert real['state']=='PLAN_REQUIRES_REVIEW'
assert real['completed_stages']==['source','caption','planning','deterministic_validation']
from transcreation.orchestration import PipelineInput,ReplayChain,run_pipeline
values=json.loads((root/'portable_replay_input.json').read_text());values['replay']=ReplayChain(**values['replay']);values['verified_objects']=()
with tempfile.TemporaryDirectory() as folder:
 values['output_dir']=str(Path(folder)/'replay');result=run_pipeline(PipelineInput(**values))
 assert result.state=='SOURCE_OBJECT_REQUIRES_REVIEW' and result.replay_validated
 assert not result.image_generation_permitted
 assert result.required_reviews==('BOX_REVIEW_MISSING','MASK_REVIEW_PENDING')
 assert not any(name in sys.modules for name in ['torch','transformers','diffusers'])
 print(json.dumps({'real_state':real['state'],'portable_replay_state':result.state,'replay_validated':result.replay_validated,'required_reviews':result.required_reviews,'model_calls':0,'model_libraries_imported':False,'new_generation_permitted':False},indent=2))
