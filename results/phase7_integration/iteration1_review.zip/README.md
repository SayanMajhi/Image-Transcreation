# Phase 7 iteration 1 review package

Read [the Phase 7 working report](results/phase7_integration/phase7_working_report.md).

- [Actual bicycle caption](results/phase7_integration/iteration1/real_run/caption.json)
- [Actual raw/final Qwen audit](results/phase7_integration/iteration1/real_run/planner_audit.json)
- [Actual stage transitions and safe REVIEW stop](results/phase7_integration/iteration1/real_run/pipeline_result.json)
- [Read-only research-chain replay and outstanding gates](results/phase7_integration/iteration1/offline/oil_lamp_replay/pipeline_result.json)
- [Saved food/Durga/bicycle policy regression](results/phase7_integration/iteration1/offline/planner_regressions.json)
- [Full 260-test regression log](results/phase7_integration/iteration1/tests_after.json)

Recommendation: NEEDS FIXES for complete approved live orchestration. Implemented paths are live caption-to-validated-plan and saved-artifact replay. No approved live detector/SAM/inpainting continuation or generation authorization route exists. No new image was generated. The one real run ended in REVIEW; Qwen's unsupported national-appropriateness claim is not endorsed.

Review needs no model inference. `python -B verify_evidence.py` checks manifest/artifact hashes and performs the portable read-only replay against included source copies. It requires existing Python/NumPy/Pillow/PyYAML, not model weights, a GPU, Ollama or access to the original Windows paths.

`portable_replay_input.json` remaps paths only and uses the same pinned source, detection, SAM, mask, pending review and existing research-generation bytes. The old lamp output is included only to verify the historical chain, not as a Phase7-generated image or a culturally approved result. Raw audit path strings remain historical provenance.

Relevant source/config/test snapshots are included. No pretrained weights, caches, virtual environments or unrelated datasets are bundled. Attribution for the two relevant photographs and previous modified lamp output is included in the evidence. Do not run new captioning/planning merely to review this package.
