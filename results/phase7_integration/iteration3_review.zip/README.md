# Phase 7 Iteration 3 review package

Start with [the same Phase 7 working report](results/phase7_integration/phase7_working_report.md).
Iteration 3 is BLOCKED pending actual user source verification. No new live model ran.
No new caption, Qwen plan or human approval is claimed. Prior iterations are preserved as history.

Inspect [the source preview](results/phase7_integration/iteration3/source_preview.jpg) and
[pending verification request](results/phase7_integration/iteration3/pending_source_verification.json).
The actual user must supply the verified object, target/context, intended change and preservation constraints.
The unchanged validator always requires REVIEW for a candidate with nonempty instructions.

For offline reproduction with Python 3.11 and the existing installed dependencies:

```powershell
$env:PYTHONPATH = (Resolve-Path src).Path
$env:HF_HUB_OFFLINE = "1"
python -B results/phase7_integration/iteration3/reproduce_policy_diagnostics.py --output diagnostics_reproduced.json
python -B -m unittest discover -s tests -v
```

Diagnostics contain synthetic drafts only, never actual verified cultural proposals.
Do not run a live pipeline from this package until the required actual user verification.
The original bicycle photograph is Basile Morin / CC BY-SA 4.0; source URL and original attribution are retained in source_provenance.json.
All native historical JSON paths and measurements are preserved as recorded.
