# Phase 7 Iteration 7 source-anchored prompt review

Start with [the same working report](results/phase7_integration/phase7_working_report.md), Iteration 7.
One system-prompt variant and one real Qwen call. Input/model/settings/schema/validator unchanged from Iteration 6.
Source description, ID, original localization and summary attribution improved in this case.
Raw PROPOSE became REVIEW because an uncertainty remains. Zero candidates released; no intent request or downstream inference.

Inspect [old prompt](results/phase7_integration/iteration7/old_system_prompt.txt),
[new prompt](results/phase7_integration/iteration7/new_system_prompt.txt),
[actual request comparison](results/phase7_integration/iteration7/request_comparison_verified.json),
[raw/final audit](results/phase7_integration/iteration7/planner_audit.json), and
[final result](results/phase7_integration/iteration7/validated_plan.json).

Offline inspection with existing Python 3.11 dependencies:

```powershell
$env:PYTHONPATH = (Resolve-Path src).Path
$env:HF_HUB_OFFLINE = "1"
python -B results/phase7_integration/iteration7/verify_saved_run.py
python -B -m unittest discover -s tests -v
```

Do not rerun controlled_call_driver.py: it archives the one executed condition for inspection.
Six new tests use mocked outputs and are not actual model evidence.
The source photo is user-provided with unknown public license, included for requested mentor review.
Source confirmation is not independent proof of cultural origin or edit authorization. No human approval was fabricated.
Previous failures/report sections are retained as history; current root source has the revised prompt.

The initial in-memory tuple/list diagnostic is preserved in request_comparison.json; use the verified saved-JSON comparison above. No condition or model result was changed.
