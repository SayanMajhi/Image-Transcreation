from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image
root=Path(__file__).resolve().parent
for name,digest in json.loads((root/'MANIFEST.sha256.json').read_text()).items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
base=root/'results/phase6_inpainting/iteration4';decision=json.loads((base/'decision.json').read_text())
assert decision['proposed_revised_mask'] is None and decision['new_generated_image'] is None
assert decision['model_generation_calls']==decision['changed_mask_pixels']==0
for item in json.loads((base/'source_hashes.json').read_text()):
 assert hashlib.sha256((root/item['copy']).read_bytes()).hexdigest()==item['sha256']
with Image.open(base/'evidence/original.jpg') as image:original=np.asarray(image.convert('RGB'))
with Image.open(base/'evidence/original_mask.png') as image:
 assert image.mode=='L' and set(image.tobytes())=={0,255};mask=np.asarray(image)==255
assert original.shape[:2]==mask.shape and int(mask.sum())==32088
for name in ['iteration2_final.png','iteration3_final.png']:
 with Image.open(base/'evidence'/name) as image:prior=np.asarray(image.convert('RGB'))
 assert prior.shape==original.shape and np.array_equal(prior[~mask],original[~mask])
assert (root/'reports/phase6_working.md').read_bytes().startswith((base/'working_report_before.txt').read_bytes())
print('PASS: original source/mask, prior image locality, unchanged report prefix and blocked zero-edit/zero-generation decision verified. No new output exists.')
