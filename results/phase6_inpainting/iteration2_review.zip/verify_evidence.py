"""Independent verification; no model libraries, generation functions or Windows paths needed."""
from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image

root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.sha256.json').read_text())
for name,digest in manifest.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
base=root/'results/phase6_inpainting'; old=json.loads((base/'iteration1/run/inpainting.json').read_text());new=json.loads((base/'iteration2/run/inpainting.json').read_text())
assert old['geometry']==new['geometry']
def normalize(settings):
    result=dict(settings);config=dict(settings['scheduler_config']);config['_use_default_values']=sorted(config.get('_use_default_values',[]));result['scheduler_config']=config;return result
assert normalize(old['settings'])==normalize(new['settings'])
assert [k for k in old['request'] if old['request'][k]!=new['request'][k]]==['prompt']
image_path=base/'iteration2/run/evidence/original.jpg';mask_path=base/'iteration2/run/evidence/mask_0.png'
assert hashlib.sha256(image_path.read_bytes()).hexdigest()==old['request']['image_sha256']==new['request']['image_sha256']
assert hashlib.sha256(mask_path.read_bytes()).hexdigest()==old['request']['mask_sha256']==new['request']['mask_sha256']
with Image.open(image_path) as image:source=np.asarray(image.convert('RGB'))
with Image.open(mask_path) as image:
    assert image.mode=='L' and set(image.tobytes())=={0,255};mask=np.asarray(image)==255
results=[]
for name in ['iteration1','iteration2']:
    with Image.open(base/name/'run/final.png') as image:final=np.asarray(image.convert('RGB'))
    assert source.shape==final.shape
    changed=np.any(source!=final,axis=2);assert not changed[~mask].any();assert changed[mask].any()
    results.append(dict(iteration=name,changed_inside=int((changed&mask).sum()),changed_outside=int((changed&~mask).sum())))
assert json.loads((base/'iteration2/invocation.json').read_text())['generation_calls']==1
assert (root/'reports/phase6_working.md').read_bytes().startswith((base/'iteration2/working_report_before.txt').read_bytes())
print(json.dumps(dict(manifest_files=len(manifest),pixel_checks=results,only_prompt_changed=True,original_report_prefix_preserved=True,model_inference_calls=0),indent=2))
