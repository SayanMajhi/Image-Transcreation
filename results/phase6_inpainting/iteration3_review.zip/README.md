# Phase 6 iteration 3 review

Read [the same working report, now with Iteration 3 appended](reports/phase6_working.md).

- [Original / original mask / hard Iteration 2 / blend Iteration 3](results/phase6_inpainting/iteration3/full_comparison.png)
- [Bowl comparison](results/phase6_inpainting/iteration3/bowl_comparison.png)
- [Rim, wick, texture and support close-ups](results/phase6_inpainting/iteration3/detail_comparison.png)
- [Binary mask versus alpha](results/phase6_inpainting/iteration3/alpha_comparison.png)
- [New final image](results/phase6_inpainting/iteration3/run/final.png)
- [Independent metrics](results/phase6_inpainting/iteration3/independent_verification.json)
- [Full 232-test regression record](results/phase6_inpainting/iteration3/tests_after.json)

Exactly one radius-5 mask-constrained blending condition was run. No diffusion inference or new prompt. Recommendation: NEEDS FIXES; subtle boundary softening does not fix wick/bowl geometry and reintroduces source content in the transition. The hard compositor remains the application default. No human acceptance is claimed.

All required images are included at portable paths. Old audit strings may retain historical machine paths; no access to those paths is needed for review. Older report sections and evidence are preserved as context, without old ZIPs, weights, environments or unrelated datasets.

With NumPy and Pillow installed, run `python -B verify_evidence.py` to verify manifest hashes, mask-restricted alpha, integer RGB reconstruction and exact outside-mask equality without any model library.

The nine new CPU-only tests can be run with `python -B -m unittest discover -s tests -p test_mask_blending.py -v`. They need no weights or GPU.

Optional deliberate reproduction of the single fixed postprocessing condition (not needed for review): `python -B -m scripts.blend_mask --input portable_input.json --out reproduced_blend_new`. This portable input binds the same bytes; do not use the earlier report's generation commands for this iteration.

Source photograph: Benoy / Diwali Oil lamps Darjeeling / CC BY-SA 3.0. Modifications and source license are retained in the working report and original attribution file. This remains research-only postprocessing, not cultural transformation or phase sign-off.
