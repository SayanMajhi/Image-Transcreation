"""Independent saved-image verifier. No project generation imports or model libraries."""
from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image,ImageFilter

root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.sha256.json').read_text())
for name,digest in manifest.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
base=root/'results/phase6_inpainting/iteration3';folder=base/'run'
metadata=json.loads((folder/'blending.json').read_text())
for name,value in [('source_image','original.jpg'),('mask_file','original_mask.png'),('hard_image','iteration2_final.png')]:
    assert hashlib.sha256((folder/value).read_bytes()).hexdigest()==metadata['input_sha256'][name]
with Image.open(folder/'original.jpg') as image:source=np.asarray(image.convert('RGB'))
with Image.open(folder/'iteration2_final.png') as image:hard=np.asarray(image.convert('RGB'))
with Image.open(folder/'original_mask.png') as image:
    assert image.mode=='L' and set(image.tobytes())=={0,255}
    mask=np.asarray(image)==255;blur=np.asarray(image.filter(ImageFilter.GaussianBlur(radius=5)))
with Image.open(folder/'alpha.png') as image:alpha=np.asarray(image)
with Image.open(folder/'final.png') as image:final=np.asarray(image.convert('RGB'))
assert source.shape==hard.shape==final.shape and alpha.shape==mask.shape==source.shape[:2]
assert np.array_equal(alpha,np.where(mask,blur,0))
assert np.count_nonzero(alpha[~mask])==0
w=alpha.astype(np.uint32)[...,None]
expected=((w*hard.astype(np.uint32)+(255-w)*source.astype(np.uint32)+127)//255).astype(np.uint8)
assert np.array_equal(final,expected)
changed=np.any(source!=final,axis=2);assert not changed[~mask].any()
different=np.any(hard!=final,axis=2)
assert (root/'reports/phase6_working.md').read_bytes().startswith((base/'working_report_before.txt').read_bytes())
print(json.dumps({'manifest_files':len(manifest),'alpha_outside':int(np.count_nonzero(alpha[~mask])),'changed_inside':int((changed&mask).sum()),'changed_outside':int((changed&~mask).sum()),'hard_vs_blended_pixels':int(different.sum()),'RGB_integer_reference_exact':True,'old_report_prefix_preserved':True,'model_imports_or_calls':0},indent=2))
