# Phase 6 iteration 1 review package

Start with [the single Phase 6 working report](reports/phase6_working.md).
Inspect [original versus final detail](results/phase6_inpainting/iteration1/run/detail.png), [the final image](results/phase6_inpainting/iteration1/run/final.png) and [measured output](results/phase6_inpainting/iteration1/run/inpainting.json).

This is RESEARCH_ONLY. It is not human mask approval, cultural-edit approval or a final Phase 6 sign-off. Historical source paths inside raw records are audit context, not dependencies for review. `portable_input.json` binds the same exact image/mask/segmentation bytes at included paths.

To run offline tests from this extracted directory with the recorded dependencies installed:
```powershell
$env:HF_HUB_OFFLINE = "1"
$env:PYTHONPATH = (Resolve-Path .\src).Path
python -B -m unittest discover -s tests -v
```

Model inference is unnecessary for review. Optional intentional reproduction after installing `pip install -e ".[inpainting]"`:
```powershell
python -B -m scripts.inpaint --input portable_input.json --out reproduced_run_new
```
Weights are excluded; uncached reproduction downloads the same pinned safetensors checkpoint. Use fresh output paths. Read the attribution and recorded environment before redistribution/reproduction. No further experiment is requested by this package.
